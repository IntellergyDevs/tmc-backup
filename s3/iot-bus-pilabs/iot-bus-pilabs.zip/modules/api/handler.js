module.exports.test = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    console.log("hi in pilabs");
}