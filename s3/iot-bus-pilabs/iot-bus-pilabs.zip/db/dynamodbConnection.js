const AWS = require("aws-sdk");
const config = require('../config')
AWS.config.update(config.aws_remote_config);
const dynamodbClient = new AWS.DynamoDB.DocumentClient();

const params = {
    TableName: config.aws_table_name
};

const getTripsData = ()=>{

}
