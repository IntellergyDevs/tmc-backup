const AWS = require("aws-sdk");

AWS.config.update({
  region: "af-south-1", // replace with your region in AWS account
});

const DynamoDB = new AWS.DynamoDB();
async function createTable() {
    const params = {
      TableName: "stoplocations",
      AttributeDefinitions: [
          { AttributeName: "Id", AttributeType:"S" },
        //   { AttributeName: "routeAllocationName", AttributeType:"S" },
        //   { AttributeName: "StopNumber", AttributeType:"S" },
        //   { AttributeName: "PointX", AttributeType:"S" },
        //   { AttributeName: "PointY", AttributeType:"S" },
        //   { AttributeName: "colorScheme", AttributeType:"S" },
        //   { AttributeName: "createdAt", AttributeType:"S" },
        //   { AttributeName: "updatedAt", AttributeType:"S" }
    ],
    KeySchema: [{ AttributeName: "Id", KeyType: "HASH" }],
      ProvisionedThroughput: {
        ReadCapacityUnits: 10,
        WriteCapacityUnits: 10,
      },
    };
  let result;
    DynamoDB.createTable(params, function(err, data) {
      if (err) {
        console.error("Unable to create table======>", err);
        result = JSON.stringify(err,null,2)
        return result;
      } else {
        console.log("Created table", data);
        return data;
      }
    });
  }
  
  module.exports = {
    createTable,
  };