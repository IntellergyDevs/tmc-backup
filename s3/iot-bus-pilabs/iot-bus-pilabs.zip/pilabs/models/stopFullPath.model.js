const AWS = require("aws-sdk");

AWS.config.update({
  region: "af-south-1", // replace with your region in AWS account
});

const dynamoDBClient = new AWS.DynamoDB.DocumentClient()

  const getAllData = async () => {
    console.log('hi scanning pilabs-stopsFullPath table');
    let params = {
        TableName: 'pilabs-stopsFullPath'
    }

    try {
        const stopsFullPaths = await dynamoDBClient.scan(params).promise();
    // console.log('stopsFullPath======>',stopsFullPaths)
    let records = stopsFullPaths.Items? stopsFullPaths.Items: [];
    return records;
    } catch (error) {
        console.log("error while scanning stopsFullPath",error)
    }
}
  
  module.exports = {
    getAllData
  };