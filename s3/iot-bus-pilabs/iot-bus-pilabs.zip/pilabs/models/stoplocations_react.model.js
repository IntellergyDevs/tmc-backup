const AWS = require("aws-sdk");

AWS.config.update({
  region: "af-south-1", // replace with your region in AWS account
});

const dynamoDBClient = new AWS.DynamoDB.DocumentClient()

  const getAllData = async () => {
    console.log('hi scanning pilabs-stoplocations_react table');
    let params = {
        TableName: 'pilabs-stoplocations_react'
    }

    try {
        const stoplocationsReact = await dynamoDBClient.scan(params).promise();
    // console.log('stopsFullPath======>',stoplocationsReact)
    let records = stoplocationsReact.Items? stoplocationsReact.Items: [];
    return records;
    } catch (error) {
        console.log("error while scanning pilabs-stoplocations_react",error)
    }
}
  
  module.exports = {
    getAllData
  };