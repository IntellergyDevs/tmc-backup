const AWS = require("aws-sdk");
const { uuid } = require('uuidv4');
AWS.config.update({
    region: "af-south-1", // replace with your region in AWS account
});

const dynamoDBClient = new AWS.DynamoDB.DocumentClient()

async function insertDeviceItem(deviceData) {
    let id = uuid()
    var params = {
        TableName: "devices",
        Item: {
            "id": id,
            "imei": deviceData.imei,
            "deviceName": deviceData.deviceName,
            "device": deviceData.device,
            "serialNumber": deviceData.serialNumber,
            "installationDate": deviceData.installationDate,
            "isActive": deviceData.isActive,
        },
    };

    let response;
    dynamoDBClient.put(params, function (err, data) {
        if (err) {
            console.error("Unable to add device", imei, ". Error JSON:", JSON.stringify(err, null, 2));
            response = {
                statusCode: 400,
                body: JSON.stringify({
                    message: 'Pi-labs device Not added successfully!',
                    input: err,
                }),
            }

        } else {
            console.log("PutdeviceItem succeeded:", data);
            response = {
                statusCode: 200,
                body: JSON.stringify({
                    message: 'Pi-labs device added successfully!',
                    input: data,
                }),
            }
        }
    });
    return response;
}
const getAllData = async () => {
    console.log('hi scanning device table');
    let params = {
        TableName: 'devices'
    }
    try {
        const devices = await dynamoDBClient.scan(params).promise();
        console.log('devices======>', devices)
        let records = [];
        for (let device of devices.Items) {
            // status according to geotab of pilabs
           let deviceStatus = device.status
            if(deviceStatus === "START_DRIVING"){
              deviceStatus = "running"
            }
            if(deviceStatus === "SLEEP_AFTER_IDLE" ){
              deviceStatus = "stopped"
            }
            let record = {
                status: deviceStatus ? deviceStatus:'idle',
                statusDuration: device.statusDuration ? device.statusDuration : '00:01:16',
                latitude: 1 * (device.latitude ? device.latitude : 0.0).toFixed(8),
                longitude:1 * (device.longitude ? device.longitude : 0.0).toFixed(8),
                id: device.imei,
                DeviceName: device.deviceName,
            }
            records.push(record);
        }
        return records;
    } catch (error) {
        console.log("error while scanning device", error)
    }
}
const insertSNSRawData = async (parsedMessage) => {
    console.log('insertSNSRawData=====>');
    let id = uuid()
    let params = {
        TableName: 'deviceStatusInfo',
        Item: {
            id: id,
            imei: parsedMessage.imei,
            acceleration: parsedMessage.acceleration ? parsedMessage.acceleration : [],
            fullPosition: parsedMessage.fullPosition ? parsedMessage.fullPosition : [],
            syncedTime: parsedMessage.syncedTime ? parsedMessage.syncedTime : 0,
            timestamp: parsedMessage.timestamp ? parsedMessage.timestamp : 0,
            syncSource: parsedMessage.syncSource ? parsedMessage.syncSource : 0,
            transmissionReason: parsedMessage.transmissionReason ? parsedMessage.transmissionReason : " ",
            msgCount: parsedMessage.msgCount ? parsedMessage.msgCount : 0,
            snsMessage: parsedMessage
        },

    }
    console.log("sns data stored on dynamodb========>", parsedMessage)
    try {
        const data = await dynamoDBClient.put(params).promise()
        console.log("Success")
        return data
    } catch (err) {
        console.log("Failure==========>", err.message)
        // there is no data here, you can return undefined or similar
    }
}

const updateData = async (snsMessage) => {
    // update data according to imei number
    let fullPosition = snsMessage.fullPosition;

    console.log("fullPosition=======>", data);
    //   const updateparams = {
    //     TableName: "devices",
    //     Key: {
    //         "imei": "1"
    //     },
    //     UpdateExpression: "set latitude = :lat, #longitude = :long",
    //     ExpressionAttributeValues: {
    //         ":lat": `${}`,
    //         ":long": `${}`
    //     },
    //     ReturnValues:"UPDATED_NEW"
    // };

    // dynamoDBClient.update(params, function(err, data) {
    //     if (err) console.log(err);
    //     else console.log(data);
    // });
}

const getIdByIMEI = async (imei) => {
    let deviceId;
    console.log("imei====>", imei)
    switch (imei) {
        case "867035048171043":
            deviceId = "df5cb855-c5ea-43b9-aa3e-e5646f6eefd6";
            break;

        case "867035048171126":
            deviceId = "874821d9-c5a3-410f-99e0-f94eafd67c8f"
            break;

        case "867035048171324":
            deviceId = "5d181a56-62fc-4415-bd20-3eda31565d98"
            break;

        default:
            break;
    }
    console.log("deviceId====>", deviceId)
    return deviceId;
}

const saveCurrentLocationByDeviceId = async (currentLocation) => {
    try {
        console.log("saveCurrentLocationByDeviceId =========> ", currentLocation);
        // let Item = {
        //     imei : currentLocation.imei,
        //     latitude: currentLocation[0].latitude,
        //     longitude : currentLocation[0].longitude,
        //     status : currentLocation.transmissionReason
        // }
        let params = {
            TableName: "devices",
            Key: { id: currentLocation.deviceId },
            // KeyConditionExpression : 'imei :imeiVal',
            UpdateExpression: `SET #lat = :latitude, #long = :longitude, #status = :status`,
            ExpressionAttributeNames: {
                '#lat': 'latitude',
                '#long': 'longitude',
                '#status': 'status'
            },
            ExpressionAttributeValues: {
                // ':id' : currentLocation.deviceId,
                ':latitude': currentLocation[0].lat,
                ':longitude': currentLocation[0].long,
                ':status': currentLocation.transmissionReason
            }
        }

        return await dynamoDBClient.update(params).promise();
        // console.log("updated devices=======>", update);

    } catch (error) {
        console.log(" error caught in saveCurrentLocationByDeviceId =========> ", error);
    }
}
const saveStatusReason = async (snsMessageData)=>{
    let params = {
        TableName: "devices",
        Key: { id: snsMessageData.deviceId },
        // KeyConditionExpression : 'imei :imeiVal',
        UpdateExpression: `SET #status = :status`,
        ExpressionAttributeNames: {
            '#status': 'status'
        },
        ExpressionAttributeValues: {
            ':status': snsMessageData.reason
        }
    }

    return await dynamoDBClient.update(params).promise();
}
module.exports = {
    insertDeviceItem,
    getAllData,
    insertSNSRawData,
    updateData,
    getIdByIMEI,
    saveCurrentLocationByDeviceId,
    saveStatusReason
}