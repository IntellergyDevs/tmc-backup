
module.exports.getAllTripList = async()=>{
    var params = {
        TableName: 'pilabs-trips-database',
        // ProjectionExpression: "id, fullname, email"
    };
    console.log("Scanning pilabs trips table.");
    const onScan = (err, data) => {
        if (err) {
            console.log('Scan failed to load data. Error JSON:', JSON.stringify(err, null, 2));
            return (err);
        } else {
            console.log("Scan succeeded.");
           return (data.Items);
        }

    };

    dynamoDb.scan(params, onScan);
}