var AWS = require('aws-sdk');
const dynamoDBClient = new AWS.DynamoDB.DocumentClient()
const { uuid } = require('uuidv4');
const deviceModel = require('../models/device2.model')
const deviceStatusInfoModel = require('../models/statusDeviceInfo.model')
module.exports.snsLambda = async (event) => {
  try {
    let message = event.Records[0].Sns.Message;
    let parsedMessage = JSON.parse(message)
    console.log("parsedMessage========>", parsedMessage);
    let deviceDetailsExist;
    deviceDetailsExist = await deviceStatusInfoModel.findOne({ where: { deviceId: parsedMessage.imei }, raw: true });
    console.log("deviceDetailsExist=======>", deviceDetailsExist);
    if (deviceDetailsExist) {
      //1. save start or reconnect bus info
      if (parsedMessage && parsedMessage.reason) {
        console.log("parsedMessage======>", parsedMessage);
        let requestBody = {
          status: parsedMessage.reason,
          updatedAt: new Date(),
        }
        let saveIdleReason = await deviceStatusInfoModel.update(requestBody, { where: { deviceId: parsedMessage.imei } })
        // let saveIdleReason = await deviceModel.saveStatusReason(parsedMessage);
      }
      //2. save stop status 
      if (parsedMessage && parsedMessage.reconnect) {
        // parsedMessage.reason = 'idle'
        let requestBody = {
          status: 'idle',
          updatedAt : new Date()
        }
        let saveIdleReason = await deviceStatusInfoModel.update(requestBody, { where: { deviceId: parsedMessage.imei } })
      
      }
      // 3. save lat long when fullPosition is present in sns
      if (parsedMessage && parsedMessage.fullPosition) {
        let Locations = parsedMessage.fullPosition;
        let currentLocation = Locations.slice(-1);
        currentLocation.transmissionReason = parsedMessage.transmissionReason;
        currentLocation.imei = parsedMessage.imei;
        console.log("currentLocation========>", currentLocation);
        let requestBody = {
          latitude: currentLocation[0].lat,
          longitude: currentLocation[0].long,
          status: parsedMessage.transmissionReason,
          updatedAt : new Date()
        }
        let saveCurrentLocation = await deviceStatusInfoModel.update(requestBody, { where: { deviceId: parsedMessage.imei } })
      }
    } else {
      // not found device
      console.log("error while finding deviceId",deviceDetailsExist)
    }

    // parsedMessage.deviceId = await deviceModel.getIdByIMEI(parsedMessage.imei);
    // //1. save start or reconnect bus info
    // if (parsedMessage && parsedMessage.reason) {
    //   console.log("parsedMessage======>", parsedMessage);
    //   let saveIdleReason = await deviceModel.saveStatusReason(parsedMessage);
    // }
    // //2. save stop status 
    // if (parsedMessage && parsedMessage.reconnect) {
    //   console.log("parsedMessage======>", parsedMessage);
    //   parsedMessage.reason = 'idle'
    //   let saveStopReason = await deviceModel.saveStatusReason(parsedMessage);
    // }
    // // 3. save lat long when fullPosition is present in sns
    // if (parsedMessage && parsedMessage.fullPosition) {
    //   let Locations = parsedMessage.fullPosition;
    //   let currentLocation = Locations.slice(-1);
    //   currentLocation.transmissionReason = parsedMessage.transmissionReason;
    //   currentLocation.imei = parsedMessage.imei;
    //   currentLocation.deviceId = parsedMessage.deviceId;
    //   let saveCurrentLocation = deviceModel.saveCurrentLocationByDeviceId(currentLocation);
    // }
    // let result = await deviceModel.insertSNSRawData(parsedMessage)

    console.log("Received MESSAGE: " + message);

    //   return message;
    return message;
  } catch (error) {
    console.log("Received error: ", error);
    return error;
  }
}


module.exports.getAll = async (event, context, callback) => {
  try {
    let parsedMessage = {
      reason: 'SLEEP_AFTER_IDLE',
      imei: '867035048171043',
      calibrationPhi: -1,
      batteryVoltageMv: 3846,
      supplyVoltageDv: 3,
      deviceId: 'df5cb855-c5ea-43b9-aa3e-e5646f6eefd6'
    };
    let deviceDetailsExist;
    deviceDetailsExist = await deviceStatusInfoModel.findOne({ where: { deviceId: parsedMessage.imei }, raw: true });
    console.log("deviceDetailsExist=======>", deviceDetailsExist);
    if (deviceDetailsExist) {
      // 3. save lat long when fullPosition is present in sns
      if (parsedMessage && parsedMessage.fullPosition) {
        // let Locations = parsedMessage.fullPosition;
        // let currentLocation = Locations.slice(-1);
        // currentLocation.transmissionReason = parsedMessage.transmissionReason;
        // currentLocation.imei = parsedMessage.imei;
        console.log("currentLocation========>", currentLocation);
        // currentLocation.deviceId = parsedMessage.deviceId;
        // let saveCurrentLocation = await deviceStatusInfoModel.update(requestBody, { where: { deviceId: parsedMessage.imei } })
      }
    } else {
      // not found device
    }


  } catch (error) {
    console.log("error====>", error);
  }
}
module.exports.snsLambda1 = async (event) => {
  let message = event.Records[0].Sns.Message;
  console.log("snsLambda1=======>", message);
  try {
    // let message = event.Records[0].Sns.Message;
    // console.log("snsLambda1=======>",message);
    let parsedMessage = JSON.parse(message)
    console.log("parsedMessage======>", parsedMessage);
    let deviceDetailsExist;
    deviceDetailsExist = await deviceStatusInfoModel.findOne({ where: { deviceId: parsedMessage.imei }, raw: true });
    console.log("deviceDetailsExist=======>", deviceDetailsExist);

    if (deviceDetailsExist) {
      // 3. save lat long when fullPosition is present in sns
      if (parsedMessage && parsedMessage.fullPosition) {
        let Locations = parsedMessage.fullPosition;
        let currentLocation = Locations.slice(-1);
        currentLocation.transmissionReason = parsedMessage.transmissionReason;
        currentLocation.imei = parsedMessage.imei;
        console.log("currentLocation========>", currentLocation);
        // currentLocation.deviceId = parsedMessage.deviceId;
        // let saveCurrentLocation = await deviceStatusInfoModel.update(requestBody, { where: { deviceId: parsedMessage.imei } })
      }
    } else {
      // not found device
    }
    return message;
  } catch (error) {
    console.log("Received error: ", error);
    return error;
  }
}
module.exports.harshEvents = async (event) => {
  try {
    let message = event.Records[0].Sns.Message;
    let parsedMessage = JSON.parse(message);
    console.log("parsedMessage=======>", parsedMessage)
  } catch (error) {
    console.log("error", error)
  }
}

module.exports.updateData = async (event, context, callback) => {
  let data = JSON.parse(event.body)
  let updateData = await deviceModel.updateData(data)

  try {
    let response = {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        msg: "Bus data fetched successfully",
        status: 1,
        result: data
      })
    }
    callback(null, response)
  } catch (error) {
    console.log("Received MESSAGE: " + error);
    callback(null, error)
  }
}

