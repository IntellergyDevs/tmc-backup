const deviceModel = require('../models/device.model')
module.exports.add = async (event, context, callback) => {
    let response;
    try {
        let request = JSON.parse(event.body);
        console.log('event.body=====>', request);
        let result = await deviceModel.insertDeviceItem(request);
        response = {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Pi-labs device added successfully!',
                input: result,
            }),
        };
        callback(null, response);
    } catch (error) {
        response = {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Pi-labs device not added successfully!',
                input: error,
            }),
        };
        callback(null, response);
    }
}