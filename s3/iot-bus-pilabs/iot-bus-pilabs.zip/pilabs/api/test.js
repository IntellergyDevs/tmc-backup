const testAPI = require('../api/tracking')
testAPI.getAllStaticDetails()