const config = require("../../config/config.json");
const moment = require("moment");
const geolib = require("geolib");
const momenttimezone = require("moment-timezone");
const utils = require("../common/utils");
const deviceModel = require("../models/device2.model");
const exceptionEventModel = require("../models/exceptionEvent.model");
const db = require("../../config/db.sequelize");
const db1 = require("../../config/db.sequelize");
const exceptionEventDataSetModel = require("../models/exceptionEvent1.model");
var classifyPoint = require("robust-point-in-polygon");
const distanceCalc = require("../common/distanceCalculator");
const distanceHelper = require("../common/distanceCalculator");
const routeCoordinates = require("../../enums/route_coordinates");
const Stops = require('../../enums/stop');
const TripsData = require('../../models/tripsData.model');
const routeDeterminationModel = require("../../models/routeDetermination.model");
// const stopLocationsModel = require('../../models/StopLocations.model');
// const stopsLandmarksModel = require('../../models/stopsLandmarks.model');
// const stopsSurroundingStopsModel = require('../../models/stopsSurroundingStops.model');

module.exports.getAllBuses = async (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  let auth = await utils.checkAuth(event.headers, callback);

  moment.tz.setDefault(config.timeZone.africaCairo);
  let error = {};
  if (Object.keys(error).length == 0) {
    var busLocations = {};

    let query =
      "SELECT * FROM device LEFT JOIN deviceStatusInfo ON device.id = deviceStatusInfo.deviceID WHERE isActive = 1 and device.application = 'PiLab'";
    var [records, meta] = await db.query(query, {});
    records = records ? records : [];

    if (records && records[0]) {
      // let calls = [];
      // records.forEach(value => {
      //     calls.push(['Get', { typeName: 'DeviceStatusInfo', resultsLimit: 1, search: { deviceSearch: { id: value.id } } }]);
      //     busLocations[value.id] = value;
      // })
      // let myMultiCall = api.multiCall(calls);
      const idleTime = 5; //mins

      let finalResponse = records.map((value, index) => {
        console.log(value);
        let isDriving = value.isDriving;
        let duration = value.currentStateDuration;
        let durationInMins = Number(moment(duration, "hh:mm:ss").format("m"));
        let status = "";
        if (isDriving) {
          status = "running";
        }
        if (!isDriving) {
          if (durationInMins <= idleTime) {
            status = "idle";
          } else {
            status = "stopped";
          }
        }
        console.log(isDriving, duration, durationInMins, status);
        return {
          status,
          statusDuration: duration,
          latitude: Number(value.latitude),
          longitude: Number(value.longitude),
          id: value.deviceId,
          DeviceName: value.DeviceName,
        };
      });
      callback(null, {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify(
          {
            msg: "Bus data fetched successfully",
            status: 1,
            results: {
              buses: finalResponse,
            },
          },
          null,
          2
        ),
      });
    } else {
      callback(null, {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          msg: "No bus data found",
          //err: error,
          status: 0,
          results: [],
        }),
      });
    }
  } else {
    callback(null, {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        msg: "Insufficient Data provided",
        err: error,
        status: 0,
        results: [],
      }),
    });
  }
};

module.exports.getPilabBusesStatus = async (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  moment.tz.setDefault(config.timeZone.africaCairo);
  let error = {};
  if (Object.keys(error).length == 0) {
    let query =
      "SELECT * FROM device LEFT JOIN deviceStatusInfo ON device.id = deviceStatusInfo.deviceID WHERE isActive = 1 and device.application = 'PiLab'";
    var [records, meta] = await db.query(query, {});
    records = records ? records : [];

    if (records && records[0]) {
      const idleTime = 5; //mins

      let finalResponse = records.map((value, index) => {
        console.log(value);
        let isDriving = value.isDriving;
        let duration = value.currentStateDuration;
        let durationInMins = Number(moment(duration, "hh:mm:ss").format("m"));
        let status = "";
        if (isDriving) {
          status = "Running";
        }
        if (!isDriving) {
          if (durationInMins <= idleTime) {
            status = "Idling";
          } else {
            status = "Stopped";
          }
        }
        console.log(isDriving, duration, durationInMins, status);
        return {
          status,
          statusDuration: duration,
          latitude: Number(value.latitude),
          longitude: Number(value.longitude),
          id: value.deviceId,
          DeviceName: value.DeviceName,
        };
      });
      callback(null, {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify(
          {
            msg: "Bus data fetched successfully",
            status: 1,
            results: {
              buses: finalResponse,
            },
          },
          null,
          2
        ),
      });
    } else {
      callback(null, {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          msg: "No bus data found",
          //err: error,
          status: 0,
          results: [],
        }),
      });
    }
  } else {
    callback(null, {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        msg: "Insufficient Data provided",
        err: error,
        status: 0,
        results: [],
      }),
    });
  }
};

module.exports.getAllPilabsBuses = async (event, context, callback) => {
  let response;
  console.log("hi getAllbuses", config.timeZone.africaCairo);
  try {
    context.callbackWaitsForEmptyEventLoop = false;
    let auth = await utils.checkAuth(event.headers, callback);
    moment.tz.setDefault(config.timeZone.africaCairo);
    let error = {};
    console.log("hi getAllbuses");
    if (Object.keys(error).length == 0) {
      let records = await deviceModel.getAllData();
      console.log("records==============>", records);
      response = {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          msg: "Bus data fetched successfully",
          status: 1,
          results: {
            buses: records,
          },
        }),
      };
      callback(null, response);
    } else {
      response = {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          msg: "No bus data found",
          //err: error,
          status: 0,
          results: error,
        }),
      };
      callback(null, response);
    }
  } catch (error) {
    console.log("error======>", error);
    response = {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        msg: "Bus data Not fetched successfully",
        status: 0,
        error: error,
      }),
    };
    callback(null, response);
  }
};

module.exports.getAllStaticDetails = async (event, context, callback) => {
  let response;
  console.log("hi getAllStaticDetails");
  try {
    context.callbackWaitsForEmptyEventLoop = false;
    // let auth = await utils.checkAuth(event.headers, callback)
    moment.tz.setDefault(config.timeZone.africaCairo);
    let error = {};
    if (Object.keys(error).length == 0) {
      let queryforStops =
        "SELECT B.id, A.name as Landmark, B.name, A.Latitude AS landmarkLat, A.Longitude AS landmarkLong, B.Latitude AS surroundLat, B.Longitude AS surroundLong, associatedRoutes FROM stopsLandmarks A LEFT JOIN stopsSurroundingStops B ON A.id = B.landmarkId";

      // var [records, meta] = await db.query(query, {});
      // records = records ? records : [];
      let queryforFullPath =
        "SELECT id, name, colorScheme, landmarkId, Latitude, Longitude FROM stopsFullPath";

      // let busRoutes = stopLocationsModel.findAll({
      // });
      let busRoutes = await db.query("SELECT * FROM stoplocations_react", {
        nest: true,
      });
      const stopsAndLandmarks = await db.query(queryforStops, {
        nest: true,
      });
      // console.log('stopsAndLandmarks======>',stopsAndLandmarks)

      let fullPath = db.query(queryforFullPath, {
        nest: true,
      });
      // records = records ? records : [];
      var toDate = moment().format("YYYY-MM-DD");
      var fromDate = moment().add(-30, "days").format("YYYY-MM-DD");
      console.log("fromDate", fromDate);
      let getCountQuery = `SELECT DeviceId, COUNT(_id) AS count FROM exceptioneventdataset WHERE createdAt >= '${toDate}' GROUP BY DeviceId`;
      // var [getExceptionCounts, meta] = await db.query(getCountQuery, {
      //     raw: true,
      // })
      // var getExceptionCounts = await db.query(getCountQuery,{nest:true})
      var getExceptionCounts = [
        {
          DeviceId: 867035048171043,
          count: 5,
        },
        {
          DeviceId: 867035048171324,
          count: 2,
        },
      ];
      console.log("getExceptionCounts", getExceptionCounts);
      let totalExceptions = 0;
      const totalDevice = getExceptionCounts.length;
      let deviceRating = {};
      getExceptionCounts.forEach((element) => {
        totalExceptions += element.count;
        deviceRating[element.DeviceId] = element.count;
      });

      const avg = totalExceptions / totalDevice;
      const percentile = avg / 5;

      let outOf = [0, 0, 0, 0, 0];

      outOf.forEach((element, index) => {
        let num = avg - index * percentile;
        outOf[index] = num;
      });

      getExceptionCounts.forEach((element, index) => {
        let count = element.count;
        let rating = outOf.filter((elem) => count <= elem).length;
        deviceRating[element.DeviceId] = rating;
      });
      console.log(toDate, fromDate);
      await Promise.all([busRoutes, stopsAndLandmarks, fullPath]).then(
        (values) => {
          let records = values[0];
          let landmarksRaw = values[1];
          let fullPath = values[2];
          let fullPathLocation = {};

          fullPath.forEach((element) => {
            if (typeof fullPathLocation[element.name] === "undefined") {
              fullPathLocation[element.name] = [];
              // fullPathLocation[element.name]['id'] = element.name;
              // fullPathLocation[element.name]['name'] = element.name;
              // fullPathLocation[element.name]['routeCoordinates'] = [];
            }
            fullPathLocation[element.name].push({
              id: element.id,
              latitude: Number(element.Latitude),
              longitude: Number(element.Longitude),
            });
          });
          let stopLocations = {};
          records.forEach((element) => {
            if (
              typeof stopLocations[element.routeAllocationName] === "undefined"
            ) {
              stopLocations[element.routeAllocationName] = {};
              stopLocations[element.routeAllocationName]["id"] =
                element.routeAllocationName;
              stopLocations[element.routeAllocationName]["name"] =
                element.routeAllocationName;
              stopLocations[element.routeAllocationName]["routeStops"] = [];
              stopLocations[element.routeAllocationName][
                "routeCoordinates"
              ] = fullPathLocation[element.routeAllocationName]
                ? fullPathLocation[element.routeAllocationName]
                : [];
              stopLocations[element.routeAllocationName]["colorScheme"] =
                "#" + element.colorScheme;
            }
            stopLocations[element.routeAllocationName].routeStops.push({
              message: element.StopNumber,
              // colorScheme: "#" + element.colorScheme,
              id: element.id,
              longitude: Number(element.PointX),
              latitude: Number(element.PointY),
              // geometry: {
              //     coordinates: [
              //         Number(element.PointY),
              //         Number(element.PointX)
              //     ]
              // }
            });
          });
          let responseStops = [];

          Object.keys(stopLocations).forEach((element) => {
            responseStops.push(stopLocations[element]);
          });
          let landmarks = landmarksRaw
            .filter((item, index, objects) => {
              // console.log("item=====>", item);
              if (index === 0) {
                return item;
              } else if (item.Landmark !== objects[index - 1].Landmark) {
                return {
                  name: item.Landmark,
                  latitude: Number(item.landmarkLat),
                  longitude: Number(item.landmarkLong),
                  associatedRoutes: item.associatedRoutes,
                };
              }
            })
            .map(function (item) {
              return {
                name: item.Landmark,
                latitude: Number(item.landmarkLat),
                longitude: Number(item.landmarkLong),
                associatedRoutes: JSON.parse(item.associatedRoutes),
              };
            });

          let landmarksWithStops = landmarksRaw
            .filter(({ id }) => id != null)
            .map(function (item) {
              return {
                Landmark: item.Landmark,
                name: item.name,
                latitude: Number(item.surroundLat),
                longitude: Number(item.surroundLong),
              };
            })
            .reduce((r, a) => {
              r[a.Landmark] = [...(r[a.Landmark] || []), a];
              return r;
            }, {});
          let responseLandmarksStops = [];
          Object.keys(landmarksWithStops).forEach((element, key) => {
            responseLandmarksStops.push({
              id: element,
              name: element,
              routeCoordinates: landmarksWithStops[element],
            });
            // console.log(element)
          });
          responseLandmarksStops.forEach((element, index) => {
            let landmark = landmarks.filter((lm) => lm.name == element.name);

            responseLandmarksStops[index]["associatedRoutes"] =
              landmark && landmark[0] && landmark[0].associatedRoutes
                ? landmark[0].associatedRoutes
                : [];
          });

          if (records && records[0]) {
            callback(null, {
              statusCode: 200,
              headers: {
                "Content-Type": "application/json",
                "X-Frame-Options": "DENY",
                "X-Frame-Options": "DENY",
                "Access-Control-Allow-Origin": "*",
              },
              body: JSON.stringify(
                {
                  msg: "Stops and landmarks data fetched successfully",
                  status: 1,
                  results: {
                    type: "FeatureCollection",
                    // routes: {
                    //     routeStops: responseStops, //black main stops
                    //     routeCoordinates: fullPathLocation // full path trace
                    // },
                    routes: responseStops,
                    landmarks: {
                      landmarkStops: landmarks, // main station points
                      landmarkAreaCoordinates: responseLandmarksStops, // all polygon
                    },
                    deviceRating,
                    stats: {
                      totalExceptions,
                      avg,
                    },
                  },
                },
                null,
                2
              ),
            });
          } else {
            callback(null, {
              statusCode: 200,
              headers: {
                "Content-Type": "application/json",
                "X-Frame-Options": "DENY",
                "Access-Control-Allow-Origin": "*",
              },
              body: JSON.stringify({
                msg: "No data found",
                //err: error,
                status: 0,
                results: [],
              }),
            });
          }
        }
      );
    } else {
      callback(null, {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          msg: "Insufficient Data provided",
          err: error,
          status: 0,
          results: [],
        }),
      });
    }
  } catch (error) {
    console.log("error======>", error);
    response = {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        msg: "Internal Server Error",
        status: 0,
        error: error,
      }),
    };
    callback(null, response);
  }
};

module.exports.getBusExceptions = async (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  let response;
  try {
    // let auth = await utils.checkAuth(event.headers, callback)
    moment.tz.setDefault(config.timeZone.africaCairo);
    let req = event.queryStringParameters;
    let busId = req && req.busId ? req.busId : null;
    let fromDate =
      req && req.fromDate
        ? req.fromDate
        : new Date().toISOString().split("T")[0];
    let toDate =
      req && req.toDate ? req.toDate : new Date().toISOString().split("T")[0];
    let searchParam = {
      busId: busId,
      fromDate: fromDate,
      toDate: toDate,
    };
    let error = {};
    if (busId == null) {
      error["Invalid Param"] = "BusId is invalid parameter";
    }
    if (Object.keys(error).length == 0) {
      // scan data from exceptioneventdataset with filter
      let record = await exceptionEventModel.getBusExceptionData(searchParam);
      console.log("record=========>", record);
      response = {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          msg: "Bus data fetched successfully",
          status: 1,
          results: {
            exceptions: record,
          },
        }),
      };
      callback(null, response);
    } else {
      callback(null, {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          msg: "Insufficient Data provided",
          err: error,
          status: 0,
          results: [],
        }),
      });
    }
  } catch (error) {
    console.log("error pilabs/getBusExceptions", error);
    response = {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        msg: "Internal server error",
        err: error,
        status: 0,
        results: [],
      }),
    };
    callback(null, response);
  }
};

module.exports.getBusExceptions1 = async (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  let response;
  try {
    let auth = await utils.checkAuth(event.headers, callback);
    moment.tz.setDefault(config.timeZone.africaCairo);
    let req = event.queryStringParameters;
    let busId = req && req.busId ? req.busId : null;
    let fromDate =
      req && req.fromDate
        ? req.fromDate
        : new Date().toISOString().split("T")[0];
    let toDate =
      req && req.toDate ? req.toDate : new Date().toISOString().split("T")[0];
    // let searchParam = {
    //     busId: busId,
    //     fromDate: fromDate,
    //     toDate: toDate
    // }
    console.log("toDate=======>", toDate);
    let error = {};
    if (busId == null) {
      error["Invalid Param"] = "BusId is invalid parameter";
    }
    if (Object.keys(error).length == 0) {
      // scan data from exceptioneventdataset with filter
      let query = `SELECT *  FROM exceptioneventdataset WHERE ActiveFrom >= '${fromDate}' AND DeviceId = '${busId}'`;
      let records = await db.query(query, { nest: true });
      // let records = await exceptionEventDataSetModel.findAll({
      //     where: {
      //         DeviceId:`${busId}`,
      //         ActiveFrom: `${fromDate}`,
      //     },
      //     raw: true
      // })
      let event = [];
      console.log("records=========>", records);
      records.forEach((value) => {
        console.log("value======>", value, value["ActiveFrom"]);
        event.push({
          activeFrom: moment(value["ActiveFrom"])
            .tz(config.timeZone.africaCairo)
            .format(config.dateFormat.powerBi),
          activeTo: moment(value["ActiveTo"])
            .tz(config.timeZone.africaCairo)
            .format(config.dateFormat.powerBi),
          distance: value.Distance,
          duration: value.Duration,
          rule: {
            id: value.RuleId,
            name: value.RuleName,
          },
          device: {
            id: value.DeviceId,
          },
          diagnostic: "",
          driver: "",
          version: "",
          id: value._id,
        });
      });
      response = {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          msg: "Bus data fetched successfully",
          status: 1,
          results: {
            exceptions: event,
          },
        }),
      };
      callback(null, response);
    } else {
      callback(null, {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          msg: "Insufficient Data provided",
          err: error,
          status: 0,
          results: [],
        }),
      });
    }
  } catch (error) {
    console.log("error pilabs/getBusExceptions", error);
    response = {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        msg: "Internal server error",
        err: error,
        status: 0,
        results: [],
      }),
    };
    callback(null, response);
  }
};
module.exports.getBusLocationTrace1 = async (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  let auth = await utils.checkAuth(event.headers, callback);
  moment.tz.setDefault(config.timeZone.africaCairo);
  let req = event.queryStringParameters;
  console.log("HI getBusLocationTrace");
  let busId = req && req.busId ? req.busId : null;
  let fromDate = req && req.fromDate ? req.fromDate : new Date().toISOString();
  let toDate = req && req.toDate ? req.toDate : new Date().toISOString();
  // const GeotabApi = require('mg-api-js');
  // const authentication = {
  //     credentials: {
  //         database: config.geotab.database,
  //         userName: config.geotab.email,
  //         password: config.geotab.password,
  //     }
  // }
  // const api = new GeotabApi(authentication);
  let response;
  try {
    if (busId == null) {
      throw new Error("BusId is invalid parameter");
    }
    // Total Distance covered by bus

    let queryAvgSpeed = `SELECT AVG(AverageSpeed) AS AverageSpeed FROM tripdataset WHERE DeviceId = '${busId}' AND StartDateTime >= '${fromDate}' AND StartDateTime <= '${toDate}'`;
    let queryFuelUsed = `SELECT Data AS FuelUsed FROM fuelusagedataset WHERE DeviceId = '${busId}' AND DateTime >= '${fromDate}' AND DateTime <= '${toDate}' ORDER BY FuelUsed ASC`;
    let queryIdlingTime = `SELECT SUM( Duration ) AS IdlingDuration FROM exceptioneventdataset WHERE DeviceId = 'bC' AND RuleId = 'RuleIdlingId' AND ActiveFrom >= '${fromDate}' AND ActiveFrom <= '${toDate}'`;
    let totalTripQ = `SELECT DeviceId, COUNT(DeviceId) AS toalTrips FROM tripdataset WHERE DeviceId = '${busId}' AND StartDateTime >= '${fromDate}' AND StopDateTime <= '${toDate}' GROUP BY DeviceId`;
    // var [BustotalDistance, meta] = await db.query(queryTotalDis, {});
    var [BusAvgSpeed, meta] = await db.query(queryAvgSpeed, {});
    var [BusFuelUsed, meta] = await db.query(queryFuelUsed, {});
    var [BusIdlingTime, meta] = await db.query(queryIdlingTime, {});
    var [totalTrip, meta] = await db.query(totalTripQ, {});
    let totalDistanceTravelled = 0;
    // BustotalDistance = BustotalDistance[0] ? BustotalDistance[0] : []

    BusAvgSpeed = BusAvgSpeed[0] ? BusAvgSpeed[0].AverageSpeed : "";
    // BusFuelUsed = BusFuelUsed[0] ? BusFuelUsed[0].FuelUsed : ''
    BusIdlingTime = BusIdlingTime[0] ? BusIdlingTime[0].IdlingDuration : "";
    totalTrip = totalTrip[0] ? totalTrip[0] : [];
    let calls = [
      [
        "Get",
        {
          typeName: "LogRecord",
          search: {
            fromDate: fromDate,
            ToDate: toDate,
            deviceSearch: { id: busId },
          },
        },
      ],
      [
        "Get",
        {
          typeName: "StatusData",
          search: {
            fromDate: fromDate,
            ToDate: toDate,
            deviceSearch: { id: busId },
            diagnosticSearch: {
              id: "DiagnosticOdometerId",
            },
          },
        },
      ],
    ];
    console.time("test");
    await api
      .multiCall(calls)
      .then((data) => {
        let BustotalDistance = data[1];
        console.log(BustotalDistance.length);
        if (BustotalDistance.length > 1) {
          let first = BustotalDistance[0].data;
          let last = BustotalDistance[BustotalDistance.length - 1].data;
          console.log(first, last);
          totalDistanceTravelled = last - first;
        }

        console.timeEnd("test");
        let totalRecords = Math.floor(data[0].length / 100);
        let tracedRecords = [];
        if (totalRecords >= 2) {
          // trim records
          data[0].forEach((val, key) => {
            if (key % totalRecords == 0) {
              tracedRecords.push({
                ...val,
                // "dateTime_utc": val.dateTime,
                dateTime: moment(val.dateTime)
                  .tz(config.timeZone.africaCairo)
                  .format(config.dateFormat.powerBi),
              });
            }
          });
        } else {
          data[0].forEach((val, key) => {
            tracedRecords.push({
              ...val,
              // "dateTime_utc": val.dateTime,
              dateTime: moment(val.dateTime)
                .tz(config.timeZone.africaCairo)
                .format(config.dateFormat.powerBi),
            });
          });
        }

        let fuelUsed = 0;
        if (BusFuelUsed.length >= 2) {
          fuelUsed =
            BusFuelUsed[BusFuelUsed.length - 1].FuelUsed -
            BusFuelUsed[0].FuelUsed;
        }
        callback(null, {
          statusCode: 200,
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
          body: JSON.stringify(
            {
              msg: "Bus exceptions data fetched successfully",
              status: 1,
              results: {
                trace: tracedRecords,
                info: {
                  0: data[0].length,
                  1: totalRecords,
                },
                otherDetails: {
                  BustotalDistance: Number(totalDistanceTravelled / 1000),
                  BusAvgSpeed: BusAvgSpeed != null ? BusAvgSpeed : 0,
                  BusFuelUsed: fuelUsed,
                  BusIdlingTime,
                  totalTrips:
                    totalTrip && totalTrip.toalTrips ? totalTrip.toalTrips : 0,
                },
              },
            },
            null,
            2
          ),
        });
      })
      .catch((error) => {
        let err = "An internal server error occured";
        console.log(error);
        if (error.message && errorMessages[error.message]) {
          err = errorMessages[error.message];
        } else {
          err = error.message;
        }
        callback(null, {
          statusCode: 200,
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
          body: JSON.stringify({
            msg: err, //error.message ? error.message : "An internal server error occured",
            //err: error,
            status: 0,
            results: [],
          }),
        });
      });

    // response = {
    //     statusCode: 200,
    //     headers: {
    //         'Content-Type': 'application/json',
    //         'Access-Control-Allow-Origin': '*'
    //     },
    //     body: JSON.stringify({
    //         msg: "Bus exceptions data fetched successfully",
    //         status: 1,
    //         results: {
    //             trace: [
    //                 {
    //                     "latitude": -25.7544193,
    //                     "longitude": 28.1614857,
    //                     "speed": 0,
    //                     "dateTime": "2021-11-07 08:09:28",
    //                     "device": {
    //                         "id": "b6"
    //                     },
    //                     "id": null
    //                 },
    //                 {
    //                     "latitude": -25.7543945,
    //                     "longitude": 28.1614857,
    //                     "speed": 0,
    //                     "dateTime": "2021-11-12 16:29:49",
    //                     "device": {
    //                         "id": "b6"
    //                     },
    //                     "id": "b8A226E"
    //                 },
    //             ],
    //             info: {
    //                 0: 3888,
    //                 1: 38
    //             },
    //             otherDetails: {
    //                 "BustotalDistance": 127.4,
    //                 "BusAvgSpeed": 15.607486565907797,
    //                 "BusFuelUsed": 0,
    //                 "BusIdlingTime": 143.37639951705933,
    //                 "totalTrips": 2
    //                 // BustotalDistance: Number(totalDistanceTravelled / 1000),
    //                 // BusAvgSpeed: BusAvgSpeed != null ? BusAvgSpeed : 0,
    //                 // BusFuelUsed: fuelUsed,
    //                 // BusIdlingTime,
    //                 // totalTrips: totalTrip && totalTrip.toalTrips ? totalTrip.toalTrips : 0
    //             }
    //         }

    //     })

    // }
    // callback(null,response)
  } catch (err) {
    callback(null, {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        msg: err.message ? err.message : "An Internal server error occured",
        status: 0,
        results: [],
      }),
    });
  }
};

module.exports.getBusLocationTrace = async (event, context, callback) => {
  try {
    context.callbackWaitsForEmptyEventLoop = false;
    //let auth = await utils.checkAuth(event.headers, callback);

    moment.tz.setDefault(config.timeZone.africaCairo);
    let req = event.queryStringParameters;

    let busId = req && req.busId ? req.busId : null;
    let fromDate = req && req.fromDate ? req.fromDate : new Date().toISOString();
    let toDate = req && req.toDate ? req.toDate : new Date().toISOString();
    fromDate = fromDate.split('T')[0];
    toDate = toDate.split('T')[0];
    
    console.log(fromDate, toDate);  

    if (busId == null) {
      throw new Error("BusId is invalid parameter");
    }
    let queryAvgSpeed = `SELECT AVG(AverageSpeed) AS AverageSpeed FROM tripdataset WHERE DeviceId = '${busId}' AND StartDateTime >= '${fromDate}' AND StartDateTime <= '${toDate}'`;
    //let queryFuelUsed = `SELECT Data AS FuelUsed FROM fuelusagedataset WHERE DeviceId = '${busId}' AND DateTime >= '${fromDate}' AND DateTime <= '${toDate}' ORDER BY FuelUsed ASC`;
    let queryIdlingTime = `SELECT SUM( Duration ) AS IdlingDuration FROM exceptioneventdataset WHERE DeviceId = '${busId}' AND RuleId = 'RuleFleetIdlingId' AND ActiveFrom >= '${fromDate}' AND ActiveFrom <= '${toDate}'`;
    let totalTripQ = `SELECT DeviceId, COUNT(DeviceId) AS toalTrips FROM tripdataset WHERE DeviceId = '${busId}' AND StartDateTime >= '${fromDate}' AND StopDateTime <= '${toDate}' GROUP BY DeviceId`;
    let queryTotalDis = `SELECT SUM(Distance) AS totalDistance FROM tripdataset WHERE DeviceId = '${busId}' AND StartDateTime >= '${fromDate}' AND StartDateTime <= '${toDate}'`;
    var [BustotalDistance, meta] = await db.query(queryTotalDis, {});
    var [BusAvgSpeed, meta] = await db.query(queryAvgSpeed, {});
    //var [BusFuelUsed, meta] = await db.query(queryFuelUsed, {});
    var [BusIdlingTime, meta] = await db.query(queryIdlingTime, {});
    var [totalTrip, meta] = await db.query(totalTripQ, {});
    
    BustotalDistance = BustotalDistance[0] ? BustotalDistance[0].totalDistance : "";
    BusAvgSpeed = BusAvgSpeed[0] ? BusAvgSpeed[0].AverageSpeed : "";
    // BusFuelUsed = BusFuelUsed[0] ? BusFuelUsed[0].FuelUsed : ''
    BusIdlingTime = BusIdlingTime[0] ? BusIdlingTime[0].IdlingDuration : "";
    totalTrip = totalTrip[0] ? totalTrip[0] : [];
    response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            msg: "Bus data fetched successfully",
            status: 1,
            results: {
                trace: [],
                info: {},
                otherDetails: {
                    // "BustotalDistance": 127.4,
                    // "BusAvgSpeed": 15.607486565907797,
                    // "BusFuelUsed": 0,
                    // "BusIdlingTime": 143.37639951705933,
                    // "totalTrips": 2
                    BustotalDistance: Number(BustotalDistance),
                    BusAvgSpeed: BusAvgSpeed != null ? BusAvgSpeed : 0,
                    BusFuelUsed: 0,
                    BusIdlingTime,
                    totalTrips: totalTrip && totalTrip.toalTrips ? totalTrip.toalTrips : 0
                }
            }

        })

    }
    callback(null,response)
  } catch (error) {
    callback(null, {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        msg: error.message ? error.message : "An Internal server error occured",
        status: 0,
        results: [],
      }),
    });
  }
};

module.exports.getAllTrip = async (event, context, callback) => {
  try {
    console.log("hi getAllTrips");
  } catch (error) {
    console.log(error);
  }
};

module.exports.getAllStaticDetails1 = async (event, context, callback) => {
  try {
    context.callbackWaitsForEmptyEventLoop = false;
    // let auth = await utils.checkAuth(event.headers, callback)
    let error = {};
    if (Object.keys(error).length == 0) {
      let queryforStops =
        "SELECT B.id, A.name as Landmark, B.name, A.Latitude AS landmarkLat, A.Longitude AS landmarkLong, B.Latitude AS surroundLat, B.Longitude AS surroundLong, associatedRoutes FROM stopsLandmarks A LEFT JOIN stopsSurroundingStops B ON A.id = B.landmarkId";
      let queryforFullPath =
        "SELECT id, name, colorScheme, landmarkId, Latitude, Longitude FROM stopsFullPath";
      let busRoutes = db.query("SELECT * FROM stoplocations_react", {
        nest: true,
      });
      const stopsAndLandmarks = await db.query(queryforStops, {
        nest: true,
      });
      console.log("stopsAndLandmarks======>", stopsAndLandmarks);
      let fullPath = await db.query(queryforFullPath, {
        nest: true,
      });
      // console.log('fullPath======>',fullPath)
    }
  } catch (error) {
    console.log("error=======>", error);
  }
};

function getRoutesFromLocation(location) {
  if (location == "marlboro") {
    return [
      "Greenstone",
      "Linbro Business Park",
      "Woodlands Office Park",
      "Buccleuch",
      "Kelvin",
    ];
  } else if (location == "centurion") {
    return ["Midstream", "Highveld"];
  } else {
    return ["Queenswood"];
  }
}

function getNextStops(stops, pastList){
    return [...stops].filter(e => !pastList.includes(e.sequence) || !pastList.includes(e.sequence));
}
 
function getDistance1(obj){
    return (obj.distanceMeters / 1000);
}

function getEndDistance(obj){
  return (obj.distanceFromStation / 1000);
}

async function findDistance(lat,long,lat1, long1){
    const d = await distanceHelper.distanceBetweenTwoPoints(
        lat,
        long,
        lat1,
        long1,
        "K"
    );
    return d;
}
async function countETA(stops, device, speed, distanceArr){
    console.log(distanceArr);
    for (let index in stops) {
        let distance = await findDistance(device.latitude, device.longitude, stops[0].PointY, stops[0].PointX);
        if(index > 0){
            const countIndex = stops[0].sequence;
            let _distance = 0;
            //for(let i = index; i > 0; i--) {
            for(let i = 0; i < index; i++) {    
                let _d = getDistance(distanceArr[countIndex + i]);
                //let _d = await findDistance(stops[i].PointY, stops[i].PointX, stops[i-1].PointY, stops[i-1].PointX);
                _distance = _distance + _d;
            }
            distance = distance + _distance;
        }
        const durationInSecs = distance / speed;
        const duration = distanceCalc.secondsToHms(durationInSecs * 3600); //secs
        stops[index]["eta"] = {
            currentTime: moment().format("HH:mm"),
            text: duration,
            timestamp: moment().add(Number(durationInSecs * 3600), 'seconds').unix(),
            time: moment().add(Number(durationInSecs * 3600), 'seconds').utcOffset('+0200').format('h:mm A'),
            seconds: Number(durationInSecs * 3600).toFixed(2)
        };
      }
      return stops;
}

module.exports.getTripETA = async (event, context, callback) => {
  try{
    const location = event.queryStringParameters.location;
    let routes = getRoutesFromLocation(location);
    let routesStopsUser = routes.map(id => "'" + id + "'").join()
    let getDeviceInfoQuery = `select * from deviceStatusInfo join device on deviceStatusInfo.deviceId=device.id join routeDetermination on deviceStatusInfo.deviceId=routeDetermination.deviceId where device.application='PiLab' and routeDetermination.currentRouteDetermined IN (${routesStopsUser});`;
    const activeDevice = await db.query(getDeviceInfoQuery, {
      nest: true
    });
    const distanceToStops = await db.query(`SELECT start, end, routeAllocationName,distanceMeters, distanceFromStation FROM trainGraphLocations_new where transportType = 2`, {
        nest: true
    });
    let result = [];
    for(let device of activeDevice){
        // Get recent detail of device
        let trackDevice = await db.query(
            "SELECT * FROM logrecorddataset where DeviceId = 867035048170698 order by id desc limit 1;",
            {
            nest: true,
            }
        );
        let routeName = '';
        const speed = trackDevice[0].Speed <= 0 ? 20 : trackDevice[0].Speed;

        if(device.currentRouteDetermined){
            routeName = device.currentRouteDetermined;
        } else {
            routeName = trackDevice[0].routeAllocationName != null && trackDevice[0].routeAllocationName != '' ? trackDevice[0].routeAllocationName : findBusRoute(device);
        }
        if(routeName){
           let distanceArr = [...distanceToStops].filter(x => x.routeAllocationName == routeName);
           let stops = await GetAllStops(routeName);
           let nextStops = getNextStops(stops, JSON.parse(device.pastList));
           console.log(nextStops, 'nextStops');
           // count ETA for remaining stops
           let res = await countETA(nextStops, device, speed, distanceArr);
           result.push({
               deviceId: device.deviceId,
               nextstops: res
           });
        }
    }
    // RESPONSE
    callback(null, {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          msg: "ETA success",
          results: result,
        }),
      });
    } catch(err){
      console.log(err);
  }
  
};

module.exports.determineRoute = async (event, context, callback) => {
  try {
    // Get device info
    let deviceInfo = await db.query(
      "select * from deviceStatusInfo join device on deviceStatusInfo.deviceId=device.id where device.application='PiLab' and  deviceStatusInfo.isDriving=1;",
      {
        nest: true,
      }
    );
    let stopsFullPaths = await db.query("SELECT * FROM stopsFullPath", {
      nest: true,
    });
    //retrieving location coordinates from fullPath array
    let onlyCoords = stopsFullPaths.map((rec) => {
      return {
        latitude: rec.Latitude,
        longitude: rec.Longitude,
      };
    });
    activeDeviceRecords = [];
    for (let device of deviceInfo) {
      let dlog = await db.query(
        `SELECT * FROM logrecorddataset where DeviceId = ${device.deviceId} order by id desc limit 1;`,
        {
          nest: true,
        }
      );
      if (dlog && dlog.length > 0) {
        let obj = {
          deviceId: device.id,
          speed: dlog[0].Speed,
          lat:-26.0824821681754,
          long:28.1012925695727,
          //   lat:-26.0770828215371, //device.latitude
          //   long:28.0988191270921, //device.longitude
          //   lat: -26.07757,
          //   long: 28.09781,
          // lat: device.latitude,
          // long: device.longitude,
          isDriving: device.isDriving,
          status: device.status,
          isDeviceCommunicating: device.isDeviceCommunicating,
        };
        activeDeviceRecords.push(obj);
      }
    }

    let insertRecords = [];
    for (let ar of activeDeviceRecords) {
      // bus route
      let routeName = findBusRoute(ar);
      // find stops
      let stops = await GetAllStops(routeName);
      // found nearest stop
      let currentStation = "";
      const currentStationIndex = IsBusInStation(stops, ar.lat, ar.long);
      let busTracking = await db.query(
        `SELECT * FROM routeDetermination WHERE deviceId=${ar.deviceId}`,
        {
          nest: true,
        }
      );
      let pastStops = JSON.parse(busTracking[0].pastList);
      if (currentStationIndex !== -1) {
        // bus is in stop
        currentStation = stops[currentStationIndex].StopNumber;
        for(let i=1; i<=stops[currentStationIndex].sequence; i++){
          pastStops.push(i);
        }
      } else {
        // bus is not in stop
        if(pastList.lengh == 0){
          // save data
          let prevRecord = await TripsData.findOne({
            where: {
                DeviceId: location.deviceId
            },
            order: [['id', 'DESC']],
            raw: true
          });
          if(prevRecord){


          } else {
            await TripsData.create({
              DeviceName: ar.deviceName,
              DeviceId: ar.deviceId,
              isDriving: ar.isDriving,
              isCompleted: 0,
              busStation: '',
              detectedRoute: routeName,
              checkpoint: `[${ar.lat}, ${ar.long}]`
            });
          }
        }

      }
      insertRecords.push({
        deviceId: ar.deviceId,
        totalCountables: "{}",
        currentRouteDetermined: routeName,
        isBusInStation: currentStationIndex > -1,
        updatedAt: new Date(),
        pastList: JSON.stringify([...new Set(pastStops)]),
        isRouteReset: 0,
        currentStation: currentStation,
      });
    }
    if (insertRecords.length > 0) {
      let p = await updateRouteDetermination(insertRecords);
      if(p){
        callback(null, {
          statusCode: 200,
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
          body: JSON.stringify({
            msg: "Records updated success"
          }),
        });
      } else {
        callback(null, {
          statusCode: 404,
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
          },
          body: JSON.stringify({
            msg: "failed"
          }),
        });
      }
    }
  } catch (error) {
    console.log(error, "error");
  }
};

async function updateRouteDetermination(insertRecords) {
  //updating/inserting data into routeDetermination table
  let res =  await routeDeterminationModel
    .bulkCreate(insertRecords, {
      updateOnDuplicate: [
        "totalCountables",
        "currentRouteDetermined",
        "updatedAt",
        "isBusInStation",
        "pastList",
        "isRouteReset",
        "currentStation",
      ],
    });
    return res;
}

async function GetAllStops(routeName) {
  let stops = await db.query(
    `SELECT id, routeAllocationName,StopNumber, PointX, PointY,sequence FROM stoplocations_react WHERE include = 1 and routeAllocationName = '${routeName}' Order By sequence ASC`,
    {
      nest: true,
    }
  );
  return stops;
}

function findBusRoute(data) {
  const boundaries = routeCoordinates;
  let routeName = "";
  for (let boundary of boundaries) {
    let isInPolygon = geolib.isPointInPolygon(
      { longitude: data.long, latitude: data.lat },
      boundary.coordinates
    );
    if (isInPolygon) {
      routeName = boundary.name;
      break;
    }
  }
  return routeName;
}

function IsBusInStation(stops, lat, long) {
  // TODO: if bus location is 100m distance from stop location then bus is in station as GPS has glitch
  return stops.findIndex((stop) => stop.PointY == lat && stop.PointX == long);
}

function findStationAndRoute (location) {
  let stationArr = ['CENTURION', 'HATFIELD', 'MARLBORO'];
  let stationName = null;
  let isInsideBox;
  let detectedRoute = null;
  for(let station of stationArr){
    let routeCoordinatesObj = routeCoordinates[station] ? routeCoordinates[station] : null;
    if (routeCoordinatesObj) {
        for (let [key, value] of Object.entries(routeCoordinatesObj)) {
            isInsideBox = geolib.isPointInPolygon(
                {
                    latitude: location.latitude,
                    longitude: location.longitude,
                },
                value
            );
            if (isInsideBox) {
                detectedRoute = key;
                break;
            }
        }
      if(detectedRoute){
        stationName = station;
        break;
      }  
    }
   }
    return {
      isInsideBox, stationName, detectedRoute
    }
}

function isBusInStation(Boundary, location){
  let stationName = null;
  let isBusInsideBusStand = true;
  for(let boundryObj of Boundary){
    isBusInsideBusStand = geolib.isPointInPolygon(
      {
          latitude: location.latitude,
          longitude: location.longitude,
      },
      boundryObj.stationBoundary
    );
    if(isBusInsideBusStand) {
      stationName = boundryObj.name;
      break;
    }
  }
  return {
    isBusInsideBusStand, stationName
  }
}

async function getLastTrip(deviceId){

  let lastTrip = await TripsData.findOne({
    where: {
        DeviceId: deviceId
    },
    order: [['id', 'DESC']],
    raw: true
  });
  return lastTrip;
}

module.exports.determineRouteNew = async (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  const routeDeterminationModel = require('../../models/routeDetermination.model');
  const CompletedTripsModel = require('../../models/CompletedTrips.model');
  const geolib = require('geolib');

  try {
      const currentHour = moment().format('H');
      let reset = false;

      // If the current time is 5AM reset the route
      if (currentHour == 5) {
          reset = true;
      }

      let stopsFullQuery = "SELECT * FROM stopsFullPath";
      const p1 = db.query(stopsFullQuery, {});

      let busLocationQuery = `SELECT currentStation,latitude,longitude,isDriving,routeDetermination.totalCountables as totalCountables,routeDetermination.isRouteReset AS isRouteReset, routeDetermination.isBusInStation AS isBusInStation,routeDetermination.deviceName AS deviceName, routeDetermination.pastList AS pastList,currentRouteDetermined, routeDetermination.deviceId FROM deviceStatusInfo LEFT JOIN routeDetermination ON deviceStatusInfo.deviceId = routeDetermination.deviceId LEFT JOIN device ON device.id=deviceStatusInfo.deviceId where device.application='PiLab'`;
      const p2 = db.query(busLocationQuery, {});

      let routeQuery = "SELECT * FROM routeDetermination";
      const p3 = db.query(routeQuery, {});

      let getBoundary = `SELECT name, stationBoundary, associatedRoutes FROM stopsLandmarks WHERE type = 'bus'`;
      const p4 = db.query(getBoundary, {
          raw: true,
      })

      let getPolygonsQuery = `SELECT name, landmarkId,Latitude AS latitude,Longitude AS longitude FROM stopsSurroundingStops`;
      const p5 = db.query(getPolygonsQuery, {
          raw: true,
      })

      let getStopsForStationQuery = `SELECT id, routeAllocationName,StopNumber, PointX, PointY,sequence FROM stoplocations_react WHERE include = 1`;
      const p6 = db.query(getStopsForStationQuery, {
          raw: true,
      });

      let completedTripsQuery = `SELECT * FROM completedTrips WHERE date >= '${moment().format('YYYY-MM-DD')} 00:00:00'`;
      const p7 = db.query(completedTripsQuery, {
          raw: true,
      });

      let stopsObj = {};
      await Promise.all([p1, p2, p3, p4, p5, p6, p7]).then(async (values) => {
          let fullPath = values[0][0];
          let busLocations = values[1][0];
          let currentRoute = values[2][0];
          let Boundary = values[3][0];
          let polygons = values[4][0];
          let stops = values[5][0];
          let isEntryCompleted = values[6][0].length == 0 ? false : true;
          let completedRecord = values[6][0];
          let completedTrips = {
              date: moment().utc().format('YYYY-MM-DD')
          };
          const polygonSorted = {};

          //inserting polygons into polygonSorted object
          for (let element of polygons) {
              if (!polygonSorted[element.name]) {
                  polygonSorted[element.name] = [];
              }
              polygonSorted[element.name].push({
                  ...element
              });
          }

          // inserting stops into stopsObj variable
          for (let element of stops) {
              if (!stopsObj[element.routeAllocationName]) {
                  stopsObj[element.routeAllocationName] = {}
                  stopsObj[element.routeAllocationName]['stops'] = []
              }
              stopsObj[element.routeAllocationName]['stops'].push({
                  StopName: element.routeAllocationName,
                  StopNumber: element.StopNumber,
                  latitude: element.PointY,
                  longitude: element.PointX,
                  sequence: element.sequence,
              })
          }

          // converting text data type to json data type
          Boundary.forEach((element, index) => {
              Boundary[index]['associatedRoutes'] = JSON.parse(element.associatedRoutes)
              Boundary[index]['stationBoundary'] = JSON.parse(element.stationBoundary)
          });

          let boundariesOnlyCords = {};
          Boundary.forEach((boundaryElement, index) => {
              if (!boundariesOnlyCords[boundaryElement.name]) {
                  boundariesOnlyCords[boundaryElement.name] = {};
              }
              boundariesOnlyCords[boundaryElement.name]['stationBoundary'] = boundaryElement.stationBoundary;
              boundariesOnlyCords[boundaryElement.name]['associatedRoutes'] = boundaryElement.associatedRoutes;
          });

          //retrieving location coordinates from fullPath array
          let onlyCoords = fullPath.map(rec => {
              return {
                  latitude: rec.Latitude,
                  longitude: rec.Longitude,
              }
          });

          //insert data into shortestDistance variable and calculating nearest lat lng using geolib library
          let shortestDistance = {};
          for (let location of busLocations) {
              let shortest = geolib.findNearest({ latitude: (location.latitude), longitude: (location.longitude) }, onlyCoords);

              shortestDistance[location.deviceId] = {};
              shortestDistance[location.deviceId]['location'] = shortest;
              shortestDistance[location.deviceId]['isRouteReset'] = location.isRouteReset;
              shortestDistance[location.deviceId]['deviceName'] = location.deviceName;
              shortestDistance[location.deviceId]['pastList'] = JSON.parse(location.pastList);
              shortestDistance[location.deviceId]['longitude'] = location.longitude;
              shortestDistance[location.deviceId]['latitude'] = location.latitude;
              shortestDistance[location.deviceId]['currentStation'] = location.currentStation;
              shortestDistance[location.deviceId]['isDriving'] = location.isDriving;
              shortestDistance[location.deviceId]['totalCountables'] = JSON.parse(location.totalCountables);
              shortestDistance[location.deviceId]['stops'] = [];
              shortestDistance[location.deviceId]['detectedRoute'] = null;
              shortestDistance[location.deviceId]['busStation'] = null;
              shortestDistance[location.deviceId]['isBusInsideBusStand'] = 1;
              shortestDistance[location.deviceId]['lastTripRoute'] = location.currentRouteDetermined ? location.currentRouteDetermined : null;
              // Detecting current route                
              //check if bus is driving
              let isBusInsideBusStand = true;
              if (location.isDriving == 1) {
                  // Check bus is inside bus station 
                  let res  = isBusInStation(Boundary, location);
                  isBusInsideBusStand = res.isBusInsideBusStand;
                  let stationName = res.stationName;

                  //if bus is not at bus stand
                  if (!isBusInsideBusStand) {
                      
                      let lastTrip = await getLastTrip(location.deviceId);

                      if (lastTrip) {
                          if (lastTrip.isCompleted == 1) {
                              //create new entry
                              let res = findStationAndRoute(location);
                              let isInsideBox = res.isInsideBox;
                              let stationName = res.stationName;
                              let detectedRoute = res.detectedRoute;
                                
                              
                              shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute ? detectedRoute : null;
                              shortestDistance[location.deviceId]['busStation'] = stationName;
                              
                              await TripsData.create({
                                  DeviceName: location.deviceName,
                                  DeviceId: location.deviceId,
                                  isDriving: location.isDriving,
                                  isCompleted: 0,
                                  busStation: stationName,
                                  detectedRoute: detectedRoute ? detectedRoute : null,
                                  checkpoint: `[${location.latitude}, ${location.longitude}]`
                              });
                          }
                          else {
                              //check if route was detected already
                              if (lastTrip.detectedRoute) {
                                  // let res = findStationAndRoute(location);
                                  // let isInsideBox = res.isInsideBox;
                                  // let stationName = res.stationName;
                                  // let detectedRoute = res.detectedRoute;
                                  // if(detectedRoute != null && detectedRoute != lastTrip.detectedRoute){
                                  //   shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute;
                                  //   shortestDistance[location.deviceId]['busStation'] = stationName;
                                  // } else {
                                  //   shortestDistance[location.deviceId]['detectedRoute'] = lastTrip.detectedRoute;
                                  //   shortestDistance[location.deviceId]['busStation'] = lastTrip.busStation;
                                  // }
                                  shortestDistance[location.deviceId]['detectedRoute'] = lastTrip.detectedRoute;
                                  shortestDistance[location.deviceId]['busStation'] = lastTrip.busStation;
                              }
                              else {
                                  //check if bus is inside BOX and update old last entry
                                  let res = findStationAndRoute(location);
                                  let isInsideBox = res.isInsideBox;
                                  let stationName = res.stationName;
                                  let detectedRoute = res.detectedRoute;

                                  shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute ? detectedRoute : null;
                                  shortestDistance[location.deviceId]['busStation'] = stationName;
                                  //update table raw with the same
                                  await TripsData.update(
                                    {
                                        detectedRoute: shortestDistance[location.deviceId]['detectedRoute'],
                                        busStation: shortestDistance[location.deviceId]['busStation'],
                                        isDriving: location.isDriving,
                                        checkpoint: `[${location.latitude}, ${location.longitude}]`
                                    },
                                    {
                                        where: {
                                            id: lastTrip.id
                                        }
                                    }
                                  );
                                }
                            }
                      }
                      else {
                          //create new entry
                          let res = findStationAndRoute(location);
                          let isInsideBox = res.isInsideBox;
                          let stationName = res.stationName;
                          let detectedRoute = res.detectedRoute;
                          
                          shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute ? detectedRoute : null;
                          shortestDistance[location.deviceId]['busStation'] = stationName;
                          await TripsData.create({
                              DeviceName: location.deviceName,
                              DeviceId: location.deviceId,
                              isDriving: location.isDriving,
                              isCompleted: 0,
                              busStation: stationName,
                              detectedRoute: detectedRoute ? detectedRoute : null,
                              checkpoint: `[${location.latitude}, ${location.longitude}]`
                          });
                      }
                  }
                  else {
                      
                      shortestDistance[location.deviceId]['detectedRoute'] = null;
                      shortestDistance[location.deviceId]['busStation'] = stationName;
                  }
              }
              else {
                  //bus is not driving
                  //check if bus is stopped outside bus station
                  let res  = isBusInStation(Boundary, location);
                  isBusInsideBusStand = res.isBusInsideBusStand;
                  let stationName = res.stationName;
                  
                  //if bus is not at bus stand
                  if (!isBusInsideBusStand) {
                      let lastTrip = await getLastTrip(location.deviceId);
                      if (lastTrip) {
                          if (lastTrip.isCompleted == 1) {
                              //create new entry
                              let res = findStationAndRoute(location);
                              let isInsideBox = res.isInsideBox;
                              let stationName = res.stationName;
                              let detectedRoute = res.detectedRoute;
                              
                              shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute ? detectedRoute : null;
                              shortestDistance[location.deviceId]['busStation'] = stationName;
                              await TripsData.create({
                                  DeviceName: location.deviceName,
                                  DeviceId: location.deviceId,
                                  isDriving: location.isDriving,
                                  isCompleted: 0,
                                  busStation: stationName,
                                  detectedRoute: detectedRoute ? detectedRoute : null,
                                  checkpoint: `[${location.latitude}, ${location.longitude}]`
                              });
                          }
                          else {
                              //check if route was detected already
                              if (lastTrip.detectedRoute) {
                                // let res = findStationAndRoute(location);
                                // let isInsideBox = res.isInsideBox;
                                // let stationName = res.stationName;
                                // let detectedRoute = res.detectedRoute;
                                // if(detectedRoute != null && detectedRoute != lastTrip.detectedRoute){
                                //   shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute;
                                //   shortestDistance[location.deviceId]['busStation'] = stationName;
                                // } else {
                                  
                                // }
                                shortestDistance[location.deviceId]['detectedRoute'] = lastTrip.detectedRoute;
                                shortestDistance[location.deviceId]['busStation'] = lastTrip.busStation;
                              }
                              else {
                                  //check if bus is inside BOX and update old last entry
                                  let res = findStationAndRoute(location);
                                  let isInsideBox = res.isInsideBox;
                                  let stationName = res.stationName;
                                  let detectedRoute = res.detectedRoute;
                                  
                                  shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute ? detectedRoute : null;
                                  shortestDistance[location.deviceId]['busStation'] = stationName;
                                  await TripsData.update(
                                    {
                                      detectedRoute: shortestDistance[location.deviceId]['detectedRoute'],
                                      busStation: shortestDistance[location.deviceId]['busStation'],
                                      isDriving: location.isDriving,
                                      checkpoint: `[${location.latitude}, ${location.longitude}]`
                                    },
                                    {
                                      where: {
                                        id: lastTrip.id
                                      }
                                    }
                                  ); 
                                }
                          }
                      }
                      else {
                          //create new entry
                          let res = findStationAndRoute(location);
                          let isInsideBox = res.isInsideBox;
                          let stationName = res.stationName;
                          let detectedRoute = res.detectedRoute;
                          
                          shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute ? detectedRoute : null;
                          shortestDistance[location.deviceId]['busStation'] = stationName;
                          await TripsData.create({
                              DeviceName: location.deviceName,
                              DeviceId: location.deviceId,
                              isDriving: location.isDriving,
                              isCompleted: 0,
                              busStation: stationName,
                              detectedRoute: detectedRoute ? detectedRoute : null,
                              checkpoint: `[${location.latitude}, ${location.longitude}]`
                          });
                      }
                  }
                  else {
                      let lastTrip = await getLastTrip(location.deviceId);
                      if (lastTrip) {
                          if (lastTrip.isCompleted == 1) {
                              // do nothing
                              //shortestDistance[location.deviceId]['lastTripRoute'] = lastTrip.detectedRoute;
                              shortestDistance[location.deviceId]['detectedRoute'] = null;
                              shortestDistance[location.deviceId]['busStation'] = null;
                              await TripsData.update({
                                  isDriving: location.isDriving
                              }, {
                                  where: {
                                      id: lastTrip.id
                                  }
                              });
                          }
                          else {
                              //Update isCompleted with true
                              //shortestDistance[location.deviceId]['lastTripRoute'] = lastTrip.detectedRoute;
                              shortestDistance[location.deviceId]['detectedRoute'] = null;
                              shortestDistance[location.deviceId]['busStation'] = null;
                              await TripsData.update({
                                  isCompleted: 1,
                                  isDriving: location.isDriving,
                                  busStation: null,
                                  detectedRoute: null,
                              }, {
                                  where: {
                                      id: lastTrip.id
                                  }
                              });
                          }
                      }
                      else {
                          shortestDistance[location.deviceId]['detectedRoute'] = null;
                          shortestDistance[location.deviceId]['busStation'] = stationName;
                      }
                  }
              }
              shortestDistance[location.deviceId]['isBusInsideBusStand'] = isBusInsideBusStand ? 1 : 0;
          }

          //insert countables and allRouted into shortestDistance object
          for (const [index, bus] of Object.entries(shortestDistance)) {
              //finding deviceId in routeDetermination table
              const indexFound = currentRoute.findIndex(rec => rec.deviceId == index);

              //assigning totalCountable from routeDetermination table
              shortestDistance[index]['countables'] = indexFound == -1 ? {} : JSON.parse(currentRoute[indexFound].totalCountables);

              //insert all routes of a bus stand
              const routes = new Set();
              shortestDistance[index]['allRoutes'] = fullPath.filter(record => {
                  if (record.Latitude == bus.location.latitude && record.Longitude == bus.location.longitude) {
                      if (routes.has(record.name)) {
                          return false;
                      }
                      routes.add(record.name);
                      return true;
                  } else {
                      return false;
                  }
              });
          }
          // increasing countables and inserting stops into shortestDistance from stopObj
          for (const [index, bus] of Object.entries(shortestDistance)) {
              bus.allRoutes.forEach(route => {
                  const name = route.name;
                  //increase count and update shortestDistance object
                  if (shortestDistance[index]['countables'] && shortestDistance[index]['countables'][name]) {
                      shortestDistance[index]['countables'][name] += 1;
                  } else {
                      shortestDistance[index]['countables'][name] = 1;
                  }

                  //insert stops in shortestDistance object
                  if (stopsObj[name]['stops'] && stopsObj[name]['stops'].length > 0) {
                      for (let stop of stopsObj[name]['stops']) {
                          shortestDistance[index]['stops'].push(stop);
                      }
                  }
              });
          }

          let insertRecords = [];
          for (const [index, bus] of Object.entries(shortestDistance)) {
              let pastList = bus.pastList ? bus.pastList : [];
              let isRouteReset = bus.isRouteReset;
              let maxName = '';
              let onlyStopCoords;
              let filterStops;

              if (bus.detectedRoute) {
                  console.log(`---------- Yes route ${bus.detectedRoute} has been detected.`);
                  //remove unwanted stops
                  
                  //bus.stops = bus.stops.filter((element) => element.StopName == bus.detectedRoute);
                  bus.stops = stopsObj[bus.detectedRoute]['stops']
                  //assign bus stops to variable filterStops
                  filterStops = bus.stops;

                  //separating  coordinates from stops
                  onlyStopCoords = filterStops.map(rec => {
                      return {
                          latitude: rec.latitude,
                          longitude: rec.longitude,
                      }
                  });

                  //getting nearest stop
                  let shortestStop = geolib.findNearest({ latitude: (bus.latitude), longitude: (bus.longitude) }, onlyStopCoords);

                  //getting current route/stop
                  let getCurrentRoute = filterStops.find((x) => x.longitude == shortestStop.longitude && x.latitude == shortestStop.latitude);

                  //filter stops with current route
                  if (getCurrentRoute) {
                      maxName = getCurrentRoute.StopName;
                      // filterStops = filterStops.filter((x) => x.StopName == getCurrentRoute.StopName);
                  }
                  //get boundary points with respect to current route
                  let boundaryPoints = Boundary.find(rec => {
                      if (rec.associatedRoutes.includes(maxName)) {
                          return true
                      }
                  });

                  //check if bus is inside bus stand using geolib library
                  let inBoundary = geolib.isPointInPolygon({
                      latitude: bus.latitude,
                      longitude: bus.longitude
                  }, boundaryPoints.stationBoundary) ? 1 : 0;

                  if(bus.isDriving == 0 && getCurrentRoute.sequence == 1){
                    inBoundary = 1;
                    maxName = null;
                    pastList = null;
                    let lastTrip = await getLastTrip(index);
                    if(lastTrip && lastTrip.isCompleted == 0){
                      await TripsData.update({
                        isCompleted: 1,
                        isDriving: 0,
                        busStation: null,
                        detectedRoute: null,
                        nextStops: null
                      }, {
                          where: {
                              id: lastTrip.id
                          }
                      });
                    }
                  }
                  // find nearest STOP here
                  let nearest;
                  completedTrips[bus.deviceName] = 0;
                  // if bus is inside the bus stand
                  if (inBoundary == 1) {
                      pastList = [2, 3, 4];
                      isRouteReset = 1;
                  }
                  else {
                      completedTrips[bus.deviceName] = bus.isRouteReset == 1 ? 1 : 0;
                      isRouteReset = 0;
                      // let distances = [];
                      //sorting stops according to sequence
                      filterStops.sort((a, b) => a.sequence - b.sequence);

                      if (bus['currentStation'] == null) {
                          //if current station is NULL then nearest stop is first index of stops
                          nearest = filterStops[0];
                          pastList = [
                              nearest.sequence,
                              nearest.sequence + 1,
                              nearest.sequence + 2,
                          ];
                          //1,2,3

                          // -----> distance calculator start
                          let arrDistances = [];
                          let lastTrip = await TripsData.findOne({
                              where: {
                                  DeviceId: index,
                                  isCompleted: 0
                              },
                              order: [['id', 'DESC']],
                              raw: true
                          });

                          if (lastTrip) {
                              let checkpoint = [bus.latitude, bus.longitude];
                              if (lastTrip.nextStops == null) {
                                  for (let past of pastList) {
                                      if (arrDistances.length < 2) {
                                          let distanceFromBusToStop = await distanceHelper.distanceBetweenTwoPoints(checkpoint[0], checkpoint[1], filterStops[past - 1].latitude, filterStops[past - 1].longitude, "M");
                                          arrDistances.push({
                                              ...filterStops[past - 1],
                                              isStopPassed: 0,
                                              originalDistance: distanceFromBusToStop,
                                              tempDistance: 0
                                          });
                                      }
                                  }
                                  await TripsData.update({
                                      nextStops: JSON.stringify(arrDistances)
                                  }, {
                                      where: {
                                          id: lastTrip.id
                                      }
                                  });
                              }
                              else {
                                  arrDistances = JSON.parse(lastTrip.nextStops);
                              }
                          }
                          // -----> distance calculator end
                      } else {
                          console.log(`--> has current station: ${bus['currentStation']}`);
                          // -----> distance calculator start
                          let arrDistances = [];
                          let lastTrip = await TripsData.findOne({
                              where: {
                                  DeviceId: index,
                                  isCompleted: 0
                              },
                              order: [['id', 'DESC']],
                              raw: true
                          });

                          if (lastTrip) {
                              if (lastTrip.nextStops == null) {
                                  for (let past of pastList) {
                                      if (arrDistances.length < 2) {
                                          let distanceFromBusToStop = await distanceHelper.distanceBetweenTwoPoints(bus.latitude, bus.longitude, filterStops[past - 1].latitude, filterStops[past - 1].longitude, "M");
                                          arrDistances.push({
                                              ...filterStops[past - 1],
                                              isStopPassed: 0,
                                              originalDistance: distanceFromBusToStop,
                                              tempDistance: 0
                                          });
                                      }
                                  }
                                  await TripsData.update({
                                      nextStops: JSON.stringify(arrDistances)
                                  }, {
                                      where: {
                                          id: lastTrip.id
                                      }
                                  });
                              }
                              else {
                                console.log(`Next stops lat lng available`);
                                  let checkpoint = JSON.parse(lastTrip.checkpoint); // it needs to be updated periodically
                                  let nextStops = JSON.parse(lastTrip.nextStops);
                                  console.log(`NextStop: ${nextStops.length}`);
                                  console.log(`PastList: ${pastList}`);
                                  console.log('---> Distances -----\n');
                                  let pastIndex = 0;
                                  for (let past of pastList) {
                                      if (past != 1 && past <= filterStops.length) {
                                          if (past == pastList[0] || past == pastList[1]) {
                                              if (nextStops[pastIndex] && nextStops[pastIndex].isStopPassed != 1) {
                                                  console.log(`\nSequence: ${past}`);
                                                  let distanceFromBusToStop = await distanceHelper.distanceBetweenTwoPoints(bus.latitude, bus.longitude, filterStops[past - 1].latitude, filterStops[past - 1].longitude, "M");
                                                  let distanceFromCheckpointToBus = await distanceHelper.distanceBetweenTwoPoints(checkpoint[0], checkpoint[1], bus.latitude, bus.longitude, "M");
                                                  let distanceFromCheckpointToStop = nextStops[pastIndex].originalDistance;
                                                  console.log(`BusToStop: ${distanceFromBusToStop}`);
                                                  console.log(`BoxToBus: ${distanceFromCheckpointToBus}`);
                                                  console.log(`BoxToStop: ${distanceFromCheckpointToStop}`);
                                                  //if (distanceFromBusToStop <= distanceFromCheckpointToStop && distanceFromCheckpointToBus <= distanceFromCheckpointToStop) {
                                                  if (distanceFromCheckpointToBus <= distanceFromCheckpointToStop) {
                                                      // it means bus hasn't reached the STOP yet
                                                      nextStops[pastIndex].tempDistance = distanceFromBusToStop;
                                                  }
                                                  else {
                                                      console.log(`${past} has marked as isStopPassed`);
                                                      // it tells bus has passed the STOP                                                
                                                      nextStops[pastIndex].isStopPassed = 1; //isStopPassed
                                                      nextStops[pastIndex].tempDistance = 0;
                                                  }
                                              }
                                          }
                                      }
                                      pastIndex++;
                                  }

                                  //if one of stop has passed then remove the first stop from the sequence
                                  let isRemovedFromNextStops = 0;
                                  let nextStopIndex = 0;
                                  let passedStopsCount = 0;
                                  for (let nextStop of nextStops) {
                                      if (nextStop.isStopPassed == 1 && nextStopIndex != 0) {
                                          console.log(`Removing stop ${nextStops[0].StopNumber}`);
                                          nextStops.shift();
                                          passedStopsCount = passedStopsCount + 1;
                                          isRemovedFromNextStops = 1;
                                          // break;
                                      }
                                      nextStopIndex++;
                                  }
                                  //let passedStopsCount = nextStops.find(nextStop => nextStop.isStopPassed == 1).lengh;

                                  //if the pastList (sequences) are not 3 in length, add the next one.
                                  //Also update "checkpoint" in trip table
                                  if (nextStops.length < 2 && pastList.length != 1) {
                                      //update pastList
                                      let tempPastList = [];
                                      for (let p of pastList) {
                                          if ((p + 1) <= filterStops.length) {
                                              tempPastList.push(p + 1);
                                          }
                                      }
                                      pastList = tempPastList;
                                      //update new checkpoint when pastList gets updated
                                      checkpoint = JSON.parse(`[${filterStops[pastList[0] - 1].latitude}, ${filterStops[pastList[0] - 1].longitude}]`);
                                      console.log(`--- updated pastList: ${pastList}`);
                                      //add next Stop
                                      if (pastList.length >= 2) {
                                          let distanceFromCheckpointToStop = await distanceHelper.distanceBetweenTwoPoints(checkpoint[0], checkpoint[1], filterStops[pastList[1] - 1].latitude, filterStops[pastList[1] - 1].longitude, "M");
                                          console.log(`--- Entering new stop ${filterStops[pastList[1] - 1].StopNumber} => ${distanceFromCheckpointToStop}`);
                                          nextStops.push({
                                              ...filterStops[pastList[1] - 1],
                                              isStopPassed: 0,
                                              originalDistance: distanceFromCheckpointToStop,
                                              tempDistance: 0
                                          });
                                      }

                                      //update original distance of other stops with the new checkpoint
                                      for (let s of nextStops) {
                                          let distanceFromCheckpointToStop = await distanceHelper.distanceBetweenTwoPoints(checkpoint[0], checkpoint[1], s.latitude, s.longitude, "M");
                                          s.originalDistance = distanceFromCheckpointToStop;
                                      }
                                  }
                                  //update trip with new future STOPS
                                  await TripsData.update({
                                      nextStops: JSON.stringify(nextStops),
                                      checkpoint: isRemovedFromNextStops == 1 ? `[${filterStops[pastList[0] - 1].latitude}, ${filterStops[pastList[0] - 1].longitude}]` : JSON.stringify(checkpoint)
                                  
                                    }, { where: { id: lastTrip.id } });
                              }
                          }
                          // -----> distance calculator end
                          nearest = filterStops[pastList[0] - 1];
                          console.log(`-----> Current station: ${nearest.StopNumber}`);
                      }
                  }

                  insertRecords.push({
                      deviceId: index,
                      totalCountables: reset ? '{}' : JSON.stringify(bus.countables),
                      currentRouteDetermined: maxName,
                      isBusInStation: inBoundary,
                      updatedAt: new Date(),
                      pastList: JSON.stringify(pastList),
                      isRouteReset,
                      currentStation: nearest && nearest.StopNumber ? nearest.StopNumber : null
                  });

              } else {
                    insertRecords.push({
                      deviceId: index,
                      totalCountables: reset ? '{}' : JSON.stringify(bus.countables),
                      currentRouteDetermined: bus.lastTripRoute,
                      isBusInStation: bus.isBusInsideBusStand,
                      updatedAt: new Date(),
                      pastList: JSON.stringify(pastList),
                      isRouteReset: bus.isRouteReset,
                      currentStation: null
                  });
              }
              // else {
              //     //assign bus stops to variable filterStops
              //     filterStops = bus.stops;

              //     //separating  coordinates from stops
              //     onlyStopCoords = filterStops.map(rec => {
              //         return {
              //             latitude: rec.latitude,
              //             longitude: rec.longitude,
              //         }
              //     });

              //     //getting nearest stop
              //     let shortestStop = geolib.findNearest({ latitude: (bus.latitude), longitude: (bus.longitude) }, onlyStopCoords);

              //     //getting current route/stop
              //     let getCurrentRoute = filterStops.find((x) => x.longitude == shortestStop.longitude && x.latitude == shortestStop.latitude);

              //     //filter stops with current route
              //     if (getCurrentRoute) {
              //         maxName = getCurrentRoute.StopName;
              //         filterStops = filterStops.filter((x) => x.StopName == getCurrentRoute.StopName);
              //     }

              //     //get boundary points with respect to current route
              //     let boundaryPoints = Boundary.find(rec => {
              //         if (rec.associatedRoutes.includes(maxName)) {
              //             return true
              //         }
              //     });

              //     //check if bus is inside bus stand using geolib library
              //     const inBoundary = geolib.isPointInPolygon({
              //         latitude: bus.latitude,
              //         longitude: bus.longitude
              //     }, boundaryPoints.stationBoundary) ? 1 : 0;

              //     let isPointInLine = false;

              //     //check if all the points are on same line
              //     filterStops.forEach((stop, index) => {
              //         //if next stop available
              //         if (filterStops[index + 1]) {
              //             let inLine = geolib.isPointInLine(
              //                 {
              //                     latitude: bus.latitude,
              //                     longitude: bus.longitude
              //                 },
              //                 {
              //                     latitude: filterStops[index].latitude,
              //                     longitude: filterStops[index].longitude
              //                 },
              //                 {
              //                     latitude: filterStops[index + 1].latitude,
              //                     longitude: filterStops[index + 1].longitude
              //                 }
              //             ) ? true : false;

              //             if (isPointInLine != true) {
              //                 isPointInLine = inLine;
              //             }
              //         }
              //     });

              //     // find nearest STOP here
              //     let nearest;
              //     completedTrips[bus.deviceName] = 0;
              //     // if bus is inside the bus stand
              //     if (inBoundary == 1) {
              //         pastList = [2, 3, 4];
              //         isRouteReset = 1;
              //     }
              //     else {
              //         completedTrips[bus.deviceName] = bus.isRouteReset == 1 ? 1 : 0;
              //         isRouteReset = 0;
              //         // let distances = [];
              //         //sorting stops according to sequence
              //         filterStops.sort((a, b) => a.sequence - b.sequence);

              //         if (bus['currentStation'] == null) {
              //             //if current station is NULL then nearest stop is first index of filterStops
              //             pastList = [2, 3, 4];
              //         } else {
              //             let NearestSequenceIndex = 0;
              //             let NearestS = filterStops[NearestSequenceIndex];
              //             let SNearestS = filterStops[NearestSequenceIndex + 1];
              //             if (NearestS || SNearestS) {
              //                 if (pastList.includes(NearestS.sequence)) {
              //                     // nearest
              //                     nearest = NearestS
              //                 } else if (pastList.includes(SNearestS.sequence)) {
              //                     // second nearest
              //                     nearest = SNearestS
              //                 } else {
              //                     nearest = NearestS
              //                 }
              //                 pastList = [2, 3, 4];
              //             }
              //             nearest = null;
              //         }
              //     }

              //     insertRecords.push({
              //         deviceId: index,
              //         totalCountables: reset ? '{}' : JSON.stringify(bus.countables),
              //         currentRouteDetermined: maxName,
              //         isBusInStation: inBoundary,
              //         updatedAt: new Date(),
              //         pastList: JSON.stringify(pastList),
              //         isRouteReset,
              //         currentStation: nearest && nearest.StopNumber ? nearest.StopNumber : null
              //     });
              // }


          }

          //updating completed trips table
          if (isEntryCompleted) {
              const arr = ['id', 'date', 'createdAt', 'updatedAt'];
              for (const property in completedRecord[0]) {
                  if (!arr.includes(property) && typeof (completedTrips[property] != 'undefined')) {
                      completedTrips[property] += Number(completedRecord[0][property])
                  }
              }
              let id = completedRecord[0].id
              CompletedTripsModel.update(completedTrips, {
                  where: {
                      id: id
                  }
              }).then(res => {
                  console.log('updated')
              }).catch(err => {
                  throw new Error(err.message)
              })
          }
          //inserting new record in completed trips table
          else {
              await CompletedTripsModel.create(
                  completedTrips
              ).then(res => {
                  console.log('inserted')
              }).catch(err => {
                  throw new Error(err.message)
              })
          }

          //updating/inserting data into routeDetermination table 
          await routeDeterminationModel.bulkCreate(insertRecords, {
              updateOnDuplicate: ['totalCountables', 'currentRouteDetermined', 'updatedAt', 'isBusInStation', 'pastList', 'isRouteReset', 'currentStation']
          }).then(function () {
              callback(null, {
                  statusCode: 200,
                  error: null,
                  msg: "Records inserted successfully"
              });
          }).catch(function (err) {
              console.log(err);
              callback(null, {
                  statusCode: 404,
                  error: 1,
                  msg: "Error Occured"
              });
          });
      });



  } catch (err) {
      callback(err, "Err");
  }
};

module.exports.getBusesStationEtaData = async (event, context, callback) => {
  try {
      context.callbackWaitsForEmptyEventLoop = false;
      //let user = await utils.checkAuth(event.headers, callback)
      // let user = jwt_decode(event.headers.Authorization.split(' ')[1]);
      // console.log('user associatedRoutes', user);
      const location = event.queryStringParameters.location;
      let routes = getRoutesFromLocation(location);
      let user = {
        associatedStation: location,
        associatedRoutes: routes
      }
      const responseBusRecords = await getBusRecord(user);

      callback(null, {
          statusCode: 200,
          headers: {
              'Content-Type': 'application/json',
              'Access-Control-Allow-Origin': '*'
          },
          body: JSON.stringify({
              msg: "Bus data fetched successfully",
              status: 1,
              results: {
                  busesInPolygon: responseBusRecords,
              }
          }, null, 2)
      })
  } catch (err) {
      console.log(err)
      callback(null, {
          statusCode: 500,
          headers: {
              'Content-Type': 'application/json',
              'Access-Control-Allow-Origin': '*'
          },
          body: JSON.stringify({
              msg: "Internal server error occured",
              err: err.message,
              status: 0,
              results: [],
          })
      })
  }
}

function between(x, min, max) {
  return x >= min && x <= max;
}

async function getBusRecord(user) {
  const geolib = require('geolib');

  let location;
  let parsedRoutes = user.associatedRoutes
  if (!user.associatedRoutes) {
      throw new Error('You are not authorized to access that location')
  }
  if (user.associatedStation) {
      location = user.associatedStation;
  }
  let routesStopsUser = parsedRoutes.map(id => "'" + id + "'").join()

  let getStopsForStationQuery = `SELECT id, routeAllocationName,StopNumber, PointX, PointY,sequence, colorScheme FROM stoplocations_react WHERE include = 1 AND routeAllocationName IN (${routesStopsUser})`
  const p1 = db.query(getStopsForStationQuery, {
      raw: true,
  })

  let getPolygonsQuery = `SELECT name, landmarkId,Latitude,Longitude FROM stopsSurroundingStops WHERE name = '${user.associatedStation}'`
  const p2 = db.query(getPolygonsQuery, {
      raw: true,
  })

  let getDeviceInfoQuery = `SELECT currentStation,isRouteReset,latitude,longitude,routeDetermination.isBusInStation AS isBusInStation, routeDetermination.pastList AS pastList,device.isActive AS isActive,currentRouteDetermined, routeDetermination.deviceId, device.deviceName, deviceStatusInfo.currentStateDuration FROM deviceStatusInfo LEFT JOIN routeDetermination ON deviceStatusInfo.deviceId = routeDetermination.deviceId LEFT JOIN device ON device.id = deviceStatusInfo.deviceId WHERE device.isActive = 1 and device.application='PiLab'`
  const p3 = db.query(getDeviceInfoQuery, {
      raw: true,
  })

  let getBoundary = `SELECT stationBoundary FROM stopsLandmarks WHERE name = '${user.associatedStation}'`
  const p4 = db.query(getBoundary, {
      raw: true,
  })

  let getAllGraphLocs = `SELECT start, end, routeAllocationName,distanceMeters, distanceFromStation FROM trainGraphLocations_new where transportType=2`
  const p5 = db.query(getAllGraphLocs, {
      raw: true,
  })

  let stopsObj = {};
  let polygonArray = [];
  let busesInPolygon = {};

  const values = await Promise.all([p1, p2, p3, p4, p5]);
  let stops = values[0][0]
  let polygons = values[1][0]
  let deviceInfo = values[2][0]
  let Boundary = values[3][0]
  let trainGraphs = values[4][0]
  let uniqueStops = []

  //inserting stops
  for (let stop of stops) {
      if (!stopsObj[stop.routeAllocationName]) {
          stopsObj[stop.routeAllocationName] = {}
          stopsObj[stop.routeAllocationName]['stops'] = []
          stopsObj[stop.routeAllocationName]['color'] = stop.colorScheme
          uniqueStops.push(stop.routeAllocationName)
      }
      stopsObj[stop.routeAllocationName]['stops'].push({
          StopNumber: stop.StopNumber,
          latitude: stop.PointY,
          longitude: stop.PointX,
          sequence: stop.sequence,
      });
  }

  let responseBusRecords = [];
  let hasRouteAllocated = [];
  for (let bus of deviceInfo) {
      if (user.associatedRoutes.includes(bus.currentRouteDetermined)) {
          let busRecord = {};
          hasRouteAllocated.push(bus.currentRouteDetermined);
          let isDeviated = false;

          //check if bus is in polygon
          const isInPoly = geolib.isPointInPolygon({ latitude: bus.latitude, longitude: bus.longitude }, polygons) ? 1 : 0;
          if (!isInPoly) {
              isDeviated = true;
          }

          //inserting bus data into new busRecord object
          busRecord['locationName'] = location;
          busRecord['deviceId'] = bus.deviceId;
          busRecord['deviceName'] = bus.deviceName;
          busRecord['stops'] = [];
          busRecord['isDeviated'] = isDeviated;
          busRecord['route'] = {
              name: bus.currentRouteDetermined,
              color: stopsObj[bus.currentRouteDetermined]['color'] ? `#${stopsObj[bus.currentRouteDetermined]['color']}` : ''
          }
          busRecord['location'] = {
              latitude: bus.latitude,
              longitude: bus.longitude
          }
          moment.tz.setDefault(config.timeZone.africaCairo);
          const currentHour = moment().format('H');
          //const currentHour = momenttimezone().tz("Africa/Johannesburg").format('H');
          console.log(currentHour, 'currentHour');
          //proceed only if bus is not at station
          let isBusOperating = between(currentHour, 5, 18);
          busRecord['isBusOperating'] = isBusOperating;
          
          if (bus.isBusInStation == 0 && isBusOperating){
              let currentStation;
              let foundCurrentStationDistance;
              let remainingDistanceFromCurrentStopInSecs = 0;
              let coveredDistanceFromCurrentStopInSecs = 0;
              let speed = 20; //kmph
              let getCurrentBusSpeed = `SELECT * FROM logrecorddataset where DeviceId = '${bus.deviceId}' order by createdAt DESC`;
              let busSpeedResult = await db.query(getCurrentBusSpeed, {
                  raw: true,
              });
              speed = busSpeedResult[0][0].Speed;
              if (speed <= 20) speed = 20;

              if (stopsObj[bus.currentRouteDetermined]['stops'] && stopsObj[bus.currentRouteDetermined]['stops'].length > 0) {
                  // sort the array by sequence
                  await stopsObj[bus.currentRouteDetermined]['stops'].sort((a, b) => a.sequence - b.sequence);
                  let duplicateBusStand = {
                      "StopNumber": stopsObj[bus.currentRouteDetermined]['stops'][0].StopNumber,
                      "latitude": stopsObj[bus.currentRouteDetermined]['stops'][0].latitude,
                      "longitude": stopsObj[bus.currentRouteDetermined]['stops'][0].longitude,
                      "sequence": stopsObj[bus.currentRouteDetermined]['stops'][stopsObj[bus.currentRouteDetermined]['stops'].length - 1].sequence + 1,
                      "duplicate": true
                  };
                  stopsObj[bus.currentRouteDetermined]['stops'].push(duplicateBusStand);
                  let Firstindex = stopsObj[bus.currentRouteDetermined]['stops'].findIndex(val => val.StopNumber == bus['currentStation']);
                  if (Firstindex !== -1) {
                      // remove stops that bus has passed
                      let filterStops = [...stopsObj[bus.currentRouteDetermined]['stops']];
                      filterStops = filterStops.splice(Firstindex);

                      if (filterStops && filterStops.length > 0) {
                          // get currentStation
                          currentStation = filterStops[0];
                          // console.log('currentStation', currentStation);

                          //getting current station distance from DB
                          foundCurrentStationDistance = trainGraphs.find(rec => rec.start == currentStation.StopNumber);

                          // get only 3 stops, remove rest
                          let nextStops = filterStops.slice(0, 4);

                          //inserting stop details into stops array of busRecord
                          if (nextStops && nextStops.length > 0) {
                              for (let nextStop of nextStops) {
                                  busRecord['stops'].push({
                                      StartStopName: Stops[nextStop.StopNumber],
                                      StartStopNumber: nextStop.StopNumber,
                                      latitude: nextStop.latitude,
                                      longitude: nextStop.longitude,
                                      sequence: nextStop.sequence
                                  })
                              }
                          }
                      }
                  }
              }
              let index = 0;
              let distanceArr = [...trainGraphs].filter(x => x.routeAllocationName == bus.currentRouteDetermined);
              if(busRecord['stops'].length > 0){
              for (let stopElement of busRecord['stops']) {
                  //getting next stop of current stop
                  let found = trainGraphs.find(rec => rec.start == stopElement.StartStopNumber);
                  
                  busRecord['stops'][index]['EndStopNumber'] = found['end'];
                  busRecord['stops'][index]['EndStopName'] = Stops[found['end']];

                  //calculating next bus stop
                  let nextStop;
                  let firstStopObj;
                  if (busRecord['stops'].length == 1) {
                      nextStop = busRecord['stops'][index];
                      firstStopObj = busRecord['stops'][0];
                  } else {
                      nextStop = busRecord['stops'][index + 1];
                      firstStopObj = busRecord['stops'][1];
                  }


                  if (nextStop) {
                      //calculating distance between two locations
                      let remainingDistanceFromCurrentStop = await distanceHelper.distanceBetweenTwoPoints(bus.latitude, bus.longitude, firstStopObj.latitude, firstStopObj.longitude, "K");
                      if(index > 0){
                          const countIndex = busRecord['stops'][0].sequence;
                          let _distance = 0;
                          for(let i = 0; i < index; i++) {    
                              let _d = getDistance1(distanceArr[countIndex + i]);
                              _distance = _distance + _d;
                          }
                          remainingDistanceFromCurrentStop = remainingDistanceFromCurrentStop + _distance;
                      }

                      //Calculating distance in seconds
                      remainingDistanceFromCurrentStopInSecs = remainingDistanceFromCurrentStop / speed;

                      let getDistance;
                      // getDistance = (found.distanceMeters / 1000); //distance in KM
                      getDistance = remainingDistanceFromCurrentStop; //distance in KM

                      let durationInSecs = getDistance / speed;
                      let duration = distanceCalc.secondsToHms(durationInSecs * 3600) //secs
                      console.log(`from bus to ${nextStop.StartStopNumber} in seconds => ${durationInSecs * 3600} => ${duration} inserting in ${busRecord['stops'][index].StartStopNumber}`);;

                      //inserting distance in km and m
                      busRecord['stops'][index]['distance'] = {
                          km: getDistance.toFixed(2),
                          m: (getDistance * 1000).toFixed(2)
                      }

                      // inserting ETA
                      busRecord['stops'][index]['eta'] = {
                          text: duration,
                          timestamp: moment().add(Number(durationInSecs * 3600), 'seconds').unix(),
                          time: moment().add(Number(durationInSecs * 3600), 'seconds').utcOffset('+0200').format('h:mm A'),
                          seconds: Number(durationInSecs * 3600).toFixed(2),
                          currentTimeStamp: moment().add(Number(remainingDistanceFromCurrentStopInSecs * 3600), 'seconds').unix(),
                          currentTime: moment().add(Number(remainingDistanceFromCurrentStopInSecs * 3600), 'seconds').utcOffset('+0200').format('h:mm A'),
                          currentSeconds: Number(remainingDistanceFromCurrentStopInSecs * 3600).toFixed(2)
                      }
                      
                      coveredDistanceFromCurrentStopInSecs = (durationInSecs * 3600) - (remainingDistanceFromCurrentStopInSecs * 3600);
                  }
                  index++;
              }
              }
              
              if (busRecord['stops'].length > 1) busRecord['stops'].splice(busRecord['stops'].length - 1, 1);
              if (busRecord['stops'].length > 1) busRecord['stops'] = busRecord['stops'].filter((stop) => Number(stop.distance.m) >= Number(busRecord['stops'][0].distance.m));
              // last stop eta
              stopsObj[bus.currentRouteDetermined]['stops'] = stopsObj[bus.currentRouteDetermined]['stops'].filter(x => !x['duplicate']);
              let isLastIndex = busRecord['stops'].findIndex(x => x.sequence == stopsObj[bus.currentRouteDetermined]['stops'].length);
              if(isLastIndex == -1 && busRecord['stops'].length > 1){
                let endStopObj = {
                  StartStopName: busRecord['stops'][0].StartStopName,
                  StartStopNumber: busRecord['stops'][0].StopNumber,
                  latitude: busRecord['stops'][0].latitude,
                  longitude: busRecord['stops'][0].longitude,
                  EndStopNumber: 'end',
                  EndStopName: Stops[`${location[0].toUpperCase()}${location.slice(1)} End`]
                }
                let distanceTofirstStop = busRecord['stops'][0].distance.km;
                let _d = getEndDistance(distanceArr[busRecord['stops'][1].sequence]);
                let remainingDistanceFromCurrentStop = Number(distanceTofirstStop) + Number(_d);
                
                let remainingDistanceFromCurrentStopInSecs = 0;
                remainingDistanceFromCurrentStopInSecs = remainingDistanceFromCurrentStop / speed;
                
                let getDistance;
                getDistance = remainingDistanceFromCurrentStop; //distance in KM

                let durationInSecs = getDistance / speed;
                let duration = distanceCalc.secondsToHms(durationInSecs * 3600) //secs
                

                //inserting distance in km and m
                endStopObj['distance'] = {
                    km: getDistance.toFixed(2),
                    m: (getDistance * 1000).toFixed(2)
                }

                // inserting ETA
                endStopObj['eta'] = {
                    text: duration,
                    timestamp: moment().add(Number(durationInSecs * 3600), 'seconds').unix(),
                    time: moment().add(Number(durationInSecs * 3600), 'seconds').utcOffset('+0200').format('h:mm A'),
                    seconds: Number(durationInSecs * 3600).toFixed(2),
                    currentTimeStamp: moment().add(Number(remainingDistanceFromCurrentStopInSecs * 3600), 'seconds').unix(),
                    currentTime: moment().add(Number(remainingDistanceFromCurrentStopInSecs * 3600), 'seconds').utcOffset('+0200').format('h:mm A'),
                    currentSeconds: Number(remainingDistanceFromCurrentStopInSecs * 3600).toFixed(2)
                }
                
                busRecord['stops'].push(endStopObj);
              }
              
          }
          // if(busRecord['stops'] && busRecord['stops'].length > 0){
            
          // }
          responseBusRecords.push(busRecord);
          //stopsObj[bus.currentRouteDetermined]['stops'] = stopsObj[bus.currentRouteDetermined]['stops'].filter(x => !x['duplicate']);  
      }
      
  }
 
  responseBusRecords = responseBusRecords.sort((a,b) => b.stops.length - a.stops.length);


  hasRouteAllocated = [...new Set(hasRouteAllocated)]
  uniqueStops = uniqueStops.filter(function (el) {
      return !hasRouteAllocated.includes(el);
  });

  for (let unique of uniqueStops) {
      let index = responseBusRecords.indexOf((x) => x.deviceId == unique);
      if (index == -1) {
          let record = {
              locationName: location,
              deviceName: null,
              deviceId: null,
              stops: [],
              route: {
                  name: unique,
                  color: stopsObj[unique]['color'] ? '#' + stopsObj[unique]['color'] : ''
              }
          }
          //responseBusRecords.push(record);
      }
  }
  return responseBusRecords;
}
