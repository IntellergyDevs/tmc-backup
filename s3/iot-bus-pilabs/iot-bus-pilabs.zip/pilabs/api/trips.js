const AWS = require('aws-sdk');
AWS.config.setPromisesDependency(require('bluebird'));
const dynamoDb = new AWS.DynamoDB.DocumentClient();
const moment = require('moment');
const momenttimezone = require('moment-timezone');
var config = require('../../config/config.json');
module.exports.getAll = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        // var params = {
        //     TableName: 'pilabs-trips-database',
        //     // ProjectionExpression: "id, fullname, email"
        // };
        // console.log("Scanning pilabs trips table.");
        // const onScan = (err, data) => {
        //     if (err) {
        //         console.log('Scan failed to load data. Error JSON:', JSON.stringify(err, null, 2));
        //         callback(err);
        //     } else {
        //         console.log("Scan succeeded.");
        //         response = {
        //             statusCode: 200,
        //             body: JSON.stringify({
        //                 result: data.Items
        //             })
        //         }
        //     }
        // };
        let params = {
            TableName: 'pilabs-trips-database'
        }
        // await dynamoDb.scan(params, onScan);
        const records = await dynamoDb.scan(params).promise();
        response = {
            statusCode: 200,
            body: JSON.stringify({
                result: records.Items
            })
        }
        callback(null, response)
    } catch (error) {
        response = {
            statusCode: 500,
            body: JSON.stringify({
                message: 'pilabs trip data not fetch sucessfully',
                error: error,
                //   result:data,
            }),
        };
        callback(null, response)
    }
}

module.exports.insertTrips = async (event, context, callback) => {
    let response;
    console.log("hi insertrips");
    try {
        let params = {
            TableName: 'pilabs-trips-database'
        }
        // await dynamoDb.scan(params, onScan);
        const records = await dynamoDb.scan(params).promise();
        response = {
            statusCode: 200,
            body: JSON.stringify({
                result: records.Items
            })
        }
        callback(null, response)
    } catch (error) {
        response = {
            statusCode: 200,
            body: JSON.stringify({
                error: error
            })
        }
        callback(null, response)
    }
}

module.exports.getAll1 = async (event, context, callback) => {
    let response;
    try {

        let limit = 50000;
        const tripModel = require('../../models/TripDataSet.model');
        const Device = require('../../models/Device.model');
        const lastRecord = await tripModel.findOne({
            attributes: ['id', 'StartDateTime'],
            order: [['id', 'DESC']],
            raw: true
        });
        console.log("lastRecord======>",lastRecord);
        // if (lastRecord !== null && lastRecord.StartDateTime !== null) {
        //     var lastDate = moment(new Date(lastRecord.StartDateTime)).utc().format(config.dateFormat.UtcIsoString);
        // }


        let params = {
            TableName: 'pilabs-trips-database'
        }
        // await dynamoDb.scan(params, onScan);
        const records = await dynamoDb.scan(params).promise();
        let nrecord = {};
        for (let record of records.Items) {
            // console.log("trip======>", record)
            nrecord['id'] = record.tripId;
                // nrecord['DeviceName'] = typeof (all_devices[record.device.id]) != 'undefined' ? all_devices[record.device.id] : '';
                nrecord['DeviceId'] = record.imei;
                nrecord['StartDateTime'] = moment(record.timestampStart).format(config.dateFormat.powerBi);
                nrecord['StopDateTime'] = moment(record.timestampEnd).format(config.dateFormat.powerBi);
                nrecord['Distance'] = record.tripLength;
                nrecord['AverageSpeed'] = record.averageSpeed?record.averageSpeed: 0;
                nrecord['DrivingDuration'] = moment.duration(record.drivingDuration).asMinutes();
                nrecord['MaximumSpeed'] = record.maximumSpeed;
                nrecord['IdlingDuration'] = moment.duration(record.idlingDuration).asMinutes()?record.idlingDuration:0;
                // nrecord['StopDuration'] = moment.duration(record.stopDuration).asMinutes();
                // nrecord['StopPointX'] = record.stopPoint.x ? record.stopPoint.x:0;
                // nrecord['StopPointY'] = record.stopPoint.y ? record.stopPoint.y: 0;
                // nrecord['NextTripStart'] = record.nextTripStart = moment(record.nextTripStart).format(config.dateFormat.powerBi) ? record.nextTripStart :0;
                // nrecord['WorkDistance'] = record.workDistance ? record.workDistance: 0;
                // nrecord['WorkDrivingDuration'] = moment.duration(record.workDrivingDuration).asMinutes();
                // nrecord['WorkStopDuration'] = moment.duration(record.workStopDuration).asMinutes();
                nrecord['createdAt'] = new Date();
                // nrecord['updatedAt'] = new Date();
                
                // console.log("nrecord======>",nrecord)
                const saveTripData = await tripModel.create(nrecord);

        }
        
        response = {
            statusCode: 200,
            body: JSON.stringify({
                result: records.Items
            })
        }
        callback(null, response)
    } catch (error) {
        console.log("error===>",error);
        response = {
            statusCode: 200,
            body: JSON.stringify({
                error: error
            })
        }
        callback(null, response)
    }
}