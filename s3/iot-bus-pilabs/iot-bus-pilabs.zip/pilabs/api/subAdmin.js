const jwt_decode = require('jwt-decode');
const utils = require('../../pilabs/common/utils')
const db = require('../../config/db.sequelize')
const geolib = require('geolib');
const distanceCalc = require('../common/distanceCalculator')
module.exports.getBusesStationEtaData = async (event, context, callback) => {
    let response; 
    try {
        context.callbackWaitsForEmptyEventLoop = false;
        let auth = await utils.checkAuth(event.headers, callback)

        let user = jwt_decode(event.headers.Authorization.split(' ')[1]);
        // console.log("user=====>",user);
        let parsedRoutes = user.associatedRoutes
        console.log("parsedRoutes=====>",parsedRoutes);
        if (!user.associatedRoutes) {
            throw new Error('You are not authorized to access that location')
        }

        let routesStopsUser = parsedRoutes.map(id => "'" + id + "'").join()
        console.log("routesStopsUser=======>",routesStopsUser);
        let getStopsForStationQuery = `SELECT id, routeAllocationName,StopNumber, PointX, PointY,sequence, colorScheme FROM stoplocations_react WHERE include = 1 AND routeAllocationName IN (${routesStopsUser})`
        const p1 = await db.query(getStopsForStationQuery, {
            raw: true,
        })
        // console.log("p1====>",p1);

        let getPolygonsQuery = `SELECT name, landmarkId,Latitude,Longitude FROM stopsSurroundingStops WHERE name = '${user.associatedStation}'`
        const p2 = db.query(getPolygonsQuery, {
            raw: true,
        })

        let getDeviceInfoQuery = `SELECT currentStation,isRouteReset,latitude,longitude,routeDetermination.isBusInStation AS isBusInStation, routeDetermination.pastList AS pastList,device.isActive AS isActive,currentRouteDetermined, routeDetermination.deviceId FROM deviceStatusInfo LEFT JOIN routeDetermination ON deviceStatusInfo.deviceId = routeDetermination.deviceId LEFT JOIN device ON device.id = deviceStatusInfo.deviceId WHERE device.isActive = 1`
        const p3 = db.query(getDeviceInfoQuery, {
            raw: true,
        })

        let getBoundary = `SELECT stationBoundary FROM stopsLandmarks WHERE name = '${user.associatedStation}'`
        const p4 = db.query(getBoundary, {
            raw: true,
        })

        let getAllGraphLocs = `SELECT start, end, routeAllocationName, distanceFromStation FROM trainGraphLocations_new`
        const p5 = db.query(getAllGraphLocs, {
            raw: true,
        })

        let stopsObj = {}
        await Promise.all([p1, p2, p3, p4, p5]).then(async (values) => {
            let stops = values[0][0]
            let polygons = values[1][0]
            let deviceInfo = values[2][0]
            let Boundary = values[3][0]
            let trainGraphs = values[4][0]
            let uniqueStops = []
            stops.forEach(element => {

                if (!stopsObj[element.routeAllocationName]) {
                    stopsObj[element.routeAllocationName] = {}
                    stopsObj[element.routeAllocationName]['stops'] = []
                    stopsObj[element.routeAllocationName]['color'] = element.colorScheme
                    uniqueStops.push(element.routeAllocationName)
                }
                stopsObj[element.routeAllocationName]['stops'].push({
                    StopNumber: element.StopNumber,
                    latitude: element.PointY,
                    longitude: element.PointX,
                    sequence: element.sequence,
                })
            });
            let responseBusRecords = {}
            let hasRouteAllocated = []
            deviceInfo.forEach((bus, index) => {
                if (user.associatedRoutes.includes(bus.currentRouteDetermined)) {
                    hasRouteAllocated.push(bus.currentRouteDetermined)
                    let isDeviated = false
                    const isInPoly = geolib.isPointInPolygon({ latitude: bus.latitude, longitude: bus.longitude }, polygons) ? 1 : 0;
                    if (!isInPoly) {
                        isDeviated = true
                    }
                    responseBusRecords[bus.deviceId] = {}
                    responseBusRecords[bus.deviceId]['stops'] = []
                    responseBusRecords[bus.deviceId]['isDeviated'] = isDeviated
                    responseBusRecords[bus.deviceId]['route'] = {
                        name: bus.currentRouteDetermined,
                        color: stopsObj[bus.currentRouteDetermined]['color'] ? '#' + stopsObj[bus.currentRouteDetermined]['color'] : ''
                    }
                    responseBusRecords[bus.deviceId]['location'] = { latitude: bus.latitude, longitude: bus.longitude }

                    if (bus.isBusInStation == 1) {
                    } else {
                        let i = 0
                        let stopsCount = 0
                        let Firstindex = stopsObj[bus.currentRouteDetermined]['stops'].findIndex(val => val.StopNumber == bus['currentStation'])

                        while (i < 3) {
                            if (stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount]) {
                                responseBusRecords[bus.deviceId]['stops'].push({
                                    StopNumber: stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount].StopNumber,
                                    latitude: stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount].latitude,
                                    longitude: stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount].longitude
                                })
                            }
                            i++;
                            stopsCount++;
                        }

                        responseBusRecords[bus.deviceId]['stops'].forEach((stopElement, index) => {
                            let getDistance
                            // if (index == 0) {
                            //     getDistance = distanceHelper.distanceBetweenTwoPoints(bus.latitude, bus.longitude, stopElement.latitude, stopElement.longitude, "K")

                            // } else {
                            //     let prevElement = responseBusRecords[bus.deviceId]['stops'][index - 1]
                            //     getDistance = distanceHelper.distanceBetweenTwoPoints(prevElement.latitude, prevElement.longitude, stopElement.latitude, stopElement.longitude, "K")
                            // }
                            console.log(stopElement.StopNumber)
                            let found = trainGraphs.find(rec => rec.start == stopElement.StopNumber)
                            getDistance = (found.distanceFromStation / 1000)

                            const speed = 20//kmph
                            let durationInSecs = getDistance / speed
                            duration = distanceCalc.secondsToHms(durationInSecs * 3600)// secs
                            console.log(getDistance)
                            responseBusRecords[bus.deviceId]['stops'][index]['distance'] = {
                                km: getDistance.toFixed(2),
                                m: (getDistance * 1000).toFixed(2)
                            }
                            responseBusRecords[bus.deviceId]['stops'][index]['eta'] = {
                                text: duration,
                                seconds: Number(durationInSecs * 3600).toFixed(2)
                            }

                        });
                    }
                }

            });
            hasRouteAllocated = [...new Set(hasRouteAllocated)]


            uniqueStops = uniqueStops.filter(function (el) {
                return !hasRouteAllocated.includes(el);
            });
            uniqueStops.forEach(unique => {
                responseBusRecords[unique] = {
                    stops: [],
                    route: {
                        name: unique,
                        color: stopsObj[unique]['color'] ? '#' + stopsObj[unique]['color'] : ''
                    }
                }
            });
            console.log("responseBusRecords==========>",responseBusRecords);
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Bus data fetched successfully",
                    status: 1,
                    results: {
                        busesInPolygon: responseBusRecords,
                    }
                }, null, 2)
            })
        })

        // response = {
        //     statusCode: 200,
        //     headers: {
        //         'Content-Type': 'application/json',
        //         'Access-Control-Allow-Origin': '*'
        //     },
        //     body: JSON.stringify({
        //         msg: "Bus data fetched successfully",
        //         status: 1,
        //         results: {
        //             "busesInPolygon": {
        //                 "b5": {
        //                     "stops": [
        //                         {
        //                             "StopNumber": "QWHS1 - 1",
        //                             "latitude": "-25.7412500003417",
        //                             "longitude": "28.2419999999466",
        //                             "distance": {
        //                                 "km": "11.87",
        //                                 "m": "11871.00"
        //                             },
        //                             "eta": {
        //                                 "text": "35m, 36s",
        //                                 "seconds": "2136.78"
        //                             }
        //                         },
        //                         {
        //                             "StopNumber": "QWHS1 - 2",
        //                             "latitude": "-25.7321749102724",
        //                             "longitude": "28.2459049379219",
        //                             "distance": {
        //                                 "km": "10.64",
        //                                 "m": "10639.00"
        //                             },
        //                             "eta": {
        //                                 "text": "31m, 55s",
        //                                 "seconds": "1915.02"
        //                             }
        //                         },
        //                         {
        //                             "StopNumber": "QWHS1 - 3",
        //                             "latitude": "-25.7290865800946",
        //                             "longitude": "28.2456983472248",
        //                             "distance": {
        //                                 "km": "10.29",
        //                                 "m": "10295.00"
        //                             },
        //                             "eta": {
        //                                 "text": "30m, 53s",
        //                                 "seconds": "1853.10"
        //                             }
        //                         }
        //                     ],
        //                     "isDeviated": true,
        //                     "route": {
        //                         "name": "Queenswood",
        //                         "color": "#ec4bd7"
        //                     },
        //                     "location": {
        //                         "latitude": "-25.7480965",
        //                         "longitude": "28.2360058"
        //                     }
        //                 }
        //             }
        //         }
        //     })
        // }
        // callback (null,response)
    } catch (error) {
        console.log(error)
        callback(null, {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Internal server error occured",
                err: error.message,
                status: 0,
                results: [],
            })
        })
    }
}

module.exports.userGetStaticDetails = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        // const req = JSON.parse(event.body);
        let auth = await utils.checkAuth(event.headers, callback)
        let user = jwt_decode(event.headers.Authorization.split(' ')[1]);
        console.log("user=====>",user);
        // get routes
        let busRoutes
        var responseStops = [];
        let landmarks
        let responseLandmarksStops = [];
        if (user.associatedRoutes) {
            let parsedRoutes = user.associatedRoutes
            let sts = parsedRoutes.map(id => "'" + id + "'").join()

            let queryforStops = `SELECT B.id, A.centerPoint, A.name as Landmark, B.name, A.Latitude AS landmarkLat, A.Longitude AS landmarkLong, B.Latitude AS surroundLat, B.Longitude AS surroundLong, associatedRoutes FROM stopsLandmarks A LEFT JOIN stopsSurroundingStops B ON A.id = B.landmarkId WHERE A.name = '${user.associatedStation}'`;
            let queryforFullPath = `SELECT id, name, colorScheme, landmarkId, Latitude, Longitude FROM stopsFullPath WHERE name IN (${sts})`

            let busRoutes = db.query(`SELECT * FROM stoplocations_react WHERE routeAllocationName IN (${sts})`, {
                nest: true
            });
            const stopsAndLandmarks = db.query(queryforStops, {
                nest: true
            });

            let fullPath = db.query(queryforFullPath, {
                nest: true
            });

            await Promise.all([busRoutes, stopsAndLandmarks, fullPath]).then((values) => {
                let records = values[0]
                let landmarksRaw = values[1]
                let fullPath = values[2]
                let fullPathLocation = {};

                fullPath.forEach(element => {
                    if (typeof (fullPathLocation[element.name]) === 'undefined') {
                        fullPathLocation[element.name] = [];
                    }
                    fullPathLocation[element.name].push({
                        id: element.id,
                        latitude: Number(element.Latitude),
                        longitude: Number(element.Longitude),
                    })
                });
                let stopLocations = {};
                records.forEach(element => {
                    if (typeof (stopLocations[element.routeAllocationName]) === 'undefined') {
                        stopLocations[element.routeAllocationName] = {};
                        stopLocations[element.routeAllocationName]['id'] = element.routeAllocationName;
                        stopLocations[element.routeAllocationName]['name'] = element.routeAllocationName;
                        stopLocations[element.routeAllocationName]['routeStops'] = [];
                        stopLocations[element.routeAllocationName]['routeCoordinates'] = fullPathLocation[element.routeAllocationName] ? fullPathLocation[element.routeAllocationName] : []
                        stopLocations[element.routeAllocationName]['colorScheme'] = "#" + element.colorScheme;
                    }
                    stopLocations[element.routeAllocationName].routeStops.push({
                        message: element.StopNumber,
                        id: element.id,
                        longitude: Number(element.PointX),
                        latitude: Number(element.PointY),
                    })
                });
                Object.keys(stopLocations).forEach(element => {
                    responseStops.push(stopLocations[element]);
                });
                landmarks = landmarksRaw.filter((item, index, objects) => {
                    if (index === 0) {
                        return item
                    } else if (item.Landmark !== objects[index - 1].Landmark) {
                        return {
                            "name": item.Landmark,
                            "latitude": Number(item.landmarkLat),
                            "longitude": Number(item.landmarkLong),
                            "associatedRoutes": item.associatedRoutes,
                            "centerPoint": item.centerPoint,
                        };
                    }
                }).map(function (item) {
                    return {
                        "name": item.Landmark,
                        "latitude": Number(item.landmarkLat),
                        "longitude": Number(item.landmarkLong),
                        "associatedRoutes": JSON.parse(item.associatedRoutes),
                        "centerPoint": JSON.parse(item.centerPoint),
                    };
                });

                let landmarksWithStops = landmarksRaw.filter(({ id }) => id != null).map(function (item) {
                    return {
                        "Landmark": item.Landmark,
                        "name": item.name,
                        "latitude": Number(item.surroundLat),
                        "longitude": Number(item.surroundLong),
                        // "centerPoint": JSON.parse(item.centerPoint),
                    };
                }).reduce((r, a) => {
                    r[a.Landmark] = [...r[a.Landmark] || [], a];
                    return r;
                }, {});

                Object.keys(landmarksWithStops).forEach((element, key) => {
                    responseLandmarksStops.push({
                        id: element,
                        name: element,
                        routeCoordinates: landmarksWithStops[element]
                    })
                });
                responseLandmarksStops.forEach((element, index) => {
                    let landmark = landmarks.filter(lm => lm.name == element.name)

                    responseLandmarksStops[index]['associatedRoutes'] = landmark && landmark[0] && landmark[0].associatedRoutes ? landmark[0].associatedRoutes : []
                })
            })
        }
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Data fetched successfully",
                status: 1,
                results: {
                    routes: responseStops,
                    landmarks: {
                        landmarkStops: landmarks, // main station points
                        landmarkAreaCoordinates: responseLandmarksStops, // all polygon,
                        centerPoint: landmarks && landmarks[0] && landmarks[0].centerPoint ? landmarks[0].centerPoint : null
                    }
                }
            }, null, 2)
        })

    } catch (err) {
        console.log(err)
        callback(null, {
            statusCode: 401,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: err.message,
                err: err.message,
                status: 0,
                results: [],
            })
        })
    }
}