const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const ExceptionEvent = db.define('exceptioneventdataset', {
    _id: {
        type: Sequelize.STRING,
        unique: true,
        //primaryKey: true,
    },
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    DeviceName: {
        type: Sequelize.STRING
    },
    DeviceId: {
        type: Sequelize.STRING
    },
    ActiveFrom: {
        type: Sequelize.STRING,
    },
    ActiveTo: {
        type: Sequelize.STRING
    },
    RuleId: {
        type: Sequelize.STRING
    },
    RuleName: {
        type: Sequelize.STRING
    },
    Distance: {
        type: Sequelize.FLOAT
    },
    Duration: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
},{
    freezeTableName: true
})

module.exports = ExceptionEvent;