const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const TripsData = db.define('trips_data', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    DeviceName: {
        type: Sequelize.STRING,
    },
    DeviceId: {
        type: Sequelize.STRING
    },
    isDriving: {
        type: Sequelize.INTEGER
    },
    isCompleted: {
        type: Sequelize.INTEGER
    },
    detectedRoute: {
        type: Sequelize.STRING
    },
    busStation: {
        type: Sequelize.STRING
    },
    nextStops: {
        type: Sequelize.TEXT
    },
    checkpoint: {
        type: Sequelize.TEXT
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = TripsData;