const Sequelize = require("sequelize");
const db = require("../config/db.sequelize");

const CompletedTrips = db.define(
  "completedTrips",
  {
    id: {
      type: Sequelize.INTEGER,
      unique: true,
      primaryKey: true,
    },
    KL66FRGP: { type: Sequelize.STRING },
    HC01LGGP: { type: Sequelize.STRING },
    KL66DXGP: { type: Sequelize.STRING },
    FH92GXGP: { type: Sequelize.STRING },
    KL66GDGP: { type: Sequelize.STRING },
    KL66CLGP: { type: Sequelize.STRING },
    KL66GGGP: { type: Sequelize.STRING },
    KL66FLGP: { type: Sequelize.STRING },
    KN26SMGP: { type: Sequelize.STRING },
    KL66CDGP: { type: Sequelize.STRING },
    KL66DLGP: { type: Sequelize.STRING },
    KL66FFGP: { type: Sequelize.STRING },
    KL66DZGP: { type: Sequelize.STRING },
    HL74DZGP: { type: Sequelize.STRING },
    HL74FCGP: { type: Sequelize.STRING },
    HL74FHGP: { type: Sequelize.STRING },
    FV16NTGP: { type: Sequelize.STRING },
    FH92HNGP: { type: Sequelize.STRING },
    PWS077GP: { type: Sequelize.STRING },
    KL66CSGP: { type: Sequelize.STRING },
    date: {
      type: Sequelize.DATE,
    },
    createdAt: {
      type: Sequelize.DATE,
    },
    updatedAt: {
      type: Sequelize.DATE,
    },
  },
  {
    freezeTableName: true,
  }
);

module.exports = CompletedTrips;
