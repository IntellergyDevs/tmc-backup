const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const stopsSurroundingStops = db.define('stopsSurroundingStops', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    landmarkId: {
        type: Sequelize.INTEGER,
    },
    name: {
        type: Sequelize.STRING
    },
    Latitude: {
        type: Sequelize.STRING
    },
    Longitude: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    isActive: {
        type: Sequelize.INTEGER,
    }
}, {
    freezeTableName: true
})

module.exports = stopsSurroundingStops;