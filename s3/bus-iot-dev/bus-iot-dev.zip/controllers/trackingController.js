const moment = require('moment');

const utils = require('./authController');
const db = require('../db/db.sequelize');
const config = require('../config/config.json');
moment.tz.setDefault(config.timeZone.africaCairo);

const TrackingDetails = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback)
        let error = {};
        
        let req = event.queryStringParameters;
        let busId = req && req.busId ? req.busId : '';

        if (Object.keys(error).length == 0) {
            const tdate = moment().format('YYYY-MM-DD');
            let eventsList = []; let responseObj = {};

            let query, eventsQuery;
            if (busId && busId != 'all') {
                query = `SELECT DeviceId, DeviceName,Latitude,Longitude FROM logrecorddataset WHERE id IN (SELECT MAX(id) FROM logrecorddataset WHERE DeviceId = '${busId}' GROUP BY DeviceId)`;
                eventsQuery = `SELECT DeviceId,RuleId, RuleName, DeviceName, ActiveFrom AS createdAt FROM exceptioneventdataset WHERE DeviceId = '${busId}' AND createdAt >= DATE('${tdate}') ORDER BY id DESC`;
            } else {
                query = `SELECT DeviceId, DeviceName,Latitude,Longitude FROM logrecorddataset WHERE id IN (SELECT MAX(id) FROM logrecorddataset GROUP BY DeviceId) AND DeviceId IN (SELECT id FROM device WHERE isActive = 1)`;
                eventsQuery = `SELECT DeviceId,RuleId, RuleName, DeviceName, ActiveFrom AS createdAt FROM exceptioneventdataset WHERE createdAt >= DATE('${tdate}') ORDER BY id DESC`;
            }

            let [records, meta1] = await db.query(query, {});
            let [eventRecords, meta2] = await db.query(eventsQuery, {});
            records = records ? records : [];
            eventRecords = eventRecords ? eventRecords : [];

            responseObj['exceptionEvents'] = [];
            responseObj['location'] = [];

            records.forEach(element => {
                responseObj['location'].push({
                    geometry: {
                        type: 'Point',
                        coordinates: [Number(element.Longitude), Number(element.Latitude)]
                    },
                    type: 'Feature',
                    busInfo: {
                        busId: element.DeviceId,
                        busName: element.DeviceName
                    },
                    properties: {
    
                    }
                });
            });

            eventRecords.forEach(element => {
                if (typeof (responseObj['exceptionEvents'][element.DeviceId]) === 'undefined') {
                    responseObj['exceptionEvents'][element.DeviceId] = [];
                }
                responseObj['exceptionEvents'][element.DeviceId].push({
                    RuleId: element.RuleId,
                    RuleName: element.RuleName,
                    DeviceName: element.DeviceName,
                    DeviceId: element.DeviceId,
                    // date: moment(element.createdAt).format('YYYY-MM-DD HH:mm:ss'),
                    date: element.createdAt,
    
                });
            });

            Object.keys(responseObj['exceptionEvents']).forEach(element => {
                eventsList.push({
                    [element]: responseObj['exceptionEvents'][element]
                });
            });

            let message = 'No data found', status = 0, results = [];;
            if (records && records[0]) {
                message = 'Success';
                status = 1;
                results = {
                    location: responseObj['location'],
                    exceptionEvents: eventsList,
                };
            }

            callbackFn(200, status, message, results, error, callback);
        } else {
            let message = 'Insufficient Data provided.';
            callbackFn(200, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const BusTrackingDetail = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback)
        let error = {};
        
        let req = event.queryStringParameters;
        let busId = req && req.busId ? req.busId : '';

        if (Object.keys(error).length == 0) {
            const tdate = moment().format('YYYY-MM-DD');
            let eventsList = []; let responseObj = {};

            let query, eventsQuery;
            if (busId && busId != 'all') {
                query = `SELECT DeviceId, DeviceName,Latitude,Longitude FROM logrecorddataset WHERE id IN (SELECT MAX(id) FROM logrecorddataset WHERE DeviceId = '${busId}' GROUP BY DeviceId)`;
                eventsQuery = `SELECT DeviceId,RuleId, RuleName, DeviceName, ActiveFrom AS createdAt FROM exceptioneventdataset WHERE DeviceId = '${busId}' AND createdAt >= DATE('${tdate}') ORDER BY id DESC`;
            } else {
                query = `SELECT DeviceId, DeviceName,Latitude,Longitude FROM logrecorddataset WHERE id IN (SELECT MAX(id) FROM logrecorddataset GROUP BY DeviceId) AND DeviceId IN (SELECT id FROM device WHERE isActive = 1)`;
                eventsQuery = `SELECT DeviceId,RuleId, RuleName, DeviceName, ActiveFrom AS createdAt FROM exceptioneventdataset WHERE createdAt >= DATE('${tdate}') ORDER BY id DESC`;
            }

            let [records, meta1] = await db.query(query, {});
            let [eventRecords, meta2] = await db.query(eventsQuery, {});
            records = records ? records : [];
            eventRecords = eventRecords ? eventRecords : [];

            responseObj['exceptionEvents'] = [];
            responseObj['location'] = [];

            records.forEach(element => {
                responseObj['location'].push({
                    type: 'Feature',
                    geometry: {
                        type: 'Point',
                        coordinates: [Number(element.Longitude), Number(element.Latitude)]
                    },
                    busInfo: {
                        busId: element.DeviceId,
                        busName: element.DeviceName
                    },
                    properties: {
    
                    }
                });
            });

            eventRecords.forEach(element => {
                if (typeof (responseObj['exceptionEvents'][element.DeviceId]) === 'undefined') {
                    responseObj['exceptionEvents'][element.DeviceId] = [];
                }
                responseObj['exceptionEvents'][element.DeviceId].push({
                    RuleId: element.RuleId,
                    RuleName: element.RuleName,
                    DeviceName: element.DeviceName,
                    DeviceId: element.DeviceId,
                    // 'date': moment(element.createdAt).format('YYYY-MM-DD HH:mm:ss'),
                    date: element.createdAt,
    
                });
            });

            Object.keys(responseObj['exceptionEvents']).forEach(element => {
                eventsList.push({
                    [element]: responseObj['exceptionEvents'][element]
                });
            });

            let message = 'No data found', status = 0, results = [];;
            if (records && records[0]) {
                message = 'Success';
                status = 1;
                results = {
                    geometry: responseObj['location'][0].geometry,
                    type: 'Feature',
                    busInfo: responseObj['location'][0].busInfo,
                    exceptionEvents: eventsList,
                };
            }

            callbackFn(200, status, message, results, error, callback);
        } else {
            let message = 'Insufficient Data provided.';
            callbackFn(200, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};






const callbackFn = (statusCode, status, message, results, err, callback) => {
    callback(null, {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'X-Frame-Options': 'DENY',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            status,
            message,
            results,
            err,
        })
    });
};

module.exports = {
    TrackingDetails,
    BusTrackingDetail,
};
