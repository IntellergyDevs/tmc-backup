const jwt_decode = require('jwt-decode');
const moment = require('moment');

const utils = require('./authController');
const db = require('../db/db.sequelize');

const UserAdminStaticModel = require('../models/UserAdminStatic.model');

const UserStaticDetails = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        let user = jwt_decode(event.headers.Authorization.split(' ')[1]);

        let landmarks, busRoutes;
        let responseStops = [];
        let responseLandmarksStops = [];
        let error = {};

        // get routes
        if (user.associatedRoutes) {
            let parsedRoutes = user.associatedRoutes
            let sts = parsedRoutes.map(id => "'" + id + "'").join()

            let queryforStops = `SELECT B.id, A.centerPoint, A.name as Landmark, B.name, A.Latitude AS landmarkLat, A.Longitude AS landmarkLong, B.Latitude AS surroundLat, B.Longitude AS surroundLong, associatedRoutes FROM stopsLandmarks A LEFT JOIN stopsSurroundingStops B ON A.id = B.landmarkId WHERE A.name = '${user.associatedStation}'`;
            let queryforFullPath = `SELECT id, name, colorScheme, landmarkId, Latitude, Longitude FROM stopsFullPath WHERE name IN (${sts})`

            let busRoutes = db.query(`SELECT * FROM stoplocations_react WHERE routeAllocationName IN (${sts})`, {
                nest: true
            });
            const stopsAndLandmarks = db.query(queryforStops, {
                nest: true
            });

            let fullPath = db.query(queryforFullPath, {
                nest: true
            });

            await Promise.all([busRoutes, stopsAndLandmarks, fullPath]).then((values) => {
                let records = values[0]
                let landmarksRaw = values[1]
                let fullPath = values[2]
                let fullPathLocation = {};

                fullPath.forEach(element => {
                    if (typeof (fullPathLocation[element.name]) === 'undefined') {
                        fullPathLocation[element.name] = [];
                    }
                    fullPathLocation[element.name].push({
                        id: element.id,
                        latitude: Number(element.Latitude),
                        longitude: Number(element.Longitude),
                    })
                });
                let stopLocations = {};
                records.forEach(element => {
                    if (typeof (stopLocations[element.routeAllocationName]) === 'undefined') {
                        stopLocations[element.routeAllocationName] = {};
                        stopLocations[element.routeAllocationName]['id'] = element.routeAllocationName;
                        stopLocations[element.routeAllocationName]['name'] = element.routeAllocationName;
                        stopLocations[element.routeAllocationName]['routeStops'] = [];
                        stopLocations[element.routeAllocationName]['routeCoordinates'] = fullPathLocation[element.routeAllocationName] ? fullPathLocation[element.routeAllocationName] : []
                        stopLocations[element.routeAllocationName]['colorScheme'] = '#' + element.colorScheme;
                    }
                    stopLocations[element.routeAllocationName].routeStops.push({
                        message: element.StopNumber,
                        id: element.id,
                        longitude: Number(element.PointX),
                        latitude: Number(element.PointY),
                    })
                });
                Object.keys(stopLocations).forEach(element => {
                    responseStops.push(stopLocations[element]);
                });
                landmarks = landmarksRaw.filter((item, index, objects) => {
                    if (index === 0) {
                        return item
                    } else if (item.Landmark !== objects[index - 1].Landmark) {
                        return {
                            'name': item.Landmark,
                            'latitude': Number(item.landmarkLat),
                            'longitude': Number(item.landmarkLong),
                            'associatedRoutes': item.associatedRoutes,
                            'centerPoint': item.centerPoint,
                        };
                    }
                }).map(function (item) {
                    return {
                        'name': item.Landmark,
                        'latitude': Number(item.landmarkLat),
                        'longitude': Number(item.landmarkLong),
                        'associatedRoutes': JSON.parse(item.associatedRoutes),
                        'centerPoint': JSON.parse(item.centerPoint),
                    };
                });

                let landmarksWithStops = landmarksRaw.filter(({ id }) => id != null).map(function (item) {
                    return {
                        'Landmark': item.Landmark,
                        'name': item.name,
                        'latitude': Number(item.surroundLat),
                        'longitude': Number(item.surroundLong),
                        // 'centerPoint': JSON.parse(item.centerPoint),
                    };
                }).reduce((r, a) => {
                    r[a.Landmark] = [...r[a.Landmark] || [], a];
                    return r;
                }, {});

                Object.keys(landmarksWithStops).forEach((element, key) => {
                    responseLandmarksStops.push({
                        id: element,
                        name: element,
                        routeCoordinates: landmarksWithStops[element]
                    })
                });
                responseLandmarksStops.forEach((element, index) => {
                    let landmark = landmarks.filter(lm => lm.name == element.name)

                    responseLandmarksStops[index]['associatedRoutes'] = landmark && landmark[0] && landmark[0].associatedRoutes ? landmark[0].associatedRoutes : []
                })
            })
        }

        let message = 'Data fetched successfully';
        let results = {
            routes: responseStops,
            landmarks: {
                landmarkStops: landmarks, // main station points
                landmarkAreaCoordinates: responseLandmarksStops, // all polygon,
                centerPoint: landmarks && landmarks[0] && landmarks[0].centerPoint ? landmarks[0].centerPoint : null
            }
        };
        callbackFn(200, 1, message, results, error, callback);
    } catch (error) {
        console.log(error);
        callbackFn(401, 0, error.message, [], error, callback);
    }
}


const AllStaticDetails = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback)
        let error = {};
        if (Object.keys(error).length == 0) {

            let queryforStops = 'SELECT B.id, A.name as Landmark, B.name, A.Latitude AS landmarkLat, A.Longitude AS landmarkLong, B.Latitude AS surroundLat, B.Longitude AS surroundLong, associatedRoutes FROM stopsLandmarks A LEFT JOIN stopsSurroundingStops B ON A.id = B.landmarkId';
            let queryforFullPath = 'SELECT id, name, colorScheme, landmarkId, Latitude, Longitude FROM stopsFullPath'
            let busRoutes = db.query('SELECT * FROM stoplocations_react', {
                nest: true
            });
            const stopsAndLandmarks = db.query(queryforStops, {
                nest: true
            });
            // console.log('stopsAndLandmarks======>',stopsAndLandmarks)

            let fullPath = db.query(queryforFullPath, {nest: true});
            let toDate = moment().format('YYYY-MM-DD');
            let fromDate = moment().add(-30, 'days').format('YYYY-MM-DD');
            let getCountQuery = `SELECT DeviceId, COUNT(_id) AS count FROM exceptioneventdataset WHERE createdAt >= '${fromDate}' GROUP BY DeviceId`;
            let [getExceptionCounts, meta] = await db.query(getCountQuery, {raw: true,});
            // console.log('getExceptionCounts',getExceptionCounts);
            let totalExceptions = 0
            const totalDevice = getExceptionCounts.length;
            let deviceRating = {};
            getExceptionCounts.forEach(element => {
                totalExceptions += element.count
                deviceRating[element.DeviceId] = element.count
            });

            const avg = totalExceptions / totalDevice;
            const percentile = avg / 5;

            let outOf = [0, 0, 0, 0, 0];
            outOf.forEach((element, index) => {
                let num = avg - (index * percentile)
                outOf[index] = num
            });

            getExceptionCounts.forEach((element, index) => {
                let count = element.count
                let rating = outOf.filter(elem => count <= elem).length
                deviceRating[element.DeviceId] = rating
            });
            // console.log(toDate, fromDate);
            await Promise.all([busRoutes, stopsAndLandmarks, fullPath]).then((values) => {
                let records = values[0]
                let landmarksRaw = values[1]
                let fullPath = values[2]
                let fullPathLocation = {};

                fullPath.forEach(element => {
                    if (typeof (fullPathLocation[element.name]) === 'undefined') {
                        fullPathLocation[element.name] = [];
                    }
                    fullPathLocation[element.name].push({
                        id: element.id,
                        latitude: Number(element.Latitude),
                        longitude: Number(element.Longitude),
                    })
                });
                let stopLocations = {};
                records.forEach(element => {
                    if (typeof (stopLocations[element.routeAllocationName]) === 'undefined') {
                        stopLocations[element.routeAllocationName] = {};
                        stopLocations[element.routeAllocationName]['id'] = element.routeAllocationName;
                        stopLocations[element.routeAllocationName]['name'] = element.routeAllocationName;
                        stopLocations[element.routeAllocationName]['routeStops'] = [];
                        stopLocations[element.routeAllocationName]['routeCoordinates'] = fullPathLocation[element.routeAllocationName] ? fullPathLocation[element.routeAllocationName] : []
                        stopLocations[element.routeAllocationName]['colorScheme'] = '#' + element.colorScheme;
                    }
                    stopLocations[element.routeAllocationName].routeStops.push({
                        message: element.StopNumber,
                        id: element.id,
                        longitude: Number(element.PointX),
                        latitude: Number(element.PointY),
                    })
                });
                let responseStops = [];

                Object.keys(stopLocations).forEach(element => {
                    responseStops.push(stopLocations[element]);
                });
                let landmarks = landmarksRaw.filter((item, index, objects) => {
                    if (index === 0) {
                        return item
                    } else if (item.Landmark !== objects[index - 1].Landmark) {
                        return {
                            'name': item.Landmark,
                            'latitude': Number(item.landmarkLat),
                            'longitude': Number(item.landmarkLong),
                            'associatedRoutes': item.associatedRoutes
                        };
                    }
                }).map(function (item) {
                    return {
                        'name': item.Landmark,
                        'latitude': Number(item.landmarkLat),
                        'longitude': Number(item.landmarkLong),
                        'associatedRoutes': JSON.parse(item.associatedRoutes)
                    };
                });

                let landmarksWithStops = landmarksRaw.filter(({ id }) => id != null).map(function (item) {
                    return {
                        'Landmark': item.Landmark,
                        'name': item.name,
                        'latitude': Number(item.surroundLat),
                        'longitude': Number(item.surroundLong),
                    };
                }).reduce((r, a) => {
                    r[a.Landmark] = [...r[a.Landmark] || [], a];
                    return r;
                }, {});
                let responseLandmarksStops = [];
                Object.keys(landmarksWithStops).forEach((element, key) => {
                    responseLandmarksStops.push({
                        id: element,
                        name: element,
                        routeCoordinates: landmarksWithStops[element]
                    })
                });
                responseLandmarksStops.forEach((element, index) => {
                    let landmark = landmarks.filter(lm => lm.name == element.name)

                    responseLandmarksStops[index]['associatedRoutes'] = landmark && landmark[0] && landmark[0].associatedRoutes ? landmark[0].associatedRoutes : []
                });

                if (records && records[0]) {
                    let message = 'Stops and landmarks data fetched successfully';
                    let results = {
                        'type': 'FeatureCollection',
                        routes: responseStops,
                        landmarks: {
                            landmarkStops: landmarks, // main station points
                            landmarkAreaCoordinates: responseLandmarksStops // all polygon
                        },
                        deviceRating,
                        stats: {
                            totalExceptions,
                            avg
                        },
                    };

                    callbackFn(200, 1, message, results, error, callback);
                } else {
                    let message = 'No data found.';
                    callbackFn(200, 0, message, [], error, callback);
                }
            });
        } else {
            let message = 'Insufficient Data provided';
            callbackFn(200, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        callbackFn(401, 0, error.message, [], error, callback);
    }
};


const AllStaticDetailsByUser = async(event, context, callback)=>{
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        let error = {};

        if (auth.role === 'ADMIN'){
            const result = await UserAdminStaticModel.findOne({
                where:{userAdmin_id:auth.userId},
                attributes:['headerText','headerColor','legendBackground','busInfoBackground','logo'],
                raw:true
            });
            let message = 'Static Details fetched successfully';
            callbackFn(200, 1, message, result, error, callback);
        } else {
            let message = 'Unauthorized';
            callbackFn(401, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = 'Not available.';
        callbackFn(400, 0, message, [], error, callback);
    }
};

const UpdateStaticDetailsByUser = async(event,context,callback)=>{
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let requestBody = JSON.parse(event.body);
        let auth = await utils.checkAuth(event.headers, callback);
        let error = {};

        if(auth.role === 'ADMIN'){
            let userDetailsExist = await UserAdminStaticModel.findOne({where:{userAdmin_id:auth.userId},raw:true});
            if(userDetailsExist){
                // console.log(JSON.parse(event.body));
                let updatedStaticData = await UserAdminStaticModel.update(requestBody,{ where: {userAdmin_id: auth.userId}});
                // console.log(updatedStaticData);
                if(updatedStaticData[0] === 0){
                    let message = 'No update found.';
                    callbackFn(200, 0, message, userDetailsExist, error, callback);
                } else {
                    let updatedUserDetails = await UserAdminStaticModel.findOne({where:{userAdmin_id:auth.userId},raw:true});
                    let message = 'Static details updated successfully';
                    callbackFn(200, 1, message, updatedUserDetails, error, callback);
                }
            } else {
                let message = 'Unauthorized';
                callbackFn(401, 0, message, [], error, callback);
            }
        } else {
            let message = 'Unauthorized';
            callbackFn(401, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};







const callbackFn = (statusCode, status, message, results, err, callback) => {
    callback(null, {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'X-Frame-Options': 'DENY',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            status,
            message,
            results,
            err,
        })
    });
};


module.exports = {
    UserStaticDetails,
    AllStaticDetails,
    AllStaticDetailsByUser,
    UpdateStaticDetailsByUser,
};