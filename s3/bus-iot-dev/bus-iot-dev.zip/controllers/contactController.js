const utils = require('./authController');
const db = require('../db/db.sequelize');

const ContactsModel = require('../models/Contacts.model');

const GetContact = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        let error = {};

        if (Object.keys(error).length == 0) {
            let query = `SELECT * FROM contacts WHERE emailId = '${auth.email}'`;
            if(auth.role === 'ADMIN') {
                query = `SELECT * FROM contacts`;
            }
            console.log(query);
            
            let [records, meta] = await db.query(query, {});
            records = records ? records : [];

            if (records && records[0]) {
                let message = 'Contacts data fetched successfully.';
                let results = {
                    contacts: records
                };
                callbackFn(200, 1, message, results, error, callback);
            } else {
                let message = 'No Contacts data found.';
                callbackFn(200, 0, message, [], error, callback);
            }
        } else {
            let message = 'Insufficient Data provided.';
            callbackFn(200, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const AddContact = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        const req = JSON.parse(event.body);
        const { queryType, description } = req;

        if (!queryType || !description){
            let errMsg = 'Please enter all the required details';
            callbackFn(401, 0, errMsg, [], {}, callback);
            throw new Error(errMsg);
        }

        await ContactsModel.create(
            req
        ).then(async function (contact){
            let message = 'Contact added successfully';
            callbackFn(200, 1, message, contact, {}, callback);
        }).catch(async function (err) {
            console.log('errors===========>',err);

            let message = 'Validation Failed.';
            let errors = err.errors.map(function (record) {
                return record.message;
            });
            callbackFn(401, 0, message, [], errors, callback);
        });
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const UpdateContact = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        let error = {};

        const req = JSON.parse(event.body);
        let contactId = req.contactId;
        let requestBody = req.updateData;

        if (!contactId || !requestBody){
            let errMsg = 'Please enter all the details';
            callbackFn(401, 0, errMsg, [], {}, callback);
            throw new Error(errMsg);
        }
        let contactExist = await ContactsModel.findOne({where:{id: contactId},raw:true});
        // console.log(contactExist);

        if(auth.role === 'ADMIN' || contactExist.emailId == auth.email) {
            if(contactExist){
                let updatedContactData = await ContactsModel.update(requestBody,{ where: {id: contactId}});
                // console.log(updatedContactData);
                if(updatedContactData[0] === 0){
                    let message = 'No update found.';
                    callbackFn(200, 0, message, contactExist, error, callback);
                } else {
                    let updatedContactDetails = await ContactsModel.findOne({where:{id: contactId},raw:true});
                    let message = 'Contact updated successfully';
                    callbackFn(200, 1, message, updatedContactDetails, error, callback);
                }
            } else {
                let message = 'Invalid ContactId';
                callbackFn(401, 0, message, [], error, callback);
            }
        } else {
            let message = 'Unauthorized';
            callbackFn(401, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};



const callbackFn = (statusCode, status, message, results, err, callback) => {
    callback(null, {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'X-Frame-Options': 'DENY',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            status,
            message,
            results,
            err,
        })
    });
};


module.exports = {
    GetContact,
    AddContact,
    UpdateContact,
};