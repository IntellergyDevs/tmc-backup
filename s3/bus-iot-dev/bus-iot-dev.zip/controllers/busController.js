const moment = require('moment');

const utils = require('./authController');
const db = require('../db/db.sequelize');
const config = require('../config/config.json');


const StopLocationsModel = require('../models/StopLocations.model');
const StopsLandmarksModel = require('../models/StopsLandmarks.model');
const StopsSurroundingStopsModel = require('../models/StopsSurroundingStops.model');

const GetAllBuses = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        let error = {};

        moment.tz.setDefault(config.timeZone.africaCairo);

        if (Object.keys(error).length == 0) {
            let busLocations = {};
            let query = 'SELECT * FROM device LEFT JOIN deviceStatusInfo ON device.id = deviceStatusInfo.deviceID WHERE isActive = 1';
            let [records, meta] = await db.query(query, {});
            records = records ? records : [];

            if (records && records[0]) {
                const idleTime = 5;          //mins
                let finalResponse = records.map((value, index) => {
                    // console.log(value);

                    let isDriving = value.isDriving
                    let duration = value.currentStateDuration
                    let durationInMins = Number(moment(duration, 'hh:mm:ss').format("m"))
                    let status = '';
                    if (isDriving) {
                        status = 'running'
                    }
                    if (!isDriving) {
                        if (durationInMins <= idleTime) {
                            status = 'idle'
                        } else {
                            status = 'stopped'
                        }
                    }
                    // console.log(isDriving, duration, durationInMins, status);

                    return {
                        status,
                        statusDuration: duration,
                        latitude: Number(value.latitude),
                        longitude: Number(value.longitude),
                        id: value.deviceId,
                        DeviceName: value.DeviceName
                    }
                });

                let message = 'Bus data fetched successfully.';
                let results = {
                    buses: finalResponse
                };
                callbackFn(200, 1, message, results, error, callback);
            } else {
                let message = 'No bus data found.';
                callbackFn(200, 0, message, [], error, callback);
            }
        } else {
            let message = 'Insufficient Data provided.';
            callbackFn(200, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const GetDriverRatings = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        let error = {};

        moment.tz.setDefault(config.timeZone.africaCairo);
        let toDate = moment().format("YYYY-MM-DD");
        let fromDate = moment().add(-30, 'days').format("YYYY-MM-DD");

        if (true) {
            // console.log(toDate, fromDate);

            let totalExceptions = 0;
            let deviceRating = {};
            let outOf = [0, 0, 0, 0, 0];

            let getCountQuery = `SELECT DeviceId, COUNT(_id) AS count FROM exceptioneventdataset WHERE createdAt >= '${fromDate}' GROUP BY DeviceId`;
            let [getExceptionCounts, meta] = await db.query(getCountQuery, {
                raw: true,
            });
            const totalDevice = getExceptionCounts.length;

            getExceptionCounts.forEach(element => {
                totalExceptions += element.count;
                deviceRating[element.DeviceId] = element.count;
            });
            const avg = totalExceptions / totalDevice;
            const percentile = avg / 5;

            outOf.forEach((element, index) => {
                let num = avg - (index * percentile);
                outOf[index] = num;
            });

            getExceptionCounts.forEach((element, index) => {
                let count = element.count;
                let rating = outOf.filter(elem => count <= elem).length;
                deviceRating[element.DeviceId] = rating;
            });

            let message = 'Driver Ratings fetched successfully';
            let results = {
                deviceRating,
                stats: {
                    totalExceptions,
                    avg
                }
            };
            callbackFn(200, 1, message, results, error, callback);
        } else {
            let message = 'Insufficient Data provided';
            callbackFn(200, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};








const callbackFn = (statusCode, status, message, results, err, callback) => {
    callback(null, {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'X-Frame-Options': 'DENY',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            status,
            message,
            results,
            err,
        })
    });
};


module.exports = {
    GetAllBuses,
    GetDriverRatings,
};