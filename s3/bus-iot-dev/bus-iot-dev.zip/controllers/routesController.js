const { Op } = require('sequelize');
const db = require('../db/db.sequelize');
const NodeGeocoder = require('node-geocoder');

const config = require('../config/config.json');

const RoutesModel = require('../models/Routes.model');
const TripModel = require('../models/Trip.model');

const options = {
    provider: 'google',
    apiKey: config.google.map,
    formatter: null
};
const geocoder = NodeGeocoder(options);


const AvailableRoutes = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let search = {};
        search['isActive'] = {
            [Op.eq]: 1
        };

        await RoutesModel.findAndCountAll({
            raw: true,
            where: search,
            attributes: ['id', 'RouteAllocation', 'routeStart', 'routeEnd'],
            group: ['routeStart', 'routeEnd'],
        }).then(function (records) {
            let allRoutes = {}; let startRoutes = []; let allRoutesSend = [];

            records.rows.forEach(function (route, index) {
                if (startRoutes.indexOf(route.routeStart) === -1) {
                    startRoutes.push(route.routeStart);
                    allRoutes[route.routeStart] = [];
                }
            });
            records.rows.forEach(function (route, index) {
                allRoutes[route.routeStart].push({
                    routeEnd: route.routeEnd,
                    allocation: route.RouteAllocation,
                });
                
            });

            
            Object.keys(allRoutes).forEach(function (route, index) {
                allRoutesSend.push(allRoutes[route]);  
            });
            let results = {
                startUniqueRoutes: startRoutes,
                allRoutes: allRoutesSend,
            };

            let message = 'Records fetched successfully.';
            callbackFn(200, 1, message, results, {}, callback);
        }).catch(function (err) {
            console.log(err);
            let message = err.message;
            callbackFn(400, 0, message, [], err, callback);
        });
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const AppropriateBusList = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let error = {}; let search = {};
        let coords = {}; let timings = {};
        let page = 0;
        let req = JSON.parse(event.body);
        let limit = req.limit ? Number(req.limit) : 20;
        if (req != null && req.page != null) {
            page = 0 + Number(req.page) * limit || 0;
        }
        
        let sortBy = req != null && req.sort_by != null && req.sort_by != '' ? req.sort_by : 'id';
        let sortOrder = req != null && req.sort_order != null && req.sort_order != '' ? req.sort_order : 'ASC';
    
        if (req.routeAllocation) {
            search['RouteAllocation'] = {
                [Op.eq]: req.routeAllocation
            };
        } else {
            error['routeAllocation'] = 'Route Allocation cannot be empty';
        }

        if (req.userLat && req.userLng) {} else {
            error['Location'] = 'Location cannot be empty'
        }

        if (req.Date && req.Time) {} else {
            error['DateTime'] = 'Date Time cannot be empty';
        }


        if (Object.keys(error).length == 0) {
            let [results, metadata] = await db.query(
                `SELECT StopPointX, StopPointY, DeviceId FROM tripdataset GROUP BY DeviceId`, {
                raw: true,
            });
            await results.forEach(function (record, index) {
                coords[record.DeviceId] = record;
            });

            let [routeTimings, meta] = await db.query(
                `SELECT id,time FROM routetimings WHERE routeAllocationName = '${req.routeAllocation}'`, {
                raw: true,
            });
            await routeTimings.forEach(function (record, index) {
                timings[record.id] = record.time
            });


            await RoutesModel.findAndCountAll({
                raw: true,
                limit: limit,
                offset: page,
                where: search,
                order: [
                    [sortBy, sortOrder],
                ],
            }).then(async function (records) {
                let resRecords = records.rows;
    
                let resultsFiltered = [];
                records.rows.forEach(function (record, index) {
                    let points = coords[record.BusId];
                    console.log(points)
                    resRecords[index].distanceFromUser = calcCrow(req.userLat, req.userLng, points.StopPointY, points.StopPointX).toFixed(5);
                    resRecords[index].routeTimings = timings;
                    if (resRecords[index].distanceFromUser <= 5) {
                        resultsFiltered.push(resRecords[index])
                    }
                    console.log(resRecords[index].distanceFromUser);
                });
    
                let message = resultsFiltered.length == 0 ? 'No Buses found' : 'Records fetched successfully';
                callbackFn(200, 1, message, resultsFiltered, {}, callback);
            }).catch(function (err) {
                console.log(err);
                let message = err.message;
                callbackFn(400, 0, message, [], err, callback);
            });
        } else {
            let message = 'Insufficient Data provided.';
            callbackFn(200, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const GetSelectedBus = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let req = JSON.parse(event.body);
        let error = {};
        let search = {}; let timings = {};

        if (req.BusId) {
            search['BusId'] = {
                [Op.eq]: req.BusId
            }
        } else {
            error['BusId'] = 'Bus id cannot be empty.';
        }
        if (req.userLat && req.userLng) {
    
        } else {
            error['Location'] = 'Location coordinates cannot be empty.';
        }

        if (Object.keys(error).length == 0) {
            await RoutesModel.findAndCountAll({
                raw: true,
                where: search,
            }).then(async function (records) {
                let [routeTimings, meta] = await db.query(
                    `SELECT id,time FROM routetimings WHERE routeAllocationName = '${records.rows[0].RouteAllocation}'`, {
                    raw: true,
                });

                await routeTimings.forEach(function (record, index) {
                    timings[record.id] = record.time
                });

                await TripModel.findAll({
                    raw: true,
                    limit: 1,
                    order: [
                        ['id', 'DESC'],
                    ],
                    attributes: ['_id', 'StopPointX', 'StopPointY', 'StopDateTime', 'Distance', 'AverageSpeed'],
                    where: {
                        DeviceId: req.BusId
                    },
                }).then(async function (lastlocation) {
                    lastlocation[0].distanceFromUser = calcCrow(req.userLat, req.userLng, lastlocation[0].StopPointY, lastlocation[0].StopPointX).toFixed(1);
                    lastlocation[0].eta = (lastlocation[0].distanceFromUser * lastlocation[0].AverageSpeed) / 60;
                    const location = await geocoder.reverse({ lat: lastlocation[0].StopPointY, lon: lastlocation[0].StopPointX });
                    lastlocation[0].location = location[0].formattedAddress;
                    records.rows[0].lastKnownLocation = lastlocation;
                    records.rows[0].routeTimings = timings;
    
                    let message = records.length == 0 ? 'No Buses found' : 'Records fetched successfully';
                    callbackFn(200, 1, message, records, {}, callback);
                }).catch(function (err) {
                    console.log(err);
                    let message = err.message;
                    callbackFn(400, 0, message, [], err, callback);
                })
            }).catch(function (err) {
                console.log(err);
                let message = err.message;
                callbackFn(400, 0, message, [], err, callback);
            });
        } else {
            let message = 'Insufficient Data provided.';
            callbackFn(200, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const AvailableBuses = async (event, context, callback) => {

};




const callbackFn = (statusCode, status, message, results, err, callback) => {
    callback(null, {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'X-Frame-Options': 'DENY',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            status,
            message,
            results,
            err,
        })
    });
};

function calcCrow(lat1, lon1, lat2, lon2) {
    let R = 6371; // km
    let dLat = toRad(lat2 - lat1);
    let dLon = toRad(lon2 - lon1);
    lat1 = toRad(lat1);
    lat2 = toRad(lat2);

    let a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
    let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    let d = R * c;
    return d;
}
function toRad(Value) {
    return Value * Math.PI / 180;
}

module.exports = {
    AvailableRoutes,
    AppropriateBusList,
    GetSelectedBus,
    AvailableBuses,
};