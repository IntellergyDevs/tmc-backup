const moment = require('moment');
const querystring = require('querystring');
const { Op } = require('sequelize');

const config = require('../config/config.json');
const utils = require('./authController');

const NotificationsModel = require('../models/Notifications.model');
const MessagesBoardModel = require('../models/MessagesBoard.model');
const GtNewsModel = require('../models/GtNews.model');

//Notifications
const GetNotifications = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    moment.tz.setDefault(config.timeZone.africaCairo);
    try {
        let error = {};
        let search = {};
        let req = querystring.parse(event.body);
        let limit = req.limit ? Number(req.limit) : 20;
        let page = 0;
        if (req != null && req.page != null) {
            page = 0 + Number(req.page) * limit || 0;
        }

        let sortBy = req != null && req.sort_by != null && req.sort_by != '' ? req.sort_by : 'id';
        let sortOrder = req != null && req.sort_order != null && req.sort_order != '' ? req.sort_order : 'ASC';

        if (Object.keys(error).length == 0) {
            await NotificationsModel.findAndCountAll({
                raw: true,
                limit: limit,
                offset: page,
                where: search,
                order: [
                    [sortBy, sortOrder],
                ],
            }).then(async function (records) {
                let idsList = [];
                let response = await records.rows.map(function (record) {
                    let currentTime = moment().tz(config.timeZone.africaCairo).format('x');
                    let notifTime = moment(record.createdAt).tz(config.timeZone.africaCairo).format('x');
                    idsList.push(record.id);
                    let nrecord = {};
                    nrecord = record;
                    nrecord['diff'] = timeDiff(currentTime, notifTime);
                    return nrecord;
                });
                let pasrsedIds = idsList.map(id => '' + id + '').join();
    
                let message = records.count == 0 ? 'No Notifications found' : 'Notifications fetched successfully';
                let status = records.count == 0 ? 0 : 1;
                let results = { ...records, pasrsedIds }
                callbackFn(200, status, message, results, error, callback);
            }).catch(function (err) {
                console.log(err);
                let message = err.message;
                callbackFn(400, 0, message, [], err, callback);
            });
        } else {
            let message = 'Insufficient Data provided';
            callbackFn(200, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const AddNotifications = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        if(auth.role === 'ADMIN') {
            const req = JSON.parse(event.body);
            const { title, description} = req;

            if (!title || !description){
                let errMsg = 'Please enter all the required details';
                callbackFn(401, 0, errMsg, [], {}, callback);
                throw new Error(errMsg);
            }

            await NotificationsModel.create({
                notificationTitle: title,
                notificationDesctiption: description
            }).then(async function (contact){
                let message = 'Notification added successfully';
                callbackFn(200, 1, message, contact, {}, callback);
            }).catch(async function (err) {
                console.log('errors===========>',err);

                let message = 'Validation Failed.';
                let errors = err.errors.map(function (record) {
                    return record.message;
                });
                callbackFn(401, 0, message, [], errors, callback);
            });

        } else {
            let message = 'Unauthorized';
            callbackFn(401, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const UpdateNotifications = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        let error = {};

        const req = JSON.parse(event.body);
        let notificationId = req.notificationId;
        let requestBody = req.updateData;

        if (!notificationId || !requestBody){
            let errMsg = 'Please enter all the details';
            callbackFn(401, 0, errMsg, [], {}, callback);
            throw new Error(errMsg);
        }
        let notificationExist = await NotificationsModel.findOne({where:{id: notificationId},raw:true});
        // console.log(notificationExist);
        if(auth.role === 'ADMIN') {
            if(notificationExist){
                let updatedData = await NotificationsModel.update(requestBody,{ where: {id: notificationId}});
                // console.log(updatedData);
                if(updatedData[0] === 0){
                    let message = 'No update found.';
                    callbackFn(200, 0, message, notificationExist, error, callback);
                } else {
                    let updatedDetails = await NotificationsModel.findOne({where:{id: notificationId},raw:true});
                    let message = 'Notification updated successfully';
                    callbackFn(200, 1, message, updatedDetails, error, callback);
                }
            } else {
                let message = 'Invalid NotificationId';
                callbackFn(401, 0, message, [], error, callback);
            }
        } else {
            let message = 'Unauthorized';
            callbackFn(401, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};


// MessageBoard
const GetMessageBoard = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    moment.tz.setDefault(config.timeZone.africaCairo);
    try {
        let error = {};
        let search = {};

        let req = querystring.parse(event.body);
        let limit = req.limit ? Number(req.limit) : 20;
        let page = 0;
        if (req != null && req.page != null) {
            page = 0 + Number(req.page) * limit || 0;
        }
    
        let sortBy = req != null && req.sort_by != null && req.sort_by != '' ? req.sort_by : 'id';
        let sortOrder = req != null && req.sort_order != null && req.sort_order != '' ? req.sort_order : 'ASC';
        if (Object.keys(error).length == 0) {
            await MessagesBoardModel.findAndCountAll({
                raw: true,
                limit: limit,
                offset: page,
                where: search,
                attributes: [
                    'title', 'description'
                ],
                order: [
                    [sortBy, sortOrder],
                ],
            }).then(async function (records) {
                let message = records.count == 0 ? 'No Messages found' : 'Messages fetched successfully';
                let status = records.count == 0 ? 0 : 1;
                callbackFn(200, status, message, records, error, callback);
            }).catch(function (err) {
                console.log(err);
                let message = err.message;
                callbackFn(400, 0, message, [], err, callback);
            });
        } else {
            let message = 'Insufficient Data provided';
            callbackFn(200, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const AddMessageBoard = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        if(auth.role === 'ADMIN') {
            const req = JSON.parse(event.body);
            const { title, description} = req;

            if (!title || !description){
                let errMsg = 'Please enter all the required details';
                callbackFn(401, 0, errMsg, [], {}, callback);
                throw new Error(errMsg);
            }

            await MessagesBoardModel.create(
                req
            ).then(async function (contact){
                let message = 'Board Message added successfully';
                callbackFn(200, 1, message, contact, {}, callback);
            }).catch(async function (err) {
                console.log('errors===========>',err);

                let message = 'Validation Failed.';
                let errors = err.errors.map(function (record) {
                    return record.message;
                });
                callbackFn(401, 0, message, [], errors, callback);
            });

        } else {
            let message = 'Unauthorized';
            callbackFn(401, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const UpdateMessageBoard = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        let error = {};

        const req = JSON.parse(event.body);
        let Id = req.messagesId;
        let requestBody = req.updateData;

        if (!Id || !requestBody){
            let errMsg = 'Please enter all the details';
            callbackFn(401, 0, errMsg, [], {}, callback);
            throw new Error(errMsg);
        }
        let dataExist = await MessagesBoardModel.findOne({where:{id: Id},raw:true});
        // console.log(dataExist);
        if(auth.role === 'ADMIN') {
            if(dataExist){
                let updatedData = await MessagesBoardModel.update(requestBody,{ where: {id: Id}});
                // console.log(updatedData);
                if(updatedData[0] === 0){
                    let message = 'No update found.';
                    callbackFn(200, 0, message, dataExist, error, callback);
                } else {
                    let updatedDetails = await MessagesBoardModel.findOne({where:{id: Id},raw:true});
                    let message = 'MessagesBoard updated successfully';
                    callbackFn(200, 1, message, updatedDetails, error, callback);
                }
            } else {
                let message = 'Invalid NotificationId';
                callbackFn(401, 0, message, [], error, callback);
            }
        } else {
            let message = 'Unauthorized';
            callbackFn(401, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};


//GtNews
const GetGtNews = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    moment.tz.setDefault(config.timeZone.africaCairo);
    try {
        let error = {};

        let req = querystring.parse(event.body);
        let limit = req.limit ? Number(req.limit) : 20;
        let page = 0;
        if (req != null && req.page != null) {
            page = 0 + Number(req.page) * limit || 0;
        }

        let sortBy = req != null && req.sort_by != null && req.sort_by != '' ? req.sort_by : 'id';
        let sortOrder = req != null && req.sort_order != null && req.sort_order != '' ? req.sort_order : 'ASC';

        let search = {
            expiryDate: {
                [Op.gte]: new Date()
            }
        };
        if (Object.keys(error).length == 0) {
            await GtNewsModel.findAndCountAll({
                raw: true,
                // limit: limit,
                // offset: page,
                where: search,
                attributes: [
                    'title', 'description', 'imageUrl'
                ],
                order: [
                    [sortBy, sortOrder],
                ],
            }).then(async function (records) {
                let message = records.count == 0 ? 'No GT News found' : 'GT News fetched successfully';
                let status = records.count == 0 ? 0 : 1;
                callbackFn(200, status, message, records, error, callback);
            }).catch(function (err) {
                console.log(err);
                let message = err.message;
                callbackFn(400, 0, message, [], err, callback);
            });
        } else {
            let message = 'Insufficient Data provided';
            callbackFn(200, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const AddGtNews = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        if(auth.role === 'ADMIN') {
            const req = JSON.parse(event.body);
            const { title, description, expiryDate} = req;

            if (!title || !description || !expiryDate){
                let errMsg = 'Please enter all the required details';
                callbackFn(401, 0, errMsg, [], {}, callback);
                throw new Error(errMsg);
            }

            await GtNewsModel.create(
                req
            ).then(async function (contact){
                let message = 'GtNews added successfully';
                callbackFn(200, 1, message, contact, {}, callback);
            }).catch(async function (err) {
                console.log('errors===========>',err);

                let message = 'Validation Failed.';
                let errors = err.errors.map(function (record) {
                    return record.message;
                });
                callbackFn(401, 0, message, [], errors, callback);
            });

        } else {
            let message = 'Unauthorized';
            callbackFn(401, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const UpdateGtNews = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        let error = {};

        const req = JSON.parse(event.body);
        let Id = req.gtNewsId;
        let requestBody = req.updateData;

        if (!Id || !requestBody){
            let errMsg = 'Please enter all the details';
            callbackFn(401, 0, errMsg, [], {}, callback);
            throw new Error(errMsg);
        }
        let dataExist = await GtNewsModel.findOne({where:{id: Id},raw:true});
        // console.log(dataExist);
        if(auth.role === 'ADMIN') {
            if(dataExist){
                let updatedData = await GtNewsModel.update(requestBody,{ where: {id: Id}});
                // console.log(updatedData);
                if(updatedData[0] === 0){
                    let message = 'No update found.';
                    callbackFn(200, 0, message, dataExist, error, callback);
                } else {
                    let updatedDetails = await GtNewsModel.findOne({where:{id: Id},raw:true});
                    let message = 'GtNews updated successfully';
                    callbackFn(200, 1, message, updatedDetails, error, callback);
                }
            } else {
                let message = 'Invalid NotificationId';
                callbackFn(401, 0, message, [], error, callback);
            }
        } else {
            let message = 'Unauthorized';
            callbackFn(401, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};


const callbackFn = (statusCode, status, message, results, err, callback) => {
    callback(null, {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'X-Frame-Options': 'DENY',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            status,
            message,
            results,
            err,
        })
    });
};



function timeDiff(curr, prev) {

    var ms_Min = 60 * 1000;
    var ms_Hour = ms_Min * 60;
    var ms_Day = ms_Hour * 24;
    var ms_Mon = ms_Day * 30;
    var ms_Yr = ms_Day * 365;
    var diff = curr - prev;
    if (diff < ms_Min) {
        return Math.round(diff / 1000) + ' seconds ago';

    } else if (diff < ms_Hour) {
        return Math.round(diff / ms_Min) + ' minutes ago';

    } else if (diff < ms_Day) {
        return Math.round(diff / ms_Hour) + ' hours ago';

    } else if (diff < ms_Mon) {
        return 'Around ' + Math.round(diff / ms_Day) + ' days ago';

    } else if (diff < ms_Yr) {
        return 'Around ' + Math.round(diff / ms_Mon) + ' months ago';
    } else {
        return 'Around ' + Math.round(diff / ms_Yr) + ' years ago';
    }
}

module.exports = {
    GetNotifications,
    AddNotifications,
    UpdateNotifications,

    GetMessageBoard,
    AddMessageBoard,
    UpdateMessageBoard,

    GetGtNews,
    AddGtNews,
    UpdateGtNews,
};