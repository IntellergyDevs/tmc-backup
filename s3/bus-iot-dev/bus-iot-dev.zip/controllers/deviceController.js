const utils = require('./authController');
const db = require('../db/db.sequelize');

const DeviceModel = require('../models/Device.model');
const DeviceStatusInfoModel = require('../models/DeviceStatusInfo.model');


const GetDevice = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        let error = {};

        if (Object.keys(error).length == 0) {
            let query = 'SELECT * FROM device LEFT JOIN deviceStatusInfo ON device.id = deviceStatusInfo.deviceID';
            //WHERE isActive = 1
            let [records, meta] = await db.query(query, {});
            records = records ? records : [];

            if (records && records[0]) {
                let finalResponse = records.map((value, index) => {
                    return {
                        id: value.deviceId,
                        DeviceName: value.DeviceName,
                        latitude: Number(value.latitude),
                        longitude: Number(value.longitude),
                        application: value.application,
                    }
                });

                let message = 'Bus data fetched successfully.';
                let results = {
                    buses: finalResponse
                };
                callbackFn(200, 1, message, results, error, callback);
            } else {
                let message = 'No bus data found.';
                callbackFn(200, 0, message, [], error, callback);
            }
        } else {
            let message = 'Insufficient Data provided.';
            callbackFn(200, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const AddDevice = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);

        const req = JSON.parse(event.body);
        const { deviceId, deviceName, application } = req;

        if (!deviceId || !deviceName || !application){
            let errMsg = 'Please enter all the details';
            callbackFn(401, 0, errMsg, [], {}, callback);
            throw new Error(errMsg);
        }

        const deviceExist = await DeviceModel.findOne({
            where: {
                id: deviceId
            },
            raw: true
        });

        if (deviceExist) {
            let errMsg = 'This deviceId is already exist.';
            callbackFn(401, 0, errMsg, [], {}, callback);
            throw new Error(errMsg);
        }

        const device = {
            id: deviceId,
            DeviceName: deviceName,
            isActive: 1,
            application
        };

        await DeviceModel.create(
            device
        ).then(async function (device){
            // console.log('device========>',device);
            let newDevice = await DeviceModel.findOne({
                where: {
                    id: deviceId
                },
                raw: true
            });

            const deviceStatusInfo = {
                currentStateDuration: '00:00:00',
                isDeviceCommunicating:0,
                isDriving: 0,
                deviceId: deviceId,
            }
           return await DeviceStatusInfoModel.create(deviceStatusInfo);
        }).then(function (newDevice) {
            // console.log('device========>',device);
            let message = 'Device added successfully';
            let results = {
                device
            };
            callbackFn(200, 1, message, results, {}, callback);
        }).catch(async function (err) {
            console.log('errors===========>',err);

            let message = 'Validation Failed.';
            let errors = err.errors.map(function (record) {
                return record.message;
            });
            callbackFn(401, 0, message, [], errors, callback);
        });
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};

const UpdateDevice = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback);
        let error = {};

        const req = JSON.parse(event.body);
        let deviceId = req.deviceId;
        let requestBody = req.updateData;

        if (!deviceId || !requestBody){
            let errMsg = 'Please enter all the details';
            callbackFn(401, 0, errMsg, [], {}, callback);
            throw new Error(errMsg);
        }

        if(auth.role === 'ADMIN'){
            let deviceExist = await DeviceModel.findOne({where:{id: deviceId},raw:true});
            if(deviceExist){
                let updatedDeviceData = await DeviceModel.update(requestBody,{ where: {id: deviceId}});
                console.log(updatedDeviceData);
                if(updatedDeviceData[0] === 0){
                    let message = 'No update found.';
                    callbackFn(200, 0, message, deviceExist, error, callback);
                } else {
                    let updatedDeviceDetails = await DeviceModel.findOne({where:{id: deviceId},raw:true});
                    let message = 'Device updated successfully';
                    callbackFn(200, 1, message, updatedDeviceDetails, error, callback);
                }
            } else {
                let message = 'Invalid DeviceId';
                callbackFn(401, 0, message, [], error, callback);
            }
        } else {
            let message = 'Unauthorized';
            callbackFn(401, 0, message, [], error, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};



const callbackFn = (statusCode, status, message, results, err, callback) => {
    callback(null, {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'X-Frame-Options': 'DENY',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            status,
            message,
            results,
            err,
        })
    });
};


module.exports = {
    GetDevice,
    AddDevice,
    UpdateDevice,
};