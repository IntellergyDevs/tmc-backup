const moment = require('moment');
const GeotabApi = require('mg-api-js');

const utils = require('../authController');
const db = require('../../db/db.sequelize');
const config = require('../../config/config.json');
moment.tz.setDefault(config.timeZone.africaCairo);

const errorMessages = {
    'JSONRPCError - Incorrect login credentials': 'You can\'t view respective bus details that frequently',
    'JSONRPCError - API calls quota exceeded. Maximum admitted 10 per 1m.': 'You can\'t view respective bus details that frequently'
}

const authentication = {
    credentials: {
        database: config.geotab.database,
        userName: config.geotab.email,
        password: config.geotab.password,
    }
};
const api = new GeotabApi(authentication);

const GetBusLocationTrace = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback)
        let error = {};
        
        let req = event.queryStringParameters;
        let busId = req && req.busId ? req.busId : null;
        let fromDate = req && req.fromDate ? req.fromDate : new Date().toISOString();
        let toDate = req && req.toDate ? req.toDate : new Date().toISOString();
        console.log(fromDate, ' ', toDate);

        try {
            if (busId == null) {
                let errMsg = 'Please enter the BusId';
                callbackFn(401, 0, errMsg, [], error, callback);
                throw new Error(errMsg);
            }

            let queryAvgSpeed = `SELECT AVG(AverageSpeed) AS AverageSpeed FROM tripdataset WHERE DeviceId = '${busId}' AND StartDateTime >= '${fromDate}' AND StartDateTime <= '${toDate}'`;
            let queryFuelUsed = `SELECT Data AS FuelUsed FROM fuelusagedataset WHERE DeviceId = '${busId}' AND DateTime >= '${fromDate}' AND DateTime <= '${toDate}' ORDER BY FuelUsed ASC`;
            let queryIdlingTime = `SELECT SUM( Duration ) AS IdlingDuration FROM exceptioneventdataset WHERE DeviceId = 'bC' AND RuleId = 'RuleIdlingId' AND ActiveFrom >= '${fromDate}' AND ActiveFrom <= '${toDate}'`;
            let totalTripQ = `SELECT DeviceId, COUNT(DeviceId) AS toalTrips FROM tripdataset WHERE DeviceId = '${busId}' AND StartDateTime >= '${fromDate}' AND StopDateTime <= '${toDate}' GROUP BY DeviceId`;
        
            let totalDistanceTravelled = 0;
            let [BusAvgSpeed, metaAvgSpeed] = await db.query(queryAvgSpeed, {});
            let [BusFuelUsed, metaFuelUsed] = await db.query(queryFuelUsed, {});
            let [BusIdlingTime, metaIdlingTime] = await db.query(queryIdlingTime, {});
            let [totalTrip, metaTotalTrip] = await db.query(totalTripQ, {});
            BusAvgSpeed = BusAvgSpeed[0] ? BusAvgSpeed[0].AverageSpeed : '';
            BusIdlingTime = BusIdlingTime[0] ? BusIdlingTime[0].IdlingDuration : '';
            totalTrip = totalTrip[0] ? totalTrip[0] : [];

            let calls = [
                ['Get',
                    {
                        typeName: 'LogRecord',
                        search: {
                            fromDate: fromDate,
                            ToDate: toDate,
                            deviceSearch: { id: busId }
                        }
                    }
                ],
                ['Get', {
                    typeName: 'StatusData',
                    search: {
                        fromDate: fromDate,
                        ToDate: toDate,
                        deviceSearch: { id: busId },
                        diagnosticSearch: {
                            id: 'DiagnosticOdometerId'
                        },
                    }
                }],
            ];

            console.time('test');
            await api.multiCall(calls).then(data => {
                let BustotalDistance = data[1]
                console.log(BustotalDistance.length);

                if (BustotalDistance.length > 1) {
                    let first = BustotalDistance[0].data
                    let last = BustotalDistance[BustotalDistance.length - 1].data
                    console.log(first, last)
                    totalDistanceTravelled = last - first
                }
                console.timeEnd('test');
            
                let tracedRecords = []; 
                let fuelUsed = 0;
                let totalRecords = Math.floor(data[0].length / 100);

                if (totalRecords >= 2) {
                    // trim records
                    data[0].forEach((val, key) => {
                        if (key % totalRecords == 0) {
                            tracedRecords.push({
                                ...val,
                                // 'dateTime_utc': val.dateTime,
                                'dateTime': moment(val.dateTime).tz(config.timeZone.africaCairo).format(config.dateFormat.powerBi),
                            })
                        }
                    })
    
                } else {
                    data[0].forEach((val, key) => {
                        tracedRecords.push({
                            ...val,
                            // 'dateTime_utc': val.dateTime,
                            'dateTime': moment(val.dateTime).tz(config.timeZone.africaCairo).format(config.dateFormat.powerBi),
                        })
                    })
                }
                
                if (BusFuelUsed.length >= 2) {
                    fuelUsed = BusFuelUsed[BusFuelUsed.length - 1].FuelUsed - BusFuelUsed[0].FuelUsed
                }

                let message = 'Bus exceptions data fetched successfully.';
                let results = {
                    trace: tracedRecords,
                    info: {
                        0: data[0].length,
                        1: totalRecords
                    },
                    otherDetails: {
                        BustotalDistance: Number(totalDistanceTravelled / 1000),
                        BusAvgSpeed: BusAvgSpeed != null ? BusAvgSpeed : 0,
                        BusFuelUsed: fuelUsed,
                        BusIdlingTime,
                        totalTrips: totalTrip && totalTrip.toalTrips ? totalTrip.toalTrips : 0
                    }
                };
                callbackFn(200, 1, message, results, error, callback);
            }).catch(error => {
                console.log(error);
                let message = 'An internal server error occured';
                message = (error.message && errorMessages[error.message])?errorMessages[error.message]:error.message;
                callbackFn(200, 0, message, [], error, callback);
            });
            
        } catch (err) {
            let message = err.message ? err.message : 'An Internal server error occured';
            callbackFn(200, 0, message, [], err, callback);
        }
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};


const GetBusExceptions = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let message = 'Under Development';
        callbackFn(202, 0, message, [], {}, callback);
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};


const BusTrackingDetail = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let message = 'Under Development';
        callbackFn(202, 0, message, [], {}, callback);
    } catch (error) {
        console.log(error);
        let message = error.message;
        callbackFn(400, 0, message, [], error, callback);
    }
};






const callbackFn = (statusCode, status, message, results, err, callback) => {
    callback(null, {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'X-Frame-Options': 'DENY',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            status,
            message,
            results,
            err,
        })
    });
};


module.exports = {
    GetBusLocationTrace,
    GetBusExceptions,

    BusTrackingDetail,
};