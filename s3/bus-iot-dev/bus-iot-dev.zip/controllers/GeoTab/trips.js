const GeotabApi = require('mg-api-js');

const config = require('../../config/config.json');
const authentication = {
    credentials: {
        database: config.geotab.database,
        userName: config.geotab.email,
        password: config.geotab.password,
    }
}
const api = new GeotabApi(authentication);

module.exports.insertTrips = async (event, context, callback) => {
    let limit = 50000;
    let typeName = 'Trip';

    try {
        console.log('before API call try block');
        
        await api.call('Get', {
            typeName: typeName,
            resultsLimit: limit,
            search: {
                'fromDate': '2022-03-16T00:00:00.000Z',
            }
        }).then(async function (records) {
            console.log('then b for records');
            console.log('length: ', records.length);
            
            callbackFn(200, 1, 'Done', records, {}, callback);
        }).catch(error => {
            console.log(error);
            callbackFn(402, 0, 'Error Occured', [], error, callback);
        });
    } catch (error) {
        console.log(error);
        callbackFn(400, 0, 'Error Occured', [], error, callback);
    }
}


const callbackFn = (statusCode, status, message, results, err, callback) => {
    callback(null, {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'X-Frame-Options': 'DENY',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            status,
            message,
            results,
            err,
        })
    });
};