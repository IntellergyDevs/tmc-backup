const AWS = require('aws-sdk');
const moment = require('moment');

const Device = require('../../models/Device.model');
const DeviceStatusInfoModel = require('../../models/DeviceStatusInfo.model')
const LogRecordModel = require('../../models/LogRecord.model');
const TripModel = require('../../models/Trip.model');

const config = require('../../config/config.json');
const s3 = new AWS.S3({region: config.aws.region});

const SNS_FirehoseLambda = async (event) => {
    try {
        let message = event.Records[0].Sns.Message;
        let parsedMessage = JSON.parse(message);
        // console.log('Received MESSAGE: ' + message);

        let deviceDetailsExist = await DeviceStatusInfoModel.findOne({ where: { deviceId: parsedMessage.imei }, raw: true });
        // console.log('deviceDetailsExist: ', deviceDetailsExist);
        if (deviceDetailsExist){
            let imei = parsedMessage.imei;
            let DeviceName = await getDeviceInfo(imei);

            if (parsedMessage && parsedMessage.reconnect) {
                let requestBody = {
                  status: 'reconnect',
                  isDeviceCommunicating: 1,
                  isDriving: 1,
                  updatedAt : new Date()
                };
                await DeviceStatusInfoModel.update(requestBody, { where: { deviceId: parsedMessage.imei } });
            }

            if (parsedMessage && parsedMessage.reason) {
                // console.log('parsedMessage:', parsedMessage);
                let requestBody = {
                  status: parsedMessage.reason,
                  isDeviceCommunicating: 1,
                  isDriving: 0,
                  updatedAt: new Date(),
                };
                await DeviceStatusInfoModel.update(requestBody, { where: { deviceId: parsedMessage.imei } });
            }

            if (parsedMessage && parsedMessage.fullPosition) {
                let Locations = parsedMessage.fullPosition;
                let currentLocation = Locations.slice(-1);
                currentLocation.transmissionReason = parsedMessage.transmissionReason;
                currentLocation.imei = parsedMessage.imei;
                // console.log('currentLocation:', currentLocation[0]);

                let requestBody = {
                    latitude: currentLocation[0].lat,
                    longitude: currentLocation[0].long,
                    status: parsedMessage.transmissionReason,
                    isDeviceCommunicating: 1,
                    isDriving: 1,
                    updatedAt : new Date()
                };
                let d1 = await DeviceStatusInfoModel.update(requestBody, { where: { deviceId: parsedMessage.imei } });
                // console.log('DeviceStatusInfoModel:', d1);

                try {
                    let records = Locations.slice(-1);
                    records = records.map(function (record) {
                        let nrecord = {};

                        // let recordTimestamp = parseInt(parsedMessage.syncedTime + ((record.timestamp - parsedMessage.timestamp) / 1000));
                        let syncedTime = Number(parsedMessage.syncedTime);
                        let timestampD = Math.round((Number(record.timestamp) - Number(parsedMessage.timestamp)) / 1000);
                        let recordTimestamp = parseInt(syncedTime + timestampD);
                        // let parsedTimestamp = moment(recordTimestamp).format(config.dateFormat.powerBi);
                        let d = new Date(0);
                        d.setUTCSeconds(recordTimestamp);
                        let parsedTimestamp = moment(d).format(config.dateFormat.powerBi);
                        nrecord['DateTime'] = moment(parsedTimestamp).format(config.dateFormat.powerBi);
                        nrecord['DeviceName'] = DeviceName;
                        nrecord['DeviceId'] = parsedMessage.imei;
                        nrecord['Latitude'] = record.lat;
                        nrecord['Longitude'] = record.long;
                        nrecord['Speed'] = record.speed;
                        nrecord['createdAt'] = new Date();

                        console.log(parsedMessage.syncedTime, record.timestamp, parsedMessage.timestamp);
                        console.log(recordTimestamp, parsedTimestamp);
                        // console.log(nrecord);
                        return nrecord;
                    });

                    let filtered = records.filter(function (el) {
                        return el != null;
                    });

                    await LogRecordModel.bulkCreate(
                        filtered, {
                        ignoreDuplicates: true
                    }).then(function () {
                        console.log('then b sequelize');
                    }).catch(function (err) {
                        console.log('insert error',err.message);
                    });
                } catch (error) {
                    console.log('LogRecord error: ', error);
                }
            }
        } else {
            console.log('error while finding deviceId.', deviceDetailsExist)
        }

        return message;
    } catch (error) {
        console.log('Received error: ', error);
        return error;
    }
};

const SNS_DynamoDbLambda = async (event) => {
    try {
        let message = event.Records[0].Sns.Message;
        let parsedMessage = JSON.parse(message);
        console.log('Received MESSAGE: ' + message);


        let imei = parsedMessage.imei.S;
        let deviceDetailsExist = await DeviceStatusInfoModel.findOne({ where: { deviceId: imei }, raw: true });
        // console.log('deviceDetailsExist: ', deviceDetailsExist);
        let DeviceName = await getDeviceInfo(imei);

        let logExist = await TripModel.findOne({ where: { _id: parsedMessage.tripId.S }, raw: true });
        // console.log('logExist: ', logExist);

        if (deviceDetailsExist){
            try {
                let StartDateTime = moment(Number(parsedMessage.timestampStart.N)).format(config.dateFormat.powerBi);
                let StopDateTime = moment(Number(parsedMessage.timestampEnd.N)).format(config.dateFormat.powerBi);
                
                let tripLength = Number(parsedMessage.tripLength.N) / 1000;
                let duration = Number(parsedMessage.duration.N) / (60*1000);

                let StartAddress = ''; let EndAddress = '';
                try {
                    let StartAddressObj = parsedMessage.startAddress.M;
                    let EndAddressObj = parsedMessage.endAddress.M;
                    StartAddress = StartAddressObj.label.S;
                    EndAddress = EndAddressObj.label.S;
                } catch (error) {
                    // let StartAddressFull = `label: ${StartAddressObj.label.S}, street: ${StartAddressObj.street.S}, city: ${StartAddressObj.city.S}, state: ${StartAddressObj.state.S}, postalCode: ${StartAddressObj.postalCode.S}, country: ${StartAddressObj.countryName.S}`;
                    // let EndAddressFull = `label: ${EndAddressObj.label.S}, street: ${EndAddressObj.street.S}, city: ${EndAddressObj.city.S}, state: ${EndAddressObj.state.S}, postalCode: ${EndAddressObj.postalCode.S}, country: ${EndAddressObj.countryName.S}`;
                }
                
                if(logExist) {
                    dataProcess_SNS_DynamoDbLambda({tripId: parsedMessage.tripId.S});
                } else {
                    let records = {
                        _id: parsedMessage.tripId.S,
                        DeviceId: imei,
                        DeviceName,
                        StartDateTime,
                        StopDateTime,
                        Distance: tripLength,
                        DrivingDuration: duration,

                        IdlingDuration: 0,
                        StopDuration: 0,
                        WorkDistance: tripLength,
                        WorkDrivingDuration: duration,
                        WorkStopDuration: 0,

                        StartAddress,
                        EndAddress,
                        processed: 0,
                    };

                    await TripModel.create(
                        records
                    ).then(function () {
                        console.log('then b sequelize');
                        dataProcess_SNS_DynamoDbLambda({tripId: parsedMessage.tripId.S});
                    }).catch(function (err) {
                        console.log('insert error',err.message);
                    });
                }
            } catch (error) {
                console.log('LogRecord error: ', error);
            }
        } else {
            console.log('error while finding deviceId.', deviceDetailsExist)
        }

        return message;
    } catch (error) {
        console.log('Received error: ', error);
        return error;
    }
};

const getDeviceInfo = async(imei) => {
    let all_devices = [];
    let devices = await Device.findAll({
        attributes: ['id', 'DeviceName'],
        raw: true
    });
    await devices.forEach(function (device, index) {
        all_devices[device.id] = device.DeviceName
    });
    let DeviceName = typeof (all_devices[imei]) != 'undefined' ? all_devices[imei] : '';
    return DeviceName;
}

const dataProcess_SNS_DynamoDbLambda = async (event) => {
    try {
        // console.log(event);
        let tripId = event.tripId || '000fec2e-b636-36a0-aeba-a56b1502ac34';
        let bucket = event.bucket || `pilabs-at-473913856290/tixs/trips/raw/${tripId}`;
        let file = event.filename || 'trip.json';

        let s3data = await s3.getObject({
            Bucket: bucket,
            Key: file
        }).promise();
        let data = JSON.parse(s3data.Body.toString());
        let {imei, startTime, endTime, fullPosition, acceleration} = data;
        startTime = moment(startTime).format(config.dateFormat.powerBi);
        endTime = moment(endTime).format(config.dateFormat.powerBi);
        let DeviceName = await getDeviceInfo(imei);

        const startPoint = {lat: fullPosition[0].lat, long: fullPosition[0].long};
        const endPoint = {lat: fullPosition.slice(-1)[0].lat, long: fullPosition.slice(-1)[0].long};
        const speedArr = fullPosition.map(x => x.speed);
        const maximumSpeed = Math.max(...speedArr);
        const averageSpeed = speedArr.reduce((a, b) => a + b, 0)/speedArr.length;
        // console.log(imei, startTime, endTime, fullPosition.length, startPoint, endPoint, averageSpeed, maximumSpeed);
        
        let updatedData = await TripModel.update({
            StartPointX: startPoint.lat,
            StartPointY: startPoint.long,
            StopPointX: endPoint.lat,
            StopPointY: endPoint.long,
            AverageSpeed: averageSpeed,
            MaximumSpeed: maximumSpeed,
            processed: 1,
        },{ where: {_id: tripId}});
        // console.log(updatedData);


        let timestampPrv = startTime, timeDiffArr = [];
        let speedPrv = 0; let records = [];
        fullPosition.forEach((element, index) => {
            let timestamp = moment(element.timestamp).format(config.dateFormat.powerBi);
            let diffSec = Math.round((new Date(timestamp) - new Date(timestampPrv))/1000);
            let speedDiff = element.speed - speedPrv;
            let acceleration = speedDiff == 0?0 : diffSec == 0?0 : speedDiff/diffSec;
            let deceleration = acceleration * -1;
            let RuleName = '';

            let nrecord = {
                DateTime: timestamp,
                DeviceName,
                DeviceId: imei,
                Latitude: element.lat,
                Longitude: element.long,
                Speed: element.speed,
                createdAt: new Date()
            };
            records.push(nrecord);

            
            if (element.speed == 0 && diffSec > 19) {
                RuleName = 'Fleet Idling';
            }
            if(acceleration > 12) { // accelerates to 13km/h in 1 second this is harsh acceleration
                RuleName = 'Harsh Acceleration';
            }
            if(deceleration > 9) { // decelerates to 10km/h in 1 second this is harsh braking
                RuleName = 'Harsh Braking';
            }

            if(acceleration > 99) { // exceed 100km/p in 5 second this is considered as speeding
                RuleName = 'Speeding exception';
            }

            if (diffSec > 0) {
                timestampPrv = timestamp;
                speedPrv = element.speed;
            }
            // timestamp, timestampPrv, 
            // console.log(diffSec, speedDiff, acceleration, RuleName);

        });

        console.log(records.length);
    } catch (error) {
        console.log(error);
    }
};

const TripDataProcess = async (event, context, callback) => {
    let req = JSON.parse(event.body);
    let { tripId } = req;
    
    dataProcess_SNS_DynamoDbLambda({tripId});
    callbackFn(callback, 'Done');
}

const TripDataProcessAll = async (event, context, callback) => {
    let unProcessedLog = await TripModel.findAll({ where: { processed: 0 }, raw: true });

    unProcessedLog.forEach(element => {
        // console.log(element);
        dataProcess_SNS_DynamoDbLambda({tripId: element._id});
    });
    
    callbackFn(callback, 'Done: ' + unProcessedLog.length);
}


const callbackFn = (callback, message) => {
    callback(null, {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/json',
            'X-Frame-Options': 'DENY',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            message,
        })
    });
};

module.exports = {
    SNS_FirehoseLambda,
    SNS_DynamoDbLambda,

    TripDataProcess,
    TripDataProcessAll,
};
