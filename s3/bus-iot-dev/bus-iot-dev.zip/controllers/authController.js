const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const UserAdminModel = require('../models/UserAdmin.model');
const UserAdminStaticModel = require('../models/UserAdminStatic.model')

const JWT_SECRET_KEY = 'aGPuWz7Q3V2mJMBqixCL';



let errorMessages = {
    'jwt expired': 'Session Timeout !!',
    'invalid signature': 'Invalid Session',
    'jwt malfunctioned': 'Session Compromised !!!, Logging you out ...',
    'jwt malformed': 'Session Compromised !!!, Logging you out ...',
    'Auth token is missing': 'Auth token is missing'
};




const Login = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        const req = JSON.parse(event.body);
        const { email, password } = req;
        const isMicrosoftUser = req.isMicrosoftUser ? req.isMicrosoftUser : false;
       
        if (!email || !password){
            let errMsg = 'Please enter all the details';
            callbackFn(401, 0, errMsg, [], {}, callback);
            throw new Error(errMsg);
        }
    
        const user = await UserAdminModel.findOne({
            where: {
                email: email
            },
            raw: true
        });

        
        if (!user && !isMicrosoftUser) {
            if (!isMicrosoftUser) {
                let errMsg = 'Your account is not registered.';
                callbackFn(401, 0, errMsg, [], {}, callback);
                throw new Error(errMsg);
            } else {
                let errMsg = 'You are not authorized to access this. Please contact to sensifeye administrator.';
                callbackFn(401, 0, errMsg, [], {}, callback);
                throw new Error(errMsg);
            }
        } else {
            // console.log(user);
            if (user.isVerified == 0) {
                let errMsg = 'Your account is not yet verified';
                callbackFn(401, 0, errMsg, [], {}, callback);
                throw new Error(errMsg);
            }
            if (user.status == 0) {
                let errMsg = 'Your account has been made inactive';
                callbackFn(401, 0, errMsg, [], {}, callback);
                throw new Error(errMsg);
            }

            const isValidPass = await bcrypt.compare(
                password,
                user.password
            );

            if (!isValidPass && !isMicrosoftUser) {
                let errMsg = 'Password is incorrect';
                callbackFn(401, 0, errMsg, [], {}, callback);
                throw new Error(errMsg);
            }
    
            let expiry = user.role == 'ADMIN' ? { expiresIn: '1h' } : {}
            const token = jwt.sign({
                userId: user.id, 
                email: user.email, 
                role: user.role, 
                associatedStation: user.associatedStation,
                associatedRoutes: JSON.parse(user.associatedRoutes),
            }, JWT_SECRET_KEY, expiry);

            let message = 'You have successfully logged in';
            let results = {
                user: {
                    email: user.email,
                    firstName: user.firstName,
                    lastName: user.lastName,
                    name: user.name,
                    station: user.associatedStation,
                    routes: JSON.parse(user.associatedRoutes),
                    role: user.role,
                },
                token
            };
            callbackFn(200, 1, message, results, {}, callback);
        }
    } catch (error) {
        console.log(error);
        callbackFn(401, 1, error.message, [], error, callback);
    }
    
};

const SignUp = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        const req = JSON.parse(event.body);
        const { email, firstName, lastName, password } = req;

        if (!email || !firstName || !lastName || !password){
            let errMsg = 'Please enter all the details';
            callbackFn(401, 0, errMsg, [], {}, callback);
            throw new Error(errMsg);
        }

        let passwordErrors = validatePassword(password)
        if (passwordErrors.length > 0) {
            let errMsg = passwordErrors[0];
            callbackFn(401, 0, errMsg, [], {}, callback);
            throw new Error(passwordErrors);
        }
        const passwordHash = await bcrypt.hash(password, 10);

        const userExist = await UserAdminModel.findOne({
            where: {
                email: email
            },
            raw: true
        });

        if (userExist) {
            let errMsg = 'This email is already registered';
            callbackFn(401, 0, errMsg, [], {}, callback);
            throw new Error(errMsg);
        }

        const user = {
            email,
            firstName,
            lastName,
            name: firstName + ' ' + lastName,
            password: passwordHash,
            isVerified: 1,
            status: 1
        };


        await UserAdminModel.create(
            user
        ).then(async function (user){
            // console.log('user========>',user);

            let userInfo = await UserAdminModel.findOne({
                where: {
                    email: email
                },
                raw: true
            });
            const userDetail = {
                headerText:'#ffffff',
                headerColor:'#2d2d2d',
                legendBackground:'#2d2d2d',
                busInfoBackground:'#2d2d2d',
                logo:'Mini Bus Tracker',
                userAdmin_id:userInfo.id
            }
           return await UserAdminStaticModel.create(userDetail);
        }).then(function (userData) {
            // console.log('user========>',user);
            let message = 'User added successfully';
            let results = {
                user: {
                    email: user.email,
                    name: user.name,
                }
            };
            callbackFn(200, 1, message, results, {}, callback);
        }).catch(async function (err) {
            console.log('errors===========>',err);

            let message = 'Validation Failed.';
            let errors = err.errors.map(function (record) {
                return record.message;
            });
            callbackFn(401, 0, message, [], errors, callback);
        });
    } catch (error) {
        console.log(error);
        callbackFn(401, 0, error.message, [], errors, callback);
    }
};


const checkAuth = (headers, callback) => {
    return new Promise(resolve => {
        try {

            if (!headers.Authorization) {
                throw new Error('Auth token is missing')
            }
            let token = headers.Authorization.split(' ')[1]
            if (!token) {
                throw new Error('Auth token is missing')
            }

            let decoded = jwt.verify(token, JWT_SECRET_KEY);
            resolve(decoded)
        } catch (error) {
            // console.log(error);
            let errorMsg = (error.message && errorMessages[error.message])? errorMessages[error.message] : 'Something went wrong';
            let errorCode = (error.message && errorMessages[error.message])? 403 : 500;
            callbackFn(errorCode, 0, errorMsg, [], error, callback);
        }
    });
};

const parseJwt = (token) => {
    return JSON.parse(jsonPayload);
};

const callbackFn = (statusCode, status, message, results, errors, callback) => {
    callback(null, {
        statusCode: statusCode,
        headers: {
            'Content-Type': 'application/json',
            'X-Frame-Options': 'DENY',
            'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
            status,
            message,
            results,
            errors,
        })
    });
};

const validatePassword = (password) => {
    errors = [];
    if (password.length < 8) {
        errors.push('Your password must be at least 8 characters');
    }
    if (password.search(/[a-z]/i) < 0) {
        errors.push('Your password must contain at least one letter.');
    }
    if (password.search(/[0-9]/) < 0) {
        errors.push('Your password must contain at least one digit.');
    }
    return errors;
};

module.exports = {
    Login,
    SignUp,
    
    checkAuth,
    parseJwt,
};
