
CREATE TABLE `logrecorddataset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `DateTime` datetime DEFAULT NULL,
  `DeviceName` varchar(255) DEFAULT NULL,
  `DeviceId` varchar(255) DEFAULT NULL,
  `Latitude` varchar(255) DEFAULT NULL,
  `Longitude` varchar(255) DEFAULT NULL,
  `Speed` float DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=545 DEFAULT CHARSET=latin1;


CREATE TABLE `tripdataset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `_id` varchar(255) NOT NULL,
  `DeviceName` varchar(255) DEFAULT NULL,
  `DeviceId` varchar(255) DEFAULT NULL,
  `StartDateTime` datetime DEFAULT NULL,
  `StartPointX` varchar(255) DEFAULT NULL,
  `StartPointY` varchar(255) DEFAULT NULL,
  `StartAddress` text,
  `StopDateTime` datetime DEFAULT NULL,
  `StopPointX` varchar(255) DEFAULT NULL,
  `StopPointY` varchar(255) DEFAULT NULL,
  `Distance` float DEFAULT NULL,
  `AverageSpeed` float DEFAULT NULL,
  `DrivingDuration` float DEFAULT NULL,
  `MaximumSpeed` float DEFAULT NULL,
  `IdlingDuration` float DEFAULT NULL,
  `StopDuration` float DEFAULT NULL,
  `EndAddress` text,
  `NextTripStart` datetime DEFAULT NULL,
  `WorkDistance` float DEFAULT NULL,
  `WorkDrivingDuration` float DEFAULT NULL,
  `WorkStopDuration` float DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unique` (`_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `logrecordDynamoDB` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `_id` varchar(255) NOT NULL,
  `DeviceName` varchar(255) DEFAULT NULL,
  `DeviceId` varchar(255) DEFAULT NULL,
  `StartDateTime` datetime DEFAULT NULL,
  `StartPointX` varchar(255) DEFAULT NULL,
  `StartPointY` varchar(255) DEFAULT NULL,
  `StartAddress` text,
  `StopDateTime` datetime DEFAULT NULL,
  `StopPointX` varchar(255) DEFAULT NULL,
  `StopPointY` varchar(255) DEFAULT NULL,
  `Distance` float DEFAULT NULL,
  `AverageSpeed` float DEFAULT NULL,
  `DrivingDuration` float DEFAULT NULL,
  `MaximumSpeed` float DEFAULT NULL,
  `IdlingDuration` float DEFAULT NULL,
  `StopDuration` float DEFAULT NULL,
  `EndAddress` text,
  `NextTripStart` datetime DEFAULT NULL,
  `WorkDistance` float DEFAULT NULL,
  `WorkDrivingDuration` float DEFAULT NULL,
  `WorkStopDuration` float DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unique` (`_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `busId` varchar(32) DEFAULT NULL,
  `Status` varchar(128) DEFAULT NULL,
  `RegistrationNumber` varchar(128) DEFAULT NULL,
  `VinNumber` varchar(128) DEFAULT NULL,
  `VehicleDescription` varchar(128) DEFAULT NULL,
  `StationAllocation` varchar(128) DEFAULT NULL,
  `RouteAllocation` varchar(128) DEFAULT NULL,
  `AlternatingVehiclesStation` varchar(128) DEFAULT NULL,
  `AlternatingVehicleRoutes` varchar(128) DEFAULT NULL,
  `routeStart` varchar(255) DEFAULT NULL,
  `routeEnd` varchar(255) DEFAULT NULL,
  `stationLocation` varchar(255) DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `isActive` int(1) DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idindex` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

CREATE TABLE `routetimings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `routeAllocationName` varchar(255) DEFAULT NULL,
  `routeId` int(11) DEFAULT NULL,
  `time` varchar(16) DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8;

CREATE TABLE `routeDetermination` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deviceName` varchar(255) DEFAULT NULL,
  `deviceId` varchar(8) DEFAULT NULL,
  `totalCountables` text,
  `isBusInStation` int(1) DEFAULT NULL,
  `isRouteReset` int(1) DEFAULT NULL,
  `currentStation` varchar(255) DEFAULT NULL,
  `currentRouteDetermined` varchar(255) DEFAULT NULL,
  `pastList` text,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `deviceIndex` (`deviceId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=200980 DEFAULT CHARSET=latin1;