const Sequelize = require('sequelize');
const db = require('../db/db.sequelize');

const BusRoutes = db.define('routes', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    BusId: {
        type: Sequelize.STRING
    },
    Status: {
        type: Sequelize.STRING
    },
    RegistrationNumber: {
        type: Sequelize.STRING
    },
    VinNumber: {
        type: Sequelize.STRING
    },
    VehicleDescription: {
        type: Sequelize.STRING
    },
    StationAllocation: {
        type: Sequelize.STRING
    },
    RouteAllocation: {
        type: Sequelize.STRING
    },
    AlternatingVehiclesStation: {
        type: Sequelize.STRING
    },
    AlternatingVehicleRoutes: {
        type: Sequelize.STRING
    },
    routeStart: {
        type: Sequelize.STRING
    },
    routeEnd: {
        type: Sequelize.STRING
    },
    stationLocation: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
},{
    freezeTableName: true
})

module.exports = BusRoutes;