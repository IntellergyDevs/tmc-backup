const Sequelize = require('sequelize');
const db = require('../db/db.sequelize');

const Device = db.define('device', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    DeviceName: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
    isActive: {
        type: Sequelize.INTEGER,
    },
    application: {
        type: Sequelize.STRING,
    }
}, {
    freezeTableName: true
})

module.exports = Device;