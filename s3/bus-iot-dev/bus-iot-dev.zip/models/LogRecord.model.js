const Sequelize = require('sequelize');
const db = require('../db/db.sequelize');

const LogRecord = db.define('logrecorddataset', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    DateTime: {
        type: Sequelize.STRING
    },
    DeviceName: {
        type: Sequelize.STRING
    },
    DeviceId: {
        type: Sequelize.STRING
    },
    Latitude: {
        type: Sequelize.STRING
    },
    Longitude: {
        type: Sequelize.STRING
    },
    Speed: {
        type: Sequelize.FLOAT
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
},{
    freezeTableName: true
})

module.exports = LogRecord;