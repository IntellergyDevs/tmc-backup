const Sequelize = require('sequelize');
const db = require('../db/db.sequelize');

const deviceStatusInfo = db.define('deviceStatusInfo', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    currentStateDuration: {
        type: Sequelize.STRING
    },
    isDeviceCommunicating: {
        type: Sequelize.INTEGER,
    },
    isDriving: {
        type: Sequelize.INTEGER,
    },
    latitude: {
        type: Sequelize.STRING
    },
    longitude: {
        type: Sequelize.STRING
    },
    deviceId: {
        type: Sequelize.STRING
    },
    status: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = deviceStatusInfo;