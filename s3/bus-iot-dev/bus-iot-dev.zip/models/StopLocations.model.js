const Sequelize = require('sequelize');
const db = require('../db/db.sequelize');

const StopLocations = db.define('stoplocations', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    routeAllocationName: {
        type: Sequelize.STRING
    },
    StopNumber: {
        type: Sequelize.STRING
    },
    PointX: {
        type: Sequelize.STRING
    },
    PointY: {
        type: Sequelize.STRING
    },
    colorScheme: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
});

module.exports = StopLocations;