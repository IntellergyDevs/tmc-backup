const Sequelize = require('sequelize');
const db = require('../db/db.sequelize');

const Notifications = db.define('notifications', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    notificationTitle: {
        type: Sequelize.STRING
    },
    notificationDesctiption: {
        type: Sequelize.TEXT
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
},{
    freezeTableName: true
})

module.exports = Notifications;