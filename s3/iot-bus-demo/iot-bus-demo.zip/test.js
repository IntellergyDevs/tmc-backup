var logrecords = require('./modules/geotab/logRecords');
logrecords.insertLogRecords();