//HighveldOld [{latitude:-25.872661911393777,longitude:28.193793296813965},{latitude:-25.87414853224553,longitude:28.195037841796875},{latitude:-25.876465306666052,longitude:28.192033767700195},{latitude:-25.87515247340658,longitude:28.19093942642212},{latitude:-25.872777752651697,longitude:28.193557262420654},{latitude:-25.872526763115964,longitude:28.193836212158203},]
module.exports = {
  "CENTURION": {
    "Highveld": [
      {
        latitude: -25.87469877028469,
        longitude: 28.187935352325436
      },
      {
        latitude: -25.875490336301507,
        longitude: 28.188364505767822
      },
      {
        latitude: -25.87500767472723,
        longitude: 28.190735578536984
      },
      {
        latitude: -25.875306925135593,
        longitude: 28.191647529602047
      },
      {
        latitude: -25.875760625921668,
        longitude: 28.1924307346344
      },
      {
        latitude: -25.873743092050365,
        longitude: 28.194769620895382
      },
      {
        latitude: -25.872999781411888,
        longitude: 28.19385766983032
      },
      {
        latitude: -25.874312638595594,
        longitude: 28.192334175109863
      },
      {
        latitude: -25.87386858559281,
        longitude: 28.189791440963745
      },
      {
        latitude: -25.874592584196023,
        longitude: 28.18792462348938
      },
    ],
    "Midstream": [{
      latitude: -25.87563513438922,
      longitude: 28.197097778320312
    },
    {
      latitude: -25.874496051305282,
      longitude: 28.198857307434082
    },
    {
      latitude: -25.880268579474592,
      longitude: 28.203749656677246
    },
    {
      latitude: -25.881060108164544,
      longitude: 28.202226161956787
    },
    {
      latitude: -25.875480683089354,
      longitude: 28.197269439697266
    },
    ]
  },
  "MARLBORO": {
    "Greenstone": [{
      latitude: -26.078871896916798,
      longitude: 28.121309280395508
    },
    {
      latitude: -26.084962025772057,
      longitude: 28.121352195739743
    },
    {
      latitude: -26.0850198419326,
      longitude: 28.12622308731079
    },
    {
      latitude: -26.08737100826203,
      longitude: 28.130557537078854
    },
    {
      latitude: -26.086156887285266,
      longitude: 28.131716251373287
    },
    {
      latitude: -26.083574429350676,
      longitude: 28.126673698425293
    },
    {
      latitude: -26.083150438273876,
      longitude: 28.123197555541992
    },
    {
      latitude: -26.078524981304103,
      longitude: 28.122940063476562
    },
    {
      latitude: -26.078756258493474,
      longitude: 28.12128782272339
    },
    ],
    "Linbro Business Park": [{
      latitude: -26.08105455073083,
      longitude: 28.11728596687317
    },
    {
      latitude: -26.08104973255531,
      longitude: 28.117924332618713
    },
    {
      latitude: -26.078491253342484,
      longitude: 28.118219375610348
    },
    {
      latitude: -26.07840934253808,
      longitude: 28.116964101791382
    },
    {
      latitude: -26.079030899562376,
      longitude: 28.116942644119263
    },
    {
      latitude: -26.079083900396245,
      longitude: 28.117489814758297
    },
    {
      latitude: -26.081078641605455,
      longitude: 28.11725378036499
    },
    ],
    "Kelvin": [{
      latitude: -26.076000175600793,
      longitude: 28.09952974319458
    },
    {
      latitude: -26.07649164968119,
      longitude: 28.09998035430908
    },
    {
      latitude: -26.07847679849881,
      longitude: 28.097212314605713
    },
    {
      latitude: -26.07784078361033,
      longitude: 28.096643686294556
    },
    {
      latitude: -26.075990538833494,
      longitude: 28.099433183670044
    },
    ],
    "Buccleuch": [{
      latitude: -26.072858547443136,
      longitude: 28.096836805343628
    },
    {
      latitude: -26.072434517554566,
      longitude: 28.09754490852356
    },
    {
      latitude: -26.07066128502055,
      longitude: 28.095860481262203
    },
    {
      latitude: -26.068502530912387,
      longitude: 28.091686964035034
    },
    {
      latitude: -26.069244607125377,
      longitude: 28.09106469154358
    },
    {
      latitude: -26.072926006602017,
      longitude: 28.09682607650757
    },
    ],
    "Woodlands office Park": [{
      latitude: -26.085617273918977,
      longitude: 28.10298442840576
    },
    {
      latitude: -26.084422406896397,
      longitude: 28.101825714111328
    },
    {
      latitude: -26.08937524390051,
      longitude: 28.09156894683838
    },
    {
      latitude: -26.090897669183096,
      longitude: 28.09255599975586
    },
    {
      latitude: -26.085694361695072,
      longitude: 28.10302734375
    },
    ]
  },
  "HATFIELD": {
    "Queenswood": [
      {
        latitude: -25.741176593353106,
        longitude: 28.241021633148193
      },
      {
        latitude: -25.741795098075052,
        longitude: 28.24128985404968
      },
      {
        latitude: -25.743225377914403,
        longitude: 28.240066766738888
      },
      {
        latitude: -25.745312782456708,
        longitude: 28.24009895324707
      },
      {
        latitude: -25.745351437750532,
        longitude: 28.239187002182007
      },
      {
        latitude: -25.742432927697816,
        longitude: 28.238983154296875
      },
      {
        latitude: -25.741205585833857,
        longitude: 28.240710496902466
      },
    ]
  }
}