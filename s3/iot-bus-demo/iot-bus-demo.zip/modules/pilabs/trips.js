const AWS = require('aws-sdk');
AWS.config.setPromisesDependency(require('bluebird'));
const dynamoDb = new AWS.DynamoDB.DocumentClient();



module.exports.getAll = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        var params = {
            TableName: 'pilabs-trips-database',
            // ProjectionExpression: "id, fullname, email"
        };
        console.log("Scanning pilabs trips table.");
        const onScan = (err, data) => {
            if (err) {
                console.log('Scan failed to load data. Error JSON:', JSON.stringify(err, null, 2));
                callback(err);
            } else {
                console.log("Scan succeeded.");
                response = {
                    statusCode: 200,
                    body: JSON.stringify({
                        result: data.Items
                    })
                }
            }
        };

        dynamoDb.scan(params, onScan);
        callback(null, response)
    } catch (error) {
        response = {
            statusCode: 500,
            body: JSON.stringify({
              message: 'pilabs trip data not fetch sucessfully',
              error:error,
              result:data,
            }),
          };
          callback(null,response)
    }
}