const AWS = require("aws-sdk");

AWS.config.update({
  region: "af-south-1", // replace with your region in AWS account
});

const dynamoDBClient = new AWS.DynamoDB.DocumentClient()

async function createTable() {
    const params = {
        TableName: "stopLandmarks",
        AttributeDefinitions: [
        { 'AttributeName' : 'id', 'AttributeType' : 'S' },
        // { 'AttributeName': 'name', 'AttributeType':'S' },
        // { 'AttributeName': 'Latitude', 'AttributeType':'S' },
        // { 'AttributeName': 'Longitude', 'AttributeType':'S' },
        // { 'AttributeName': 'createdAt', 'AttributeType':'S' },
        // { 'AttributeName': 'updatedAt', 'AttributeType':'S' }
      ],
      KeySchema: [{ AttributeName: "id", KeyType: "HASH" }],
        ProvisionedThroughput: {
          ReadCapacityUnits: 10,
          WriteCapacityUnits: 10,
        },
      };
  let result;
    DynamoDB.createTable(params, function(err, data) {
      if (err) {
        console.error("Unable to create table======>", err);
        result = JSON.stringify(err,null,2)
        return result;
      } else {
        console.log("Created table", data);
        return data;
      }
    });
  }

  const getAllData = async () => {
    console.log('hi scanning stoplocations table');
    let params = {
        TableName: 'stoplocations'
    }

    try {
        const stoplocations = await dynamoDBClient.scan(params).promise();
    console.log('devices======>',stoplocations)
    let records = [];
    // for(let device of devices.Items){
    //     let record = {
    //         status:device.status ? device.status :'',
    //         statusDuration:device.statusDuration ? device.statusDuration : '',
    //         latitude:device.latitude ? device.latitude : '',
    //         longitude:device.longitude ? device.longitude : '',
    //         id : device.imei,
    //         DeviceName:device.deviceName,
    //     }
    //     records.push(record);
    // }
    return stoplocations;
    } catch (error) {
        console.log("error while scanning device",error)
    }
}
  
  module.exports = {
    createTable,
    getAllData
  };