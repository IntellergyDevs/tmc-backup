const AWS = require("aws-sdk");
const { uuid } = require('uuidv4');
AWS.config.update({
    region: "af-south-1", // replace with your region in AWS account
});

const dynamoDBClient = new AWS.DynamoDB.DocumentClient()

async function insertDeviceItem(deviceData) {
    let id = uuid()
    var params = {
        TableName: "devices",
        Item: {
            "id": id,
            "imei": deviceData.imei,
            "deviceName": deviceData.deviceName,
            "device": deviceData.device,
            "serialNumber": deviceData.serialNumber,
            "installationDate": deviceData.installationDate,
            "isActive": deviceData.isActive,
        },
    };

    let response;
    dynamoDBClient.put(params, function (err, data) {
        if (err) {
            console.error("Unable to add device", imei, ". Error JSON:", JSON.stringify(err, null, 2));
            response = {
                statusCode: 400,
                body: JSON.stringify({
                    message: 'Pi-labs device Not added successfully!',
                    input: err,
                }),
            }

        } else {
            console.log("PutdeviceItem succeeded:", data);
            response = {
                statusCode: 200,
                body: JSON.stringify({
                    message: 'Pi-labs device added successfully!',
                    input: data,
                }),
            }
        }
    });
    return response;
}
const getAllData = async () => {
    console.log('hi scanning device table');
    let params = {
        TableName: 'devices'
    }
    // console.log("Scanning devices table.");
    // let records = [];
    // let devices;
    // const onScan = async (err, data) => {
    //     if (err) {
    //         console.log('Scan failed to load data. Error JSON:', JSON.stringify(err, null, 2));
    //         return err;
    //     } else {
    //         console.log("Scan succeeded.", data.Items);
    //         devices = data.Items
    //         for (let device of devices) {
    //             console.log("device========>",device);
    //             let record = {
    //                 status: device.status ? device.status : '',
    //                 statusDuration: device.statusDuration ? device.statusDuration : '',
    //                 latitude: device.latitude ? device.latitude : '',
    //                 longitude: device.longitude ? device.longitude : '',
    //                 id: device.imei,
    //                 DeviceName: device.deviceName,
    //             }
    //             records.push(record);
    //         }
            
    //     }
    // };

    // let data = await dynamoDBClient.scan(params, onScan);
    // console.log("data==========>",data);
    // return records;
    try {
        const devices = await dynamoDBClient.scan(params).promise();
    console.log('devices======>',devices)
    let records = [];
    for(let device of devices.Items){
        let record = {
            // status:device.status ? device.status :'',
            "status": "idle",
            // statusDuration:device.statusDuration ? device.statusDuration : '',
            // latitude:device.latitude ? device.latitude : '',
            // longitude:device.longitude ? device.longitude : '',
            "statusDuration": "00:00:27",
            "latitude": -25.7544193,
            "longitude": 28.1614857,
            id : device.imei,
            DeviceName:device.deviceName,
        }
        records.push(record);
    }
    return records;
    } catch (error) {
        console.log("error while scanning device",error)
    }
}

const insertSNSRawData = async (parsedMessage)=>{
    let id = uuid()
        let params = {
          TableName : 'deviceStatusInfo',
          Item:{
            id:id,
            imei : parsedMessage.imei,
            acceleration: parsedMessage.acceleration ? parsedMessage.acceleration:[],
            fullPosition:parsedMessage.fullPosition ? parsedMessage.fullPosition:[],
            syncedTime: parsedMessage.syncedTime ? parsedMessage.syncedTime :0,
            timestamp: parsedMessage.timestamp? parsedMessage.timestamp :0,
            syncSource: parsedMessage.syncSource? parsedMessage.syncSource :0,
            transmissionReason: parsedMessage.transmissionReason? parsedMessage.transmissionReason :" ",
            msgCount: parsedMessage.msgCount? parsedMessage.msgCount :0,
            snsMessage : parsedMessage
          },
          
        }
        console.log("sns data stored on dynamodb========>",parsedMessage)
        try {
          const data = await dynamoDBClient.put(params).promise()
          console.log("Success")
          return data
      } catch (err) {
          console.log("Failure==========>", err.message)
          // there is no data here, you can return undefined or similar
      }
}

module.exports = {
    insertDeviceItem,
    getAllData,
    insertSNSRawData


}