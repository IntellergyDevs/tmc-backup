const AWS = require("aws-sdk");
const { uuid } = require('uuidv4');
const moment = require('moment');
const momenttimezone = require('moment-timezone');
AWS.config.update({
    region: "af-south-1", // replace with your region in AWS account
});

const dynamoDBClient = new AWS.DynamoDB.DocumentClient()

const getBusExceptionData = async (searchParam) => {
    console.log('hi scanning exceptionEvent table of pilabs');
    var config = require('../../../config/config.json');
    moment.tz.setDefault(config.timeZone.africaCairo);
    let params = {
        TableName: 'exceptionEventPilabsDataset',
        FilterExpression: 'DeviceId =:this_deviceId AND ActiveFrom =:this_ActiveFrom AND ActiveTo =:this_ActiveTo ',
        ExpressionAttributeValues : {
            ':this_deviceId' : searchParam.busId, 
            ':this_ActiveFrom':searchParam.fromDate, 
            ':this_ActiveTo':searchParam.toDate}
    }
    try {
        const exceptionEvents = await dynamoDBClient.scan(params).promise();
        console.log('exceptionEvent======>', exceptionEvents)
        let records = [];
        for (let exceptionEvent of exceptionEvents.Items) {
            console.log('exceptionEvent======>', exceptionEvent);
            let record = {
                activeFrom: moment(exceptionEvent['ActiveFrom']).tz(config.timeZone.africaCairo).format(config.dateFormat.powerBi),
                activeTo: moment(exceptionEvent['ActiveTo']).tz(config.timeZone.africaCairo).format(config.dateFormat.powerBi),
                distance: exceptionEvent.Distance ? exceptionEvent.Distance : '',
                duration: exceptionEvent.Duration ? exceptionEvent.Duration : '',
                rule: {
                    id: exceptionEvent.RuleId ? exceptionEvent.RuleId : '',
                    name: exceptionEvent.RuleName ? exceptionEvent.RuleName : '',
                },
                device: {
                    id: exceptionEvent.DeviceId ? exceptionEvent.DeviceId : '',
                },
                diagnostic: exceptionEvent.diagnostic ? exceptionEvent.diagnostic : '',
                driver: exceptionEvent.driver ? exceptionEvent.driver : '',
                version:exceptionEvent.version ? exceptionEvent.version : '',
                id: exceptionEvent._id ? exceptionEvent._id : ''
            }

            records.push(record);
        }
        return records;
    } catch (error) {
        console.log("error while scanning exceptionEvent", error)
    }
}

const getCountByDeviceId = async ()=>{
    try {
        const params = {
            TableName: 'exceptionEventPilabsDataset',
            Select: "COUNT",
          };
          const count = await dynamoDBClient.scan(params).promise();
          console.log("Count=======>",count);
          return count;
    } catch (error) {
        console.log("error=======>",error);
    }
}

module.exports = {
    getBusExceptionData,
    getCountByDeviceId
}