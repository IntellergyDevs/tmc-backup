// Load the AWS SDK for Node.js
var AWS = require('aws-sdk');
const dynamoDBClient = new AWS.DynamoDB.DocumentClient()
const { uuid } = require('uuidv4');
const deviceModel = require('../models/device.model') 
// // Set region
// AWS.config.update({region: 'af-south-1'});

// const params = {
//   TopicArn : 'arn:aws:sns:af-south-1:473913856290:pilabs-at-473913856290'
// }

// // Create promise and SNS service object
// var subslistPromise = new AWS.SNS({apiVersion: '2010-03-31'}).listSubscriptionsByTopic(params).promise();

// // Handle promise's fulfilled/rejected states
//   subslistPromise.then(
//     function(data) {
//       console.log(data);
//     }).catch(
//     function(err) {
//       console.error(err, err.stack);
//     }
//   );

module.exports.snsLambda = async(event,context,callback)=>{
    try {
        let message = event.Records[0].Sns.Message;
        let parsedMessage = JSON.parse(message)
        let result = await deviceModel.insertSNSRawData(parsedMessage)
        console.log("sns data stored on dynamodb========>",result)
        let id = uuid()
        // let params = {
        //   TableName : 'deviceStatusInfo',
        //   Item:{
        //     id:id,
        //     imei : parsedMessage.imei,
        //     acceleration: parsedMessage.acceleration ? parsedMessage.acceleration:[],
        //     fullPosition:parsedMessage.fullPosition ? parsedMessage.fullPosition:[],
        //     syncedTime: parsedMessage.syncedTime ? parsedMessage.syncedTime :0,
        //     timestamp: parsedMessage.timestamp? parsedMessage.timestamp :0,
        //     syncSource: parsedMessage.syncSource? parsedMessage.syncSource :0,
        //     transmissionReason: parsedMessage.transmissionReason? parsedMessage.transmissionReason :" ",
        //     msgCount: parsedMessage.msgCount? parsedMessage.msgCount :0,
        //     snsMessage : event.Records[0].Sns.Message
        //   },
          
        // }
        // console.log("sns data stored on dynamodb========>",event.Records[0].Sns.Message)
      //   try {
      //     const data = await dynamoDBClient.put(params).promise()
      //     console.log("Success")
      //     console.log("sns data stored on dynamodb========>",params)
      //     return data
      // } catch (err) {
      //     console.log("Failure==========>", err.message)
      //     // there is no data here, you can return undefined or similar
      // }
    
      console.log("Received MESSAGE: " + params);
    
    //   return message;
        callback(null,'message')
    } catch (error) {
      console.log("Received MESSAGE: " + error);
        callback(null,error)
    }
}