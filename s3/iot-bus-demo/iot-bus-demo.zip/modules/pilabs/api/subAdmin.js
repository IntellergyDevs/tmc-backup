const jwt_decode = require('jwt-decode');
const utils = require('../../api/common/utils')
module.exports.getBusesStationEtaData = async (event, context, callback) => {
    let response; 
    try {
        context.callbackWaitsForEmptyEventLoop = false;
        let auth = await utils.checkAuth(event.headers, callback)

        let user = jwt_decode(event.headers.Authorization.split(' ')[1]);

        // let parsedRoutes = user.associatedRoutes
        // if (!user.associatedRoutes) {
        //     throw new Error('You are not authorized to access that location')
        // }
        // let routesStopsUser = parsedRoutes.map(id => "'" + id + "'").join()
        response = {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Bus data fetched successfully",
                status: 1,
                results: {
                    "busesInPolygon": {
                        "b5": {
                            "stops": [
                                {
                                    "StopNumber": "QWHS1 - 1",
                                    "latitude": "-25.7412500003417",
                                    "longitude": "28.2419999999466",
                                    "distance": {
                                        "km": "11.87",
                                        "m": "11871.00"
                                    },
                                    "eta": {
                                        "text": "35m, 36s",
                                        "seconds": "2136.78"
                                    }
                                },
                                {
                                    "StopNumber": "QWHS1 - 2",
                                    "latitude": "-25.7321749102724",
                                    "longitude": "28.2459049379219",
                                    "distance": {
                                        "km": "10.64",
                                        "m": "10639.00"
                                    },
                                    "eta": {
                                        "text": "31m, 55s",
                                        "seconds": "1915.02"
                                    }
                                },
                                {
                                    "StopNumber": "QWHS1 - 3",
                                    "latitude": "-25.7290865800946",
                                    "longitude": "28.2456983472248",
                                    "distance": {
                                        "km": "10.29",
                                        "m": "10295.00"
                                    },
                                    "eta": {
                                        "text": "30m, 53s",
                                        "seconds": "1853.10"
                                    }
                                }
                            ],
                            "isDeviated": true,
                            "route": {
                                "name": "Queenswood",
                                "color": "#ec4bd7"
                            },
                            "location": {
                                "latitude": "-25.7480965",
                                "longitude": "28.2360058"
                            }
                        }
                    }
                }
            })
        }
        callback (null,response)
    } catch (error) {
        console.log(error)
        callback(null, {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Internal server error occured",
                err: error.message,
                status: 0,
                results: [],
            })
        })
    }
}

module.exports.userGetStaticDetails = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        // const req = JSON.parse(event.body);
        let auth = await utils.checkAuth(event.headers, callback)
        let user = jwt_decode(event.headers.Authorization.split(' ')[1]);

        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Data fetched successfully",
                status: 1,
                results: {
                    "routes": [
                        {
                            "id": "Queenswood",
                            "name": "Queenswood",
                            "routeStops": [
                                {
                                    "message": "Hatfield Start",
                                    "id": 97,
                                    "longitude": 28.237902,
                                    "latitude": -25.747543
                                },
                                {
                                    "message": "QWHS1 - 1",
                                    "id": 98,
                                    "longitude": 28.2419999999466,
                                    "latitude": -25.7412500003417
                                },
                                {
                                    "message": "QWHS1 - 2",
                                    "id": 99,
                                    "longitude": 28.2459049379219,
                                    "latitude": -25.7321749102724
                                },
                                {
                                    "message": "QWHS1 - 3",
                                    "id": 100,
                                    "longitude": 28.2456983472248,
                                    "latitude": -25.7290865800946
                                },
                                {
                                    "message": "QWHS1 - 4",
                                    "id": 101,
                                    "longitude": 28.2448585787471,
                                    "latitude": -25.7266203795756
                                },
                                {
                                    "message": "QWHS1 - 5",
                                    "id": 102,
                                    "longitude": 28.2420469814407,
                                    "latitude": -25.7224880190059
                                },
                                {
                                    "message": "QWHS1 - 6",
                                    "id": 103,
                                    "longitude": 28.2421181971114,
                                    "latitude": -25.7177716766727
                                },
                                {
                                    "message": "QWHS1 - 7",
                                    "id": 104,
                                    "longitude": 28.2423311917008,
                                    "latitude": -25.7145908729138
                                },
                                {
                                    "message": "QWHS1 - 8",
                                    "id": 105,
                                    "longitude": 28.2423545835959,
                                    "latitude": -25.7108974802124
                                },
                                {
                                    "message": "QWHS1 - 9",
                                    "id": 106,
                                    "longitude": 28.2426444403836,
                                    "latitude": -25.7063559660959
                                },
                                {
                                    "message": "QWHS1 - 10",
                                    "id": 107,
                                    "longitude": 28.242782648216,
                                    "latitude": -25.7014398792635
                                },
                                {
                                    "message": "QWHS1 - 11",
                                    "id": 108,
                                    "longitude": 28.2397709049372,
                                    "latitude": -25.7011012134952
                                },
                                {
                                    "message": "QWHS1 - 12",
                                    "id": 109,
                                    "longitude": 28.2405899998936,
                                    "latitude": -25.704489999897
                                },
                                {
                                    "message": "QWHS1 - 13",
                                    "id": 110,
                                    "longitude": 28.2430981169605,
                                    "latitude": -25.7064581469069
                                },
                                {
                                    "message": "QWHS1 - 14",
                                    "id": 111,
                                    "longitude": 28.2427815600024,
                                    "latitude": -25.7108996987269
                                },
                                {
                                    "message": "QWHS1 - 15",
                                    "id": 112,
                                    "longitude": 28.242854914216,
                                    "latitude": -25.7145436819511
                                },
                                {
                                    "message": "QWHS1 - 16",
                                    "id": 113,
                                    "longitude": 28.2425343476864,
                                    "latitude": -25.7173121510407
                                },
                                {
                                    "message": "QWHS1 - 17",
                                    "id": 114,
                                    "longitude": 28.2425157187085,
                                    "latitude": -25.7224280658462
                                },
                                {
                                    "message": "QWHS1 - 18",
                                    "id": 115,
                                    "longitude": 28.2455315974981,
                                    "latitude": -25.7269358176583
                                },
                                {
                                    "message": "QWHS1 - 19",
                                    "id": 116,
                                    "longitude": 28.2460303165546,
                                    "latitude": -25.7289642130374
                                },
                                {
                                    "message": "QWHS1 - 20",
                                    "id": 117,
                                    "longitude": 28.2461282242366,
                                    "latitude": -25.7321912389084
                                },
                                {
                                    "message": "QWHS1 - 21",
                                    "id": 118,
                                    "longitude": 28.2432777780092,
                                    "latitude": -25.7413055558886
                                },
                                {
                                    "message": "Hatfield End",
                                    "id": 119,
                                    "longitude": 28.237902,
                                    "latitude": -25.747543
                                }
                            ],
                            "routeCoordinates": [
                                {
                                    "id": 896,
                                    "latitude": -25.748801458271,
                                    "longitude": 28.2398530395215
                                },
                                {
                                    "id": 897,
                                    "latitude": -25.7488631501782,
                                    "longitude": 28.2389536315404
                                },
                                {
                                    "id": 898,
                                    "latitude": -25.7489464667561,
                                    "longitude": 28.2377447345037
                                },
                                {
                                    "id": 899,
                                    "latitude": -25.7489688911197,
                                    "longitude": 28.2374777170255
                                },
                                {
                                    "id": 900,
                                    "latitude": -25.7482550690079,
                                    "longitude": 28.2374249086584
                                },
                                {
                                    "id": 901,
                                    "latitude": -25.7478482994087,
                                    "longitude": 28.2373877960686
                                },
                                {
                                    "id": 902,
                                    "latitude": -25.7474934502241,
                                    "longitude": 28.2373654132094
                                },
                                {
                                    "id": 903,
                                    "latitude": -25.7475506686193,
                                    "longitude": 28.2361486290725
                                },
                                {
                                    "id": 904,
                                    "latitude": -25.7475872361654,
                                    "longitude": 28.2354652247306
                                },
                                {
                                    "id": 905,
                                    "latitude": -25.7475689523938,
                                    "longitude": 28.2349237208729
                                },
                                {
                                    "id": 906,
                                    "latitude": -25.748149128876,
                                    "longitude": 28.2349720975228
                                },
                                {
                                    "id": 907,
                                    "latitude": -25.7487805262397,
                                    "longitude": 28.2350248908878
                                },
                                {
                                    "id": 908,
                                    "latitude": -25.7491087280767,
                                    "longitude": 28.2350241522726
                                },
                                {
                                    "id": 909,
                                    "latitude": -25.7490276788321,
                                    "longitude": 28.2364881980158
                                },
                                {
                                    "id": 910,
                                    "latitude": -25.748984703691,
                                    "longitude": 28.2371834591434
                                },
                                {
                                    "id": 911,
                                    "latitude": -25.7489688911197,
                                    "longitude": 28.2374777170255
                                },
                                {
                                    "id": 912,
                                    "latitude": -25.7496416833076,
                                    "longitude": 28.2375431598561
                                },
                                {
                                    "id": 913,
                                    "latitude": -25.7501664043505,
                                    "longitude": 28.2375886519556
                                },
                                {
                                    "id": 914,
                                    "latitude": -25.7503878500378,
                                    "longitude": 28.2376118796239
                                },
                                {
                                    "id": 915,
                                    "latitude": -25.7503606253898,
                                    "longitude": 28.2379507950719
                                },
                                {
                                    "id": 916,
                                    "latitude": -25.7503017298947,
                                    "longitude": 28.2386828316879
                                },
                                {
                                    "id": 917,
                                    "latitude": -25.7502505210991,
                                    "longitude": 28.2393293923657
                                },
                                {
                                    "id": 918,
                                    "latitude": -25.7502218283328,
                                    "longitude": 28.2397895792491
                                },
                                {
                                    "id": 919,
                                    "latitude": -25.7502121649069,
                                    "longitude": 28.2399759927697
                                },
                                {
                                    "id": 920,
                                    "latitude": -25.7492677173661,
                                    "longitude": 28.2398933091205
                                },
                                {
                                    "id": 921,
                                    "latitude": -25.748801458271,
                                    "longitude": 28.2398530395215
                                },
                                {
                                    "id": 922,
                                    "latitude": -25.7477290314871,
                                    "longitude": 28.2398378786685
                                },
                                {
                                    "id": 923,
                                    "latitude": -25.7466441907961,
                                    "longitude": 28.239756682113
                                },
                                {
                                    "id": 924,
                                    "latitude": -25.7444019611954,
                                    "longitude": 28.2395617455858
                                },
                                {
                                    "id": 925,
                                    "latitude": -25.7436583989452,
                                    "longitude": 28.2394670162711
                                },
                                {
                                    "id": 926,
                                    "latitude": -25.7428043840832,
                                    "longitude": 28.2394281535411
                                },
                                {
                                    "id": 927,
                                    "latitude": -25.7426193428095,
                                    "longitude": 28.2395472053085
                                },
                                {
                                    "id": 928,
                                    "latitude": -25.7425371984079,
                                    "longitude": 28.2396477881434
                                },
                                {
                                    "id": 929,
                                    "latitude": -25.7420783296428,
                                    "longitude": 28.2402065614108
                                },
                                {
                                    "id": 930,
                                    "latitude": -25.7413247367228,
                                    "longitude": 28.2412742567469
                                },
                                {
                                    "id": 931,
                                    "latitude": -25.7413035798968,
                                    "longitude": 28.2422913232034
                                },
                                {
                                    "id": 932,
                                    "latitude": -25.7412563310058,
                                    "longitude": 28.2428808046303
                                },
                                {
                                    "id": 933,
                                    "latitude": -25.7409670688317,
                                    "longitude": 28.2434074571164
                                },
                                {
                                    "id": 934,
                                    "latitude": -25.7407625265766,
                                    "longitude": 28.2436843193986
                                },
                                {
                                    "id": 935,
                                    "latitude": -25.7401077989404,
                                    "longitude": 28.2443081044174
                                },
                                {
                                    "id": 936,
                                    "latitude": -25.7396784046962,
                                    "longitude": 28.2447044330658
                                },
                                {
                                    "id": 937,
                                    "latitude": -25.7393280739181,
                                    "longitude": 28.2449592429142
                                },
                                {
                                    "id": 938,
                                    "latitude": -25.7390227330279,
                                    "longitude": 28.2451626923094
                                },
                                {
                                    "id": 939,
                                    "latitude": -25.7389780833556,
                                    "longitude": 28.2452182042903
                                },
                                {
                                    "id": 940,
                                    "latitude": -25.7389400300106,
                                    "longitude": 28.2452658134989
                                },
                                {
                                    "id": 941,
                                    "latitude": -25.7386875487713,
                                    "longitude": 28.2454019356113
                                },
                                {
                                    "id": 942,
                                    "latitude": -25.7378235127524,
                                    "longitude": 28.2458704179769
                                },
                                {
                                    "id": 943,
                                    "latitude": -25.7373154926254,
                                    "longitude": 28.2461389093718
                                },
                                {
                                    "id": 944,
                                    "latitude": -25.7369748153977,
                                    "longitude": 28.2462660698653
                                },
                                {
                                    "id": 945,
                                    "latitude": -25.7362418978736,
                                    "longitude": 28.2463926506026
                                },
                                {
                                    "id": 946,
                                    "latitude": -25.7354842130761,
                                    "longitude": 28.2465180575263
                                },
                                {
                                    "id": 947,
                                    "latitude": -25.7353456674427,
                                    "longitude": 28.246491049347
                                },
                                {
                                    "id": 948,
                                    "latitude": -25.7347214394234,
                                    "longitude": 28.2465531674287
                                },
                                {
                                    "id": 949,
                                    "latitude": -25.7342968103801,
                                    "longitude": 28.2465468372014
                                },
                                {
                                    "id": 950,
                                    "latitude": -25.7338923408448,
                                    "longitude": 28.2465116979081
                                },
                                {
                                    "id": 951,
                                    "latitude": -25.7332979439902,
                                    "longitude": 28.2463262405229
                                },
                                {
                                    "id": 952,
                                    "latitude": -25.7325822885566,
                                    "longitude": 28.2460481305448
                                },
                                {
                                    "id": 953,
                                    "latitude": -25.7320150219414,
                                    "longitude": 28.2459515024163
                                },
                                {
                                    "id": 954,
                                    "latitude": -25.7309277560131,
                                    "longitude": 28.2458865403045
                                },
                                {
                                    "id": 955,
                                    "latitude": -25.7298359902094,
                                    "longitude": 28.2458505047515
                                },
                                {
                                    "id": 956,
                                    "latitude": -25.7295710284324,
                                    "longitude": 28.2458574220953
                                },
                                {
                                    "id": 957,
                                    "latitude": -25.7294743773425,
                                    "longitude": 28.2458708331402
                                },
                                {
                                    "id": 958,
                                    "latitude": -25.7283984276677,
                                    "longitude": 28.2458154982118
                                },
                                {
                                    "id": 959,
                                    "latitude": -25.7277826304424,
                                    "longitude": 28.2457417007048
                                },
                                {
                                    "id": 960,
                                    "latitude": -25.7267711554948,
                                    "longitude": 28.2452728145163
                                },
                                {
                                    "id": 961,
                                    "latitude": -25.7255174357675,
                                    "longitude": 28.2440636624148
                                },
                                {
                                    "id": 962,
                                    "latitude": -25.7242660765656,
                                    "longitude": 28.242772349206
                                },
                                {
                                    "id": 963,
                                    "latitude": -25.7238579622019,
                                    "longitude": 28.2424490482533
                                },
                                {
                                    "id": 964,
                                    "latitude": -25.7234991456973,
                                    "longitude": 28.2423409415869
                                },
                                {
                                    "id": 965,
                                    "latitude": -25.7219470816251,
                                    "longitude": 28.242308614238
                                },
                                {
                                    "id": 966,
                                    "latitude": -25.7209397838086,
                                    "longitude": 28.2423235455432
                                },
                                {
                                    "id": 967,
                                    "latitude": -25.7192966169035,
                                    "longitude": 28.2423181252812
                                },
                                {
                                    "id": 968,
                                    "latitude": -25.7176936965856,
                                    "longitude": 28.2423250461247
                                },
                                {
                                    "id": 969,
                                    "latitude": -25.7168359080278,
                                    "longitude": 28.2423819443755
                                },
                                {
                                    "id": 970,
                                    "latitude": -25.7156705359712,
                                    "longitude": 28.2425260866024
                                },
                                {
                                    "id": 971,
                                    "latitude": -25.7151810997728,
                                    "longitude": 28.2425884980968
                                },
                                {
                                    "id": 972,
                                    "latitude": -25.7149424960214,
                                    "longitude": 28.2426177325572
                                },
                                {
                                    "id": 973,
                                    "latitude": -25.7147115956997,
                                    "longitude": 28.2426124965032
                                },
                                {
                                    "id": 974,
                                    "latitude": -25.7137473803882,
                                    "longitude": 28.2425990888288
                                },
                                {
                                    "id": 975,
                                    "latitude": -25.7126671562901,
                                    "longitude": 28.2425803133719
                                },
                                {
                                    "id": 976,
                                    "latitude": -25.7118257296647,
                                    "longitude": 28.2425704380348
                                },
                                {
                                    "id": 977,
                                    "latitude": -25.7107045768235,
                                    "longitude": 28.2425600142396
                                },
                                {
                                    "id": 978,
                                    "latitude": -25.7094019901972,
                                    "longitude": 28.2425412387781
                                },
                                {
                                    "id": 979,
                                    "latitude": -25.7081960952318,
                                    "longitude": 28.2425365412005
                                },
                                {
                                    "id": 980,
                                    "latitude": -25.7078377026853,
                                    "longitude": 28.2425681313897
                                },
                                {
                                    "id": 981,
                                    "latitude": -25.7072947322905,
                                    "longitude": 28.2427173138206
                                },
                                {
                                    "id": 982,
                                    "latitude": -25.7069099780107,
                                    "longitude": 28.2428114392235
                                },
                                {
                                    "id": 983,
                                    "latitude": -25.7068628516383,
                                    "longitude": 28.2428181447458
                                },
                                {
                                    "id": 984,
                                    "latitude": -25.7058143547523,
                                    "longitude": 28.2428230122132
                                },
                                {
                                    "id": 985,
                                    "latitude": -25.7050204429469,
                                    "longitude": 28.2428149079482
                                },
                                {
                                    "id": 986,
                                    "latitude": -25.7045368181773,
                                    "longitude": 28.2427902520426
                                },
                                {
                                    "id": 987,
                                    "latitude": -25.7045199362408,
                                    "longitude": 28.2427459792439
                                },
                                {
                                    "id": 988,
                                    "latitude": -25.7044752257081,
                                    "longitude": 28.2427178160501
                                },
                                {
                                    "id": 989,
                                    "latitude": -25.704429237384,
                                    "longitude": 28.2427315773472
                                },
                                {
                                    "id": 990,
                                    "latitude": -25.7044099030869,
                                    "longitude": 28.2427691282722
                                },
                                {
                                    "id": 991,
                                    "latitude": -25.7042497908186,
                                    "longitude": 28.2427872331825
                                },
                                {
                                    "id": 992,
                                    "latitude": -25.7040481162296,
                                    "longitude": 28.242807508266
                                },
                                {
                                    "id": 993,
                                    "latitude": -25.7031858922737,
                                    "longitude": 28.2427995340115
                                },
                                {
                                    "id": 994,
                                    "latitude": -25.7019221754349,
                                    "longitude": 28.2427855673324
                                },
                                {
                                    "id": 995,
                                    "latitude": -25.7010015626532,
                                    "longitude": 28.2427797849848
                                },
                                {
                                    "id": 996,
                                    "latitude": -25.7010050612353,
                                    "longitude": 28.2421563001775
                                },
                                {
                                    "id": 997,
                                    "latitude": -25.701008299865,
                                    "longitude": 28.2414870115591
                                },
                                {
                                    "id": 998,
                                    "latitude": -25.7010115302566,
                                    "longitude": 28.2405423570161
                                },
                                {
                                    "id": 999,
                                    "latitude": -25.701026428275,
                                    "longitude": 28.2390682825062
                                },
                                {
                                    "id": 1000,
                                    "latitude": -25.7019757575826,
                                    "longitude": 28.2390809329017
                                },
                                {
                                    "id": 1001,
                                    "latitude": -25.7026941468419,
                                    "longitude": 28.2390890510109
                                },
                                {
                                    "id": 1002,
                                    "latitude": -25.7037105020635,
                                    "longitude": 28.2391065370101
                                },
                                {
                                    "id": 1003,
                                    "latitude": -25.7045204805438,
                                    "longitude": 28.2391205874303
                                },
                                {
                                    "id": 1004,
                                    "latitude": -25.7045096377953,
                                    "longitude": 28.2399718791445
                                },
                                {
                                    "id": 1005,
                                    "latitude": -25.70449845582,
                                    "longitude": 28.2408822922179
                                },
                                {
                                    "id": 1006,
                                    "latitude": -25.7044864472303,
                                    "longitude": 28.2420949988937
                                },
                                {
                                    "id": 1007,
                                    "latitude": -25.7044844149638,
                                    "longitude": 28.2423988462271
                                },
                                {
                                    "id": 1008,
                                    "latitude": -25.7044608512994,
                                    "longitude": 28.2426047057667
                                },
                                {
                                    "id": 1009,
                                    "latitude": -25.7044493715639,
                                    "longitude": 28.2427173585418
                                },
                                {
                                    "id": 1010,
                                    "latitude": -25.704429237384,
                                    "longitude": 28.2427315773472
                                },
                                {
                                    "id": 1011,
                                    "latitude": -25.7044099030869,
                                    "longitude": 28.2427691282722
                                },
                                {
                                    "id": 1012,
                                    "latitude": -25.704425141323,
                                    "longitude": 28.2428346050277
                                },
                                {
                                    "id": 1013,
                                    "latitude": -25.7044752896432,
                                    "longitude": 28.2428547215946
                                },
                                {
                                    "id": 1014,
                                    "latitude": -25.704510697152,
                                    "longitude": 28.2428470233053
                                },
                                {
                                    "id": 1015,
                                    "latitude": -25.7045327088646,
                                    "longitude": 28.2428263647446
                                },
                                {
                                    "id": 1016,
                                    "latitude": -25.7045368181773,
                                    "longitude": 28.2427902520426
                                },
                                {
                                    "id": 1017,
                                    "latitude": -25.7050204429469,
                                    "longitude": 28.2428149079482
                                },
                                {
                                    "id": 1018,
                                    "latitude": -25.7058143547523,
                                    "longitude": 28.2428230122132
                                },
                                {
                                    "id": 1019,
                                    "latitude": -25.7068628516383,
                                    "longitude": 28.2428181447458
                                },
                                {
                                    "id": 1020,
                                    "latitude": -25.7069099780107,
                                    "longitude": 28.2428114392235
                                },
                                {
                                    "id": 1021,
                                    "latitude": -25.7072947322905,
                                    "longitude": 28.2427173138206
                                },
                                {
                                    "id": 1022,
                                    "latitude": -25.7078377026853,
                                    "longitude": 28.2425681313897
                                },
                                {
                                    "id": 1023,
                                    "latitude": -25.7081960952318,
                                    "longitude": 28.2425365412005
                                },
                                {
                                    "id": 1024,
                                    "latitude": -25.7094019901972,
                                    "longitude": 28.2425412387781
                                },
                                {
                                    "id": 1025,
                                    "latitude": -25.7107045768235,
                                    "longitude": 28.2425600142396
                                },
                                {
                                    "id": 1026,
                                    "latitude": -25.7118257296647,
                                    "longitude": 28.2425704380348
                                },
                                {
                                    "id": 1027,
                                    "latitude": -25.7126671562901,
                                    "longitude": 28.2425803133719
                                },
                                {
                                    "id": 1028,
                                    "latitude": -25.7137473803882,
                                    "longitude": 28.2425990888288
                                },
                                {
                                    "id": 1029,
                                    "latitude": -25.7147115956997,
                                    "longitude": 28.2426124965032
                                },
                                {
                                    "id": 1030,
                                    "latitude": -25.7149424960214,
                                    "longitude": 28.2426177325572
                                },
                                {
                                    "id": 1031,
                                    "latitude": -25.7151810997728,
                                    "longitude": 28.2425884980968
                                },
                                {
                                    "id": 1032,
                                    "latitude": -25.7156705359712,
                                    "longitude": 28.2425260866024
                                },
                                {
                                    "id": 1033,
                                    "latitude": -25.7168359080278,
                                    "longitude": 28.2423819443755
                                },
                                {
                                    "id": 1034,
                                    "latitude": -25.7176936965856,
                                    "longitude": 28.2423250461247
                                },
                                {
                                    "id": 1035,
                                    "latitude": -25.7192966169035,
                                    "longitude": 28.2423181252812
                                },
                                {
                                    "id": 1036,
                                    "latitude": -25.7209397838086,
                                    "longitude": 28.2423235455432
                                },
                                {
                                    "id": 1037,
                                    "latitude": -25.7219470816251,
                                    "longitude": 28.242308614238
                                },
                                {
                                    "id": 1038,
                                    "latitude": -25.7234991456973,
                                    "longitude": 28.2423409415869
                                },
                                {
                                    "id": 1039,
                                    "latitude": -25.7238579622019,
                                    "longitude": 28.2424490482533
                                },
                                {
                                    "id": 1040,
                                    "latitude": -25.7242660765656,
                                    "longitude": 28.242772349206
                                },
                                {
                                    "id": 1041,
                                    "latitude": -25.7255174357675,
                                    "longitude": 28.2440636624148
                                },
                                {
                                    "id": 1042,
                                    "latitude": -25.7267711554948,
                                    "longitude": 28.2452728145163
                                },
                                {
                                    "id": 1043,
                                    "latitude": -25.7277826304424,
                                    "longitude": 28.2457417007048
                                },
                                {
                                    "id": 1044,
                                    "latitude": -25.7283984276677,
                                    "longitude": 28.2458154982118
                                },
                                {
                                    "id": 1045,
                                    "latitude": -25.7294743773425,
                                    "longitude": 28.2458708331402
                                },
                                {
                                    "id": 1046,
                                    "latitude": -25.7295722097375,
                                    "longitude": 28.2458976182399
                                },
                                {
                                    "id": 1047,
                                    "latitude": -25.7296799641703,
                                    "longitude": 28.2459247307065
                                },
                                {
                                    "id": 1048,
                                    "latitude": -25.7299443901185,
                                    "longitude": 28.2459313276709
                                },
                                {
                                    "id": 1049,
                                    "latitude": -25.730310137294,
                                    "longitude": 28.2459658094113
                                },
                                {
                                    "id": 1050,
                                    "latitude": -25.7304920634731,
                                    "longitude": 28.245979161252
                                },
                                {
                                    "id": 1051,
                                    "latitude": -25.7312293294785,
                                    "longitude": 28.2459901440331
                                },
                                {
                                    "id": 1052,
                                    "latitude": -25.7319687337322,
                                    "longitude": 28.2460488970045
                                },
                                {
                                    "id": 1053,
                                    "latitude": -25.7328583506411,
                                    "longitude": 28.2462653506137
                                },
                                {
                                    "id": 1054,
                                    "latitude": -25.7334689926674,
                                    "longitude": 28.2465577672278
                                },
                                {
                                    "id": 1055,
                                    "latitude": -25.7335777214825,
                                    "longitude": 28.2466114114064
                                },
                                {
                                    "id": 1056,
                                    "latitude": -25.733881233552,
                                    "longitude": 28.2466245836676
                                },
                                {
                                    "id": 1057,
                                    "latitude": -25.7344060940673,
                                    "longitude": 28.24667295393
                                },
                                {
                                    "id": 1058,
                                    "latitude": -25.7348571429193,
                                    "longitude": 28.2466639320904
                                },
                                {
                                    "id": 1059,
                                    "latitude": -25.7353071471016,
                                    "longitude": 28.2465909031283
                                },
                                {
                                    "id": 1060,
                                    "latitude": -25.7354521165911,
                                    "longitude": 28.2465453055765
                                },
                                {
                                    "id": 1061,
                                    "latitude": -25.7354842130761,
                                    "longitude": 28.2465180575263
                                },
                                {
                                    "id": 1062,
                                    "latitude": -25.7362418978736,
                                    "longitude": 28.2463926506026
                                },
                                {
                                    "id": 1063,
                                    "latitude": -25.7369748153977,
                                    "longitude": 28.2462660698653
                                },
                                {
                                    "id": 1064,
                                    "latitude": -25.7373154926254,
                                    "longitude": 28.2461389093718
                                },
                                {
                                    "id": 1065,
                                    "latitude": -25.7378235127524,
                                    "longitude": 28.2458704179769
                                },
                                {
                                    "id": 1066,
                                    "latitude": -25.7386875487713,
                                    "longitude": 28.2454019356113
                                },
                                {
                                    "id": 1067,
                                    "latitude": -25.7389400300106,
                                    "longitude": 28.2452658134989
                                },
                                {
                                    "id": 1068,
                                    "latitude": -25.7390864268725,
                                    "longitude": 28.2452332336614
                                },
                                {
                                    "id": 1069,
                                    "latitude": -25.7392534233134,
                                    "longitude": 28.2451518654177
                                },
                                {
                                    "id": 1070,
                                    "latitude": -25.7395168830364,
                                    "longitude": 28.2449754829837
                                },
                                {
                                    "id": 1071,
                                    "latitude": -25.7398354833837,
                                    "longitude": 28.2446808492364
                                },
                                {
                                    "id": 1072,
                                    "latitude": -25.7406299218554,
                                    "longitude": 28.2439185104478
                                },
                                {
                                    "id": 1073,
                                    "latitude": -25.7410206744537,
                                    "longitude": 28.2435229874002
                                },
                                {
                                    "id": 1074,
                                    "latitude": -25.7413108648898,
                                    "longitude": 28.2432582421341
                                },
                                {
                                    "id": 1075,
                                    "latitude": -25.7419429604192,
                                    "longitude": 28.2425804304614
                                },
                                {
                                    "id": 1076,
                                    "latitude": -25.7421497291367,
                                    "longitude": 28.2423383396607
                                },
                                {
                                    "id": 1077,
                                    "latitude": -25.7424486007284,
                                    "longitude": 28.2420603386584
                                },
                                {
                                    "id": 1078,
                                    "latitude": -25.7425748374181,
                                    "longitude": 28.2419845662546
                                },
                                {
                                    "id": 1079,
                                    "latitude": -25.7426636258244,
                                    "longitude": 28.241968473
                                },
                                {
                                    "id": 1080,
                                    "latitude": -25.7430333244791,
                                    "longitude": 28.2419184885417
                                },
                                {
                                    "id": 1081,
                                    "latitude": -25.743699689999,
                                    "longitude": 28.2419726195786
                                },
                                {
                                    "id": 1082,
                                    "latitude": -25.7445123258278,
                                    "longitude": 28.2420312615365
                                },
                                {
                                    "id": 1083,
                                    "latitude": -25.7447561154901,
                                    "longitude": 28.2419996850983
                                },
                                {
                                    "id": 1084,
                                    "latitude": -25.7451167783187,
                                    "longitude": 28.2418526591445
                                },
                                {
                                    "id": 1085,
                                    "latitude": -25.745520672077,
                                    "longitude": 28.2415368786136
                                },
                                {
                                    "id": 1086,
                                    "latitude": -25.7463270253461,
                                    "longitude": 28.2408229207289
                                },
                                {
                                    "id": 1087,
                                    "latitude": -25.7469344679743,
                                    "longitude": 28.2403403851049
                                },
                                {
                                    "id": 1088,
                                    "latitude": -25.7472418821181,
                                    "longitude": 28.2401298647766
                                },
                                {
                                    "id": 1089,
                                    "latitude": -25.7474909357693,
                                    "longitude": 28.2400395605179
                                },
                                {
                                    "id": 1090,
                                    "latitude": -25.7478115547413,
                                    "longitude": 28.2399795966384
                                },
                                {
                                    "id": 1091,
                                    "latitude": -25.7484697674026,
                                    "longitude": 28.2399931293976
                                },
                                {
                                    "id": 1092,
                                    "latitude": -25.7492317814942,
                                    "longitude": 28.2400236816741
                                },
                                {
                                    "id": 1093,
                                    "latitude": -25.7497415303583,
                                    "longitude": 28.240050503765
                                },
                                {
                                    "id": 1094,
                                    "latitude": -25.7502054754705,
                                    "longitude": 28.240100121587
                                },
                                {
                                    "id": 1095,
                                    "latitude": -25.7502121649069,
                                    "longitude": 28.2399759927697
                                }
                            ],
                            "colorScheme": "#ec4bd7"
                        }
                    ],
                    "landmarks": {
                        "landmarkStops": [
                            {
                                "name": "HATFIELD",
                                "latitude": -25.747543,
                                "longitude": 28.237902,
                                "associatedRoutes": [
                                    "Queenswood"
                                ],
                                "centerPoint": {
                                    "latitude": -25.7224880190059,
                                    "longitude": 28.2420469814407
                                }
                            }
                        ],
                        "landmarkAreaCoordinates": [
                            {
                                "id": "HATFIELD",
                                "name": "HATFIELD",
                                "routeCoordinates": [
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7464963492684,
                                        "longitude": 28.2395395938037
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7467427740914,
                                        "longitude": 28.2347384398188
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7492311529856,
                                        "longitude": 28.2348725502643
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7491731719366,
                                        "longitude": 28.2373670045747
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7505318208964,
                                        "longitude": 28.237463853591
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7503766817101,
                                        "longitude": 28.2402963089338
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7478829350482,
                                        "longitude": 28.2401559620697
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7468368446359,
                                        "longitude": 28.240697527131
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7451148484918,
                                        "longitude": 28.2421010171668
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7445681778268,
                                        "longitude": 28.2422906779908
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7425776512962,
                                        "longitude": 28.2421938348918
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7406009155478,
                                        "longitude": 28.2443819704467
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7393634100104,
                                        "longitude": 28.2453592347706
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7367733206298,
                                        "longitude": 28.246582285462
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7342121954018,
                                        "longitude": 28.246968523569
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7325208560011,
                                        "longitude": 28.2465286413228
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7283939146077,
                                        "longitude": 28.2461209023879
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7268184763995,
                                        "longitude": 28.2457132066552
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7262965475009,
                                        "longitude": 28.2452947820611
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.724663088556,
                                        "longitude": 28.2436532701786
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7237931900264,
                                        "longitude": 28.2427305903032
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7231842572052,
                                        "longitude": 28.2425803865475
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.718080698217,
                                        "longitude": 28.2426233018908
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7149488603609,
                                        "longitude": 28.2429451669752
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7131992483699,
                                        "longitude": 28.2429773534906
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7079731969061,
                                        "longitude": 28.2428747390463
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7068676711333,
                                        "longitude": 28.2431814815969
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7039616205553,
                                        "longitude": 28.2431751404742
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7007907413608,
                                        "longitude": 28.2430893097915
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.700789907063,
                                        "longitude": 28.2389018092977
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7046761324978,
                                        "longitude": 28.238901798121
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7046913446357,
                                        "longitude": 28.2424624924567
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7062360185568,
                                        "longitude": 28.242577724359
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7078124682291,
                                        "longitude": 28.2421963650013
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7113311579949,
                                        "longitude": 28.2422929245021
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7144050930778,
                                        "longitude": 28.2423143821407
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.716000028084,
                                        "longitude": 28.2421641784307
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7176722703203,
                                        "longitude": 28.2419603305436
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7189481849839,
                                        "longitude": 28.2420032458875
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7241000332391,
                                        "longitude": 28.2420675711425
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7269513362157,
                                        "longitude": 28.2449107126755
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7283720769451,
                                        "longitude": 28.2454578687968
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7322187652954,
                                        "longitude": 28.2455758859873
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7334075407931,
                                        "longitude": 28.245908479897
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7342966984422,
                                        "longitude": 28.2461874296315
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7363842598341,
                                        "longitude": 28.2460372258806
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7385201302808,
                                        "longitude": 28.2450286875032
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7406559384965,
                                        "longitude": 28.243258429549
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7409845209649,
                                        "longitude": 28.2410161028763
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7414387364159,
                                        "longitude": 28.2400075922935
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.742356826193,
                                        "longitude": 28.239031268172
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7455894121184,
                                        "longitude": 28.2394282350713
                                    },
                                    {
                                        "Landmark": "HATFIELD",
                                        "name": "HATFIELD",
                                        "latitude": -25.7464963492684,
                                        "longitude": 28.2395395938037
                                    }
                                ],
                                "associatedRoutes": [
                                    "Queenswood"
                                ]
                            }
                        ],
                        "centerPoint": {
                            "latitude": -25.7224880190059,
                            "longitude": 28.2420469814407
                        }
                    }
                }
            }, null, 2)
        })

    } catch (err) {
        console.log(err)
        callback(null, {
            statusCode: 401,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: err.message,
                err: err.message,
                status: 0,
                results: [],
            })
        })
    }
}