'use strict';
const deviceModel = require('../models/device.model')
const moment = require('moment');
const momenttimezone = require('moment-timezone');
const utils = require('../../../modules/api/common/utils')
const aws = require('aws-sdk')
const exceptionEventModel = require('../models/exceptionEvent.model');
const stopsFullPathModel = require('../models/stopFullPath.model');
const stoplocationsReactModel = require('../models/stoplocations_react.model')

module.exports.getAllBuses = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    let response;
    try {
        let auth = await utils.checkAuth(event.headers, callback)
        var config = require('../../../config/config.json');
        moment.tz.setDefault(config.timeZone.africaCairo);
        let error = {};
        if (Object.keys(error).length == 0) {
            // let query = "SELECT * FROM device LEFT JOIN deviceStatusInfo ON device.id = deviceStatusInfo.deviceID WHERE isActive = 1";
            // var [records, meta] = await db.query(query, {});
            // records = records ? records : [];
            // console.log("bus data for pilabs=================>");
            let records = await deviceModel.getAllData();
            console.log("records==============>", records);
            response = {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Bus data fetched successfully",
                    status: 1,
                    results: {
                        buses: records
                    },
                })
            }
            callback(null, response)
        } else {
            response = {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "No bus data found",
                    //err: error,
                    status: 0,
                    results: [],
                })
            }
            callback(null, response)
        }
    } catch (error) {
        response = {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Internal server error",
                //err: error,
                status: 0,
                results: [],
            })
        }
        callback(null, response)
    }
}

module.exports.getBusExceptions = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    let response;
    try {
        let auth = await utils.checkAuth(event.headers, callback)
        var config = require('../../../config/config.json');
        moment.tz.setDefault(config.timeZone.africaCairo);
        let req = event.queryStringParameters;
        let busId = req && req.busId ? req.busId : null;
        let fromDate = req && req.fromDate ? req.fromDate : new Date().toISOString().split('T')[0];
        let toDate = req && req.toDate ? req.toDate : new Date().toISOString().split('T')[0];
        let searchParam = {
            busId: busId,
            fromDate: fromDate,
            toDate: toDate
        }
        let error = {};
        if (busId == null) {
            error['Invalid Param'] = "BusId is invalid parameter"
        }
        if (Object.keys(error).length == 0) {
            // scan data from exceptioneventdataset with filter
            let record = await exceptionEventModel.getBusExceptionData(searchParam);
            console.log('record=========>', record);
            response = {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Bus data fetched successfully",
                    status: 1,
                    results: {
                        exceptions: record
                    },
                })
            }
            callback(null, response)

        } else {
            callback(null, {
                statusCode: 400,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Insufficient Data provided",
                    err: error,
                    status: 0,
                    results: [],
                })
            })
        }
    } catch (error) {
        response = {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Internal server error",
                err: error,
                status: 0,
                results: [],
            })
        }
        callback(null, response)
    }
}

module.exports.getBusLocationTrace = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let auth = await utils.checkAuth(event.headers, callback)
        var config = require('../../config/config.json');
        moment.tz.setDefault(config.timeZone.africaCairo);
        let req = event.queryStringParameters;

        let busId = req && req.busId ? req.busId : null;
        let fromDate = req && req.fromDate ? req.fromDate : new Date().toISOString();
        let toDate = req && req.toDate ? req.toDate : new Date().toISOString();
        if (busId == null) {
            throw new Error("BusId is invalid parameter")
        }
        let queryAvgSpeed = `SELECT AVG(AverageSpeed) AS AverageSpeed FROM tripdataset WHERE DeviceId = '${busId}' AND StartDateTime >= '${fromDate}' AND StartDateTime <= '${toDate}'`;
    } catch (error) {

    }
};
module.exports.getAllStaticDetails = async (event, context, callback) => {
    let response;
    try {
        context.callbackWaitsForEmptyEventLoop = false;

        // let auth = await utils.checkAuth(event.headers, callback)
        let error = {};
        if (Object.keys(error).length == 0) {
            let fullPath = await stopsFullPathModel.getAllData();
            let busRoutes = await stoplocationsReactModel.getAllData();
            console.log('busRoutes====>', busRoutes);
            // get stats value
            var toDate = moment().format("YYYY-MM-DD");
            var fromDate = moment().add(-30, 'days').format("YYYY-MM-DD");
            console.log("fromDate======>", fromDate)
            let getCountQuery = await exceptionEventModel.getCountByDeviceId();
            console.log("getCountQuery======>", getCountQuery);
            // let getCountQuery = `SELECT DeviceId, COUNT(_id) AS count FROM exceptioneventdataset WHERE createdAt >= '${fromDate}' GROUP BY DeviceId`
            // var [getExceptionCounts, meta] = await db.query(getCountQuery, {
            //     raw: true,
            // })
            // let totalExceptions = 0

            response = {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Stops and landmarks data fetched successfully",
                    status: 1,
                    results: {
                        "type": "FeatureCollection",
                        routes: [
                            {
                                "id": "Buccleuch",
                                "name": "Buccleuch",
                                "routeStops": [
                                    {
                                        "message": "Marlboro Start",
                                        "id": 1,
                                        "longitude": 28.1108449262413,
                                        "latitude": -26.0837865886268
                                    },
                                    {
                                        "message": "MBS1 - 1",
                                        "id": 2,
                                        "longitude": 28.0965399996452,
                                        "latitude": -26.0591400003713
                                    },
                                    {
                                        "message": "MBS1 - 2",
                                        "id": 3,
                                        "longitude": 28.0987699998997,
                                        "latitude": -26.0556799997977
                                    },
                                    {
                                        "message": "MBS1 - 3",
                                        "id": 4,
                                        "longitude": 28.0988399997837,
                                        "latitude": -26.0518399998865
                                    },
                                    {
                                        "message": "MBS1 - 4",
                                        "id": 5,
                                        "longitude": 28.1025900001419,
                                        "latitude": -26.0460800004475
                                    },
                                    {
                                        "message": "MBS1 - 5",
                                        "id": 6,
                                        "longitude": 28.1091480506841,
                                        "latitude": -26.043899021233
                                    },
                                    {
                                        "message": "MBS1 - 6",
                                        "id": 7,
                                        "longitude": 28.105719999955,
                                        "latitude": -26.0474000003591
                                    },
                                    {
                                        "message": "MBS1 - 7",
                                        "id": 8,
                                        "longitude": 28.103150000374,
                                        "latitude": -26.0491499997209
                                    },
                                    {
                                        "message": "MBS1 - 8",
                                        "id": 9,
                                        "longitude": 28.1074499997586,
                                        "latitude": -26.0511799999167
                                    },
                                    {
                                        "message": "MBS1 - 9",
                                        "id": 10,
                                        "longitude": 28.1099100000417,
                                        "latitude": -26.0503900003298
                                    },
                                    {
                                        "message": "MBS1 - 10",
                                        "id": 11,
                                        "longitude": 28.1143495667517,
                                        "latitude": -26.0514021705287
                                    },
                                    {
                                        "message": "MBS1 - 11",
                                        "id": 12,
                                        "longitude": 28.1176649687348,
                                        "latitude": -26.0546153596214
                                    },
                                    {
                                        "message": "MBS1 - 12",
                                        "id": 13,
                                        "longitude": 28.1155170150552,
                                        "latitude": -26.0565817019772
                                    },
                                    {
                                        "message": "MBS1 - 13",
                                        "id": 14,
                                        "longitude": 28.1128741606667,
                                        "latitude": -26.0568443468306
                                    },
                                    {
                                        "message": "MBS1 - 14",
                                        "id": 15,
                                        "longitude": 28.1104599999961,
                                        "latitude": -26.0571000001022
                                    },
                                    {
                                        "message": "MBS1 - 15",
                                        "id": 16,
                                        "longitude": 28.1078400001184,
                                        "latitude": -26.0568799995788
                                    },
                                    {
                                        "message": "MBS1 - 16",
                                        "id": 17,
                                        "longitude": 28.102990000005,
                                        "latitude": -26.0576399996646
                                    },
                                    {
                                        "message": "MBS1 - 17",
                                        "id": 18,
                                        "longitude": 28.1005100004633,
                                        "latitude": -26.0604499998742
                                    },
                                    {
                                        "message": "MBS1 - 18",
                                        "id": 19,
                                        "longitude": 28.0991499998163,
                                        "latitude": -26.0613000003598
                                    },
                                    {
                                        "message": "MBS1 - 19",
                                        "id": 20,
                                        "longitude": 28.0963800003968,
                                        "latitude": -26.0614900002535
                                    },
                                    {
                                        "message": "Marlboro End",
                                        "id": 21,
                                        "longitude": 28.1108449262413,
                                        "latitude": -26.0837865886268
                                    }
                                ],
                                "routeCoordinates": [
                                    {
                                        "id": 144,
                                        "latitude": -26.0841882809841,
                                        "longitude": 28.1104793859317
                                    },
                                    {
                                        "id": 145,
                                        "latitude": -26.0845263301392,
                                        "longitude": 28.1106835268561
                                    },
                                    {
                                        "id": 146,
                                        "latitude": -26.084885139451,
                                        "longitude": 28.1109083588188
                                    },
                                    {
                                        "id": 147,
                                        "latitude": -26.0850606131405,
                                        "longitude": 28.1105544802632
                                    },
                                    {
                                        "id": 148,
                                        "latitude": -26.0852879585638,
                                        "longitude": 28.1100853663008
                                    },
                                    {
                                        "id": 149,
                                        "latitude": -26.0847047383719,
                                        "longitude": 28.1095743312732
                                    },
                                    {
                                        "id": 150,
                                        "latitude": -26.0844097393623,
                                        "longitude": 28.109231956797
                                    },
                                    {
                                        "id": 151,
                                        "latitude": -26.0843051733093,
                                        "longitude": 28.1090453592282
                                    },
                                    {
                                        "id": 152,
                                        "latitude": -26.0837686371729,
                                        "longitude": 28.1076795418141
                                    },
                                    {
                                        "id": 153,
                                        "latitude": -26.0835462940827,
                                        "longitude": 28.1072704231025
                                    },
                                    {
                                        "id": 154,
                                        "latitude": -26.0832654390492,
                                        "longitude": 28.1069160272759
                                    },
                                    {
                                        "id": 155,
                                        "latitude": -26.0830384140703,
                                        "longitude": 28.1067518586206
                                    },
                                    {
                                        "id": 156,
                                        "latitude": -26.0827435149812,
                                        "longitude": 28.1065981133671
                                    },
                                    {
                                        "id": 157,
                                        "latitude": -26.0825725907537,
                                        "longitude": 28.1064830732012
                                    },
                                    {
                                        "id": 158,
                                        "latitude": -26.0821987934444,
                                        "longitude": 28.1062123988669
                                    },
                                    {
                                        "id": 159,
                                        "latitude": -26.0820913087851,
                                        "longitude": 28.1061182049042
                                    },
                                    {
                                        "id": 160,
                                        "latitude": -26.081863568359,
                                        "longitude": 28.10586841523
                                    },
                                    {
                                        "id": 161,
                                        "latitude": -26.0818141677029,
                                        "longitude": 28.1058124652871
                                    },
                                    {
                                        "id": 162,
                                        "latitude": -26.0816604578853,
                                        "longitude": 28.1055711057022
                                    },
                                    {
                                        "id": 163,
                                        "latitude": -26.0815446510009,
                                        "longitude": 28.1053319105767
                                    },
                                    {
                                        "id": 164,
                                        "latitude": -26.0811409267082,
                                        "longitude": 28.1049431059135
                                    },
                                    {
                                        "id": 165,
                                        "latitude": -26.0806315847912,
                                        "longitude": 28.1044879199664
                                    },
                                    {
                                        "id": 166,
                                        "latitude": -26.0803283634561,
                                        "longitude": 28.1042242914227
                                    },
                                    {
                                        "id": 167,
                                        "latitude": -26.0803420896763,
                                        "longitude": 28.1041826993151
                                    },
                                    {
                                        "id": 168,
                                        "latitude": -26.0803186009263,
                                        "longitude": 28.1041337490023
                                    },
                                    {
                                        "id": 169,
                                        "latitude": -26.0802866803097,
                                        "longitude": 28.1041277140323
                                    },
                                    {
                                        "id": 170,
                                        "latitude": -26.080248736924,
                                        "longitude": 28.1041518539125
                                    },
                                    {
                                        "id": 171,
                                        "latitude": -26.0802397027827,
                                        "longitude": 28.1041927575985
                                    },
                                    {
                                        "id": 172,
                                        "latitude": -26.0802583733406,
                                        "longitude": 28.1042282968666
                                    },
                                    {
                                        "id": 173,
                                        "latitude": -26.0802921007924,
                                        "longitude": 28.1042417079112
                                    },
                                    {
                                        "id": 174,
                                        "latitude": -26.0803283634561,
                                        "longitude": 28.1042242914227
                                    },
                                    {
                                        "id": 175,
                                        "latitude": -26.0803420896763,
                                        "longitude": 28.1041826993151
                                    },
                                    {
                                        "id": 176,
                                        "latitude": -26.0803186009263,
                                        "longitude": 28.1041337490023
                                    },
                                    {
                                        "id": 177,
                                        "latitude": -26.0802866803097,
                                        "longitude": 28.1041277140323
                                    },
                                    {
                                        "id": 178,
                                        "latitude": -26.080248736924,
                                        "longitude": 28.1041518539125
                                    },
                                    {
                                        "id": 179,
                                        "latitude": -26.0796544783634,
                                        "longitude": 28.1036230782719
                                    },
                                    {
                                        "id": 180,
                                        "latitude": -26.0791042457232,
                                        "longitude": 28.1031318567672
                                    },
                                    {
                                        "id": 181,
                                        "latitude": -26.0785591210468,
                                        "longitude": 28.102642531863
                                    },
                                    {
                                        "id": 182,
                                        "latitude": -26.0780088832527,
                                        "longitude": 28.1021494137303
                                    },
                                    {
                                        "id": 183,
                                        "latitude": -26.0771894841049,
                                        "longitude": 28.1014154263694
                                    },
                                    {
                                        "id": 184,
                                        "latitude": -26.0764763832938,
                                        "longitude": 28.1007743519366
                                    },
                                    {
                                        "id": 185,
                                        "latitude": -26.0759993643015,
                                        "longitude": 28.1003478807063
                                    },
                                    {
                                        "id": 186,
                                        "latitude": -26.0758627874815,
                                        "longitude": 28.100229628128
                                    },
                                    {
                                        "id": 187,
                                        "latitude": -26.0758712196619,
                                        "longitude": 28.1001793367108
                                    },
                                    {
                                        "id": 188,
                                        "latitude": -26.0758598467351,
                                        "longitude": 28.10013370233
                                    },
                                    {
                                        "id": 189,
                                        "latitude": -26.0758120689044,
                                        "longitude": 28.1001211760461
                                    },
                                    {
                                        "id": 190,
                                        "latitude": -26.0757705102738,
                                        "longitude": 28.100138610404
                                    },
                                    {
                                        "id": 191,
                                        "latitude": -26.0757590665903,
                                        "longitude": 28.1001862196123
                                    },
                                    {
                                        "id": 192,
                                        "latitude": -26.0757795447599,
                                        "longitude": 28.1002398637906
                                    },
                                    {
                                        "id": 193,
                                        "latitude": -26.07582466087,
                                        "longitude": 28.1002491802362
                                    },
                                    {
                                        "id": 194,
                                        "latitude": -26.0758627874815,
                                        "longitude": 28.100229628128
                                    },
                                    {
                                        "id": 195,
                                        "latitude": -26.0758712196619,
                                        "longitude": 28.1001793367108
                                    },
                                    {
                                        "id": 196,
                                        "latitude": -26.0758598467351,
                                        "longitude": 28.10013370233
                                    },
                                    {
                                        "id": 197,
                                        "latitude": -26.0758120689044,
                                        "longitude": 28.1001211760461
                                    },
                                    {
                                        "id": 198,
                                        "latitude": -26.0757705102738,
                                        "longitude": 28.100138610404
                                    },
                                    {
                                        "id": 199,
                                        "latitude": -26.075237081413,
                                        "longitude": 28.0996721975583
                                    },
                                    {
                                        "id": 200,
                                        "latitude": -26.0742889592389,
                                        "longitude": 28.0988106118818
                                    },
                                    {
                                        "id": 201,
                                        "latitude": -26.0729579300464,
                                        "longitude": 28.0976083653801
                                    },
                                    {
                                        "id": 202,
                                        "latitude": -26.0722551468656,
                                        "longitude": 28.0969731371863
                                    },
                                    {
                                        "id": 203,
                                        "latitude": -26.0719692253974,
                                        "longitude": 28.0967218391284
                                    },
                                    {
                                        "id": 204,
                                        "latitude": -26.071976102175,
                                        "longitude": 28.0966756024182
                                    },
                                    {
                                        "id": 205,
                                        "latitude": -26.0719616465273,
                                        "longitude": 28.0966454275679
                                    },
                                    {
                                        "id": 206,
                                        "latitude": -26.071930325951,
                                        "longitude": 28.0966320165233
                                    },
                                    {
                                        "id": 207,
                                        "latitude": -26.0718911752189,
                                        "longitude": 28.0966414042545
                                    },
                                    {
                                        "id": 208,
                                        "latitude": -26.0718706963692,
                                        "longitude": 28.0966843195972
                                    },
                                    {
                                        "id": 209,
                                        "latitude": -26.0719002100044,
                                        "longitude": 28.0967439987455
                                    },
                                    {
                                        "id": 210,
                                        "latitude": -26.0719357468206,
                                        "longitude": 28.0967466809545
                                    },
                                    {
                                        "id": 211,
                                        "latitude": -26.0719692253974,
                                        "longitude": 28.0967218391284
                                    },
                                    {
                                        "id": 212,
                                        "latitude": -26.071976102175,
                                        "longitude": 28.0966756024182
                                    },
                                    {
                                        "id": 213,
                                        "latitude": -26.0719616465273,
                                        "longitude": 28.0966454275679
                                    },
                                    {
                                        "id": 214,
                                        "latitude": -26.071930325951,
                                        "longitude": 28.0966320165233
                                    },
                                    {
                                        "id": 215,
                                        "latitude": -26.0718911752189,
                                        "longitude": 28.0966414042545
                                    },
                                    {
                                        "id": 216,
                                        "latitude": -26.0715429135444,
                                        "longitude": 28.096355312532
                                    },
                                    {
                                        "id": 217,
                                        "latitude": -26.0714100310547,
                                        "longitude": 28.0962481541684
                                    },
                                    {
                                        "id": 218,
                                        "latitude": -26.0712354096074,
                                        "longitude": 28.096067976393
                                    },
                                    {
                                        "id": 219,
                                        "latitude": -26.0710122345029,
                                        "longitude": 28.0957901232966
                                    },
                                    {
                                        "id": 220,
                                        "latitude": -26.0709025543313,
                                        "longitude": 28.095621519556
                                    },
                                    {
                                        "id": 221,
                                        "latitude": -26.0705786519762,
                                        "longitude": 28.0950172763893
                                    },
                                    {
                                        "id": 222,
                                        "latitude": -26.0697428232714,
                                        "longitude": 28.0933079667011
                                    },
                                    {
                                        "id": 223,
                                        "latitude": -26.0692303824598,
                                        "longitude": 28.0922456208961
                                    },
                                    {
                                        "id": 224,
                                        "latitude": -26.068954464124,
                                        "longitude": 28.0916766934211
                                    },
                                    {
                                        "id": 225,
                                        "latitude": -26.0685332092718,
                                        "longitude": 28.0908522652723
                                    },
                                    {
                                        "id": 226,
                                        "latitude": -26.0684450632322,
                                        "longitude": 28.0906860976525
                                    },
                                    {
                                        "id": 227,
                                        "latitude": -26.0681683059937,
                                        "longitude": 28.0909405362051
                                    },
                                    {
                                        "id": 228,
                                        "latitude": -26.067700647717,
                                        "longitude": 28.0913871874239
                                    },
                                    {
                                        "id": 229,
                                        "latitude": -26.0673386178037,
                                        "longitude": 28.091728357943
                                    },
                                    {
                                        "id": 230,
                                        "latitude": -26.0672157398737,
                                        "longitude": 28.0918316229882
                                    },
                                    {
                                        "id": 231,
                                        "latitude": -26.0670488907124,
                                        "longitude": 28.0919570162585
                                    },
                                    {
                                        "id": 232,
                                        "latitude": -26.0665970313386,
                                        "longitude": 28.0921713070901
                                    },
                                    {
                                        "id": 233,
                                        "latitude": -26.066066313419,
                                        "longitude": 28.0924203413892
                                    },
                                    {
                                        "id": 234,
                                        "latitude": -26.0651505932473,
                                        "longitude": 28.0925869326652
                                    },
                                    {
                                        "id": 235,
                                        "latitude": -26.0640978023064,
                                        "longitude": 28.0927827779953
                                    },
                                    {
                                        "id": 236,
                                        "latitude": -26.0627905057879,
                                        "longitude": 28.09309231654
                                    },
                                    {
                                        "id": 237,
                                        "latitude": -26.0624586017229,
                                        "longitude": 28.0932049693177
                                    },
                                    {
                                        "id": 238,
                                        "latitude": -26.0619688758625,
                                        "longitude": 28.0933960767058
                                    },
                                    {
                                        "id": 239,
                                        "latitude": -26.0615451160476,
                                        "longitude": 28.0935565955062
                                    },
                                    {
                                        "id": 240,
                                        "latitude": -26.0614873613262,
                                        "longitude": 28.0935742074466
                                    },
                                    {
                                        "id": 241,
                                        "latitude": -26.0613554416614,
                                        "longitude": 28.0936177933415
                                    },
                                    {
                                        "id": 242,
                                        "latitude": -26.0614030291375,
                                        "longitude": 28.0938498044127
                                    },
                                    {
                                        "id": 243,
                                        "latitude": -26.0614524237125,
                                        "longitude": 28.0937103295491
                                    },
                                    {
                                        "id": 244,
                                        "latitude": -26.0614873613262,
                                        "longitude": 28.0935742074466
                                    },
                                    {
                                        "id": 245,
                                        "latitude": -26.0613554416614,
                                        "longitude": 28.0936177933415
                                    },
                                    {
                                        "id": 246,
                                        "latitude": -26.0614030291375,
                                        "longitude": 28.0938498044127
                                    },
                                    {
                                        "id": 247,
                                        "latitude": -26.0615321621984,
                                        "longitude": 28.0946379437255
                                    },
                                    {
                                        "id": 248,
                                        "latitude": -26.0615676452458,
                                        "longitude": 28.0949594297831
                                    },
                                    {
                                        "id": 249,
                                        "latitude": -26.0615250965011,
                                        "longitude": 28.0955695316803
                                    },
                                    {
                                        "id": 250,
                                        "latitude": -26.0614900046962,
                                        "longitude": 28.0959682169657
                                    },
                                    {
                                        "id": 251,
                                        "latitude": -26.061478204425,
                                        "longitude": 28.0960848698653
                                    },
                                    {
                                        "id": 252,
                                        "latitude": -26.0601733682398,
                                        "longitude": 28.0959405204406
                                    },
                                    {
                                        "id": 253,
                                        "latitude": -26.0591683913335,
                                        "longitude": 28.0965630273347
                                    },
                                    {
                                        "id": 254,
                                        "latitude": -26.0556914288434,
                                        "longitude": 28.0987733780156
                                    },
                                    {
                                        "id": 255,
                                        "latitude": -26.0545891534713,
                                        "longitude": 28.0995131688519
                                    },
                                    {
                                        "id": 256,
                                        "latitude": -26.0532275048956,
                                        "longitude": 28.1003341562049
                                    },
                                    {
                                        "id": 257,
                                        "latitude": -26.0523359406761,
                                        "longitude": 28.0986651159951
                                    },
                                    {
                                        "id": 258,
                                        "latitude": -26.0424482064239,
                                        "longitude": 28.1051845697954
                                    },
                                    {
                                        "id": 259,
                                        "latitude": -26.0424869450155,
                                        "longitude": 28.1054321115797
                                    },
                                    {
                                        "id": 260,
                                        "latitude": -26.0432571699731,
                                        "longitude": 28.1067293914707
                                    },
                                    {
                                        "id": 261,
                                        "latitude": -26.0442318721798,
                                        "longitude": 28.108049430658
                                    },
                                    {
                                        "id": 262,
                                        "latitude": -26.0439236160468,
                                        "longitude": 28.1085847622935
                                    },
                                    {
                                        "id": 263,
                                        "latitude": -26.0437115457392,
                                        "longitude": 28.1093885671429
                                    },
                                    {
                                        "id": 264,
                                        "latitude": -26.0438548365296,
                                        "longitude": 28.1094013259501
                                    },
                                    {
                                        "id": 265,
                                        "latitude": -26.0439293476714,
                                        "longitude": 28.1089547677004
                                    },
                                    {
                                        "id": 266,
                                        "latitude": -26.0441012962795,
                                        "longitude": 28.1084380360115
                                    },
                                    {
                                        "id": 267,
                                        "latitude": -26.044542629886,
                                        "longitude": 28.1079021661119
                                    },
                                    {
                                        "id": 268,
                                        "latitude": -26.0463936929729,
                                        "longitude": 28.1067209257523
                                    },
                                    {
                                        "id": 269,
                                        "latitude": -26.0468367285975,
                                        "longitude": 28.1067360986215
                                    },
                                    {
                                        "id": 270,
                                        "latitude": -26.0472388671626,
                                        "longitude": 28.1067057528931
                                    },
                                    {
                                        "id": 271,
                                        "latitude": -26.0473274737796,
                                        "longitude": 28.1065009192261
                                    },
                                    {
                                        "id": 272,
                                        "latitude": -26.0474706074041,
                                        "longitude": 28.1048850091864
                                    },
                                    {
                                        "id": 273,
                                        "latitude": -26.0474501597541,
                                        "longitude": 28.1042249895928
                                    },
                                    {
                                        "id": 274,
                                        "latitude": -26.048616192532,
                                        "longitude": 28.1034437253725
                                    },
                                    {
                                        "id": 275,
                                        "latitude": -26.050197451204,
                                        "longitude": 28.1024574891981
                                    },
                                    {
                                        "id": 276,
                                        "latitude": -26.0503201341747,
                                        "longitude": 28.1024347299018
                                    },
                                    {
                                        "id": 277,
                                        "latitude": -26.0501565568584,
                                        "longitude": 28.104649968098
                                    },
                                    {
                                        "id": 278,
                                        "latitude": -26.0504905269968,
                                        "longitude": 28.1056665501878
                                    },
                                    {
                                        "id": 279,
                                        "latitude": -26.0512470680459,
                                        "longitude": 28.1076086768082
                                    },
                                    {
                                        "id": 280,
                                        "latitude": -26.0512947776806,
                                        "longitude": 28.1078742019706
                                    },
                                    {
                                        "id": 281,
                                        "latitude": -26.0502792398827,
                                        "longitude": 28.1104308297342
                                    },
                                    {
                                        "id": 282,
                                        "latitude": -26.050531421241,
                                        "longitude": 28.1120088077989
                                    },
                                    {
                                        "id": 283,
                                        "latitude": -26.0508653902992,
                                        "longitude": 28.1136323042875
                                    },
                                    {
                                        "id": 284,
                                        "latitude": -26.0520785760344,
                                        "longitude": 28.115202695989
                                    },
                                    {
                                        "id": 285,
                                        "latitude": -26.0530191270997,
                                        "longitude": 28.1163710065341
                                    },
                                    {
                                        "id": 286,
                                        "latitude": -26.0539460396261,
                                        "longitude": 28.1171296498384
                                    },
                                    {
                                        "id": 287,
                                        "latitude": -26.0559565967392,
                                        "longitude": 28.1187531465256
                                    },
                                    {
                                        "id": 288,
                                        "latitude": -26.0565459451557,
                                        "longitude": 28.1159716501071
                                    },
                                    {
                                        "id": 289,
                                        "latitude": -26.056873649188,
                                        "longitude": 28.1124847784228
                                    },
                                    {
                                        "id": 290,
                                        "latitude": -26.0572688204885,
                                        "longitude": 28.1078821078525
                                    },
                                    {
                                        "id": 291,
                                        "latitude": -26.0566134137135,
                                        "longitude": 28.1079679385339
                                    },
                                    {
                                        "id": 292,
                                        "latitude": -26.0564065900338,
                                        "longitude": 28.1068341484769
                                    },
                                    {
                                        "id": 293,
                                        "latitude": -26.056445143543,
                                        "longitude": 28.1055574170904
                                    },
                                    {
                                        "id": 294,
                                        "latitude": -26.0565415272606,
                                        "longitude": 28.1052355520138
                                    },
                                    {
                                        "id": 295,
                                        "latitude": -26.0578908909903,
                                        "longitude": 28.1021563759998
                                    },
                                    {
                                        "id": 296,
                                        "latitude": -26.0583631571575,
                                        "longitude": 28.1017272435591
                                    },
                                    {
                                        "id": 297,
                                        "latitude": -26.0608305149744,
                                        "longitude": 28.1001071894467
                                    },
                                    {
                                        "id": 298,
                                        "latitude": -26.060951355568,
                                        "longitude": 28.0999809056353
                                    },
                                    {
                                        "id": 299,
                                        "latitude": -26.0609802695796,
                                        "longitude": 28.0998199731076
                                    },
                                    {
                                        "id": 300,
                                        "latitude": -26.0611392965156,
                                        "longitude": 28.0997770577668
                                    },
                                    {
                                        "id": 301,
                                        "latitude": -26.0612019434312,
                                        "longitude": 28.0995034724697
                                    },
                                    {
                                        "id": 302,
                                        "latitude": -26.061478204425,
                                        "longitude": 28.0960848698653
                                    }
                                ],
                                "colorScheme": "#2e7ca3"
                            },
                        ],
                        landmarks: {
                            landmarkStops: [
                                {
                                    "name": "MARLBORO",
                                    "latitude": -26.0836862867187,
                                    "longitude": 28.1117156048987,
                                    "associatedRoutes": [
                                        "Greenstone",
                                        "Linbro Business Park",
                                        "Woodlands Office Park",
                                        "Buccleuch",
                                        "Kelvin"
                                    ]
                                },
                            ], // main station points
                            landmarkAreaCoordinates: [
                                {
                                    "id": "MARLBORO",
                                    "name": "MARLBORO",
                                    "routeCoordinates": [
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0858495701361,
                                            "longitude": 28.110519717148
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0855425229037,
                                            "longitude": 28.1096819829849
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0852922758967,
                                            "longitude": 28.1070570774124
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0860145239646,
                                            "longitude": 28.1041894058546
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0865900303791,
                                            "longitude": 28.103024225474
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0880903015144,
                                            "longitude": 28.0998203427818
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0903018521705,
                                            "longitude": 28.0958620657439
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0916103970865,
                                            "longitude": 28.0913675419226
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0923658193488,
                                            "longitude": 28.0876186770117
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0923199853029,
                                            "longitude": 28.0837782758442
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0878245752677,
                                            "longitude": 28.0822071814709
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0821209732103,
                                            "longitude": 28.082461888264
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0721279774275,
                                            "longitude": 28.0841424067767
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0692230754039,
                                            "longitude": 28.0850863555546
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0674112443432,
                                            "longitude": 28.0798935992443
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0655704115544,
                                            "longitude": 28.0791318498751
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0620692933594,
                                            "longitude": 28.0788685034856
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0565581128335,
                                            "longitude": 28.0821885402183
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0553399891236,
                                            "longitude": 28.0858912619384
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0551494989175,
                                            "longitude": 28.0938096387181
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0480089464489,
                                            "longitude": 28.0984499548618
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0416125015533,
                                            "longitude": 28.1033493369807
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0410184549283,
                                            "longitude": 28.1043813026527
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0418518532541,
                                            "longitude": 28.1067056249086
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0426697955308,
                                            "longitude": 28.1084201587085
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0429300499676,
                                            "longitude": 28.1105015911764
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0442222352105,
                                            "longitude": 28.1101879500897
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0449073487331,
                                            "longitude": 28.1084131715529
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0468378202359,
                                            "longitude": 28.107578780137
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0492748989678,
                                            "longitude": 28.1071077494869
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0491618439706,
                                            "longitude": 28.1105896864648
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0499712010854,
                                            "longitude": 28.1148716018295
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0558305288246,
                                            "longitude": 28.1202648515941
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0597699802148,
                                            "longitude": 28.1181961139739
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0610361426828,
                                            "longitude": 28.1194513245032
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.065919277353,
                                            "longitude": 28.119143836891
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0755134763408,
                                            "longitude": 28.1210901507143
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0779322222083,
                                            "longitude": 28.1205635537281
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.079331968495,
                                            "longitude": 28.1275256097655
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0826862270796,
                                            "longitude": 28.1261880004458
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0866348775073,
                                            "longitude": 28.1329076076989
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0881043985861,
                                            "longitude": 28.1340929920791
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1024252351974,
                                            "longitude": 28.1339341788116
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1037543005112,
                                            "longitude": 28.1446005425484
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1083554829972,
                                            "longitude": 28.1520036708327
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.11131514232,
                                            "longitude": 28.151440910008
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1150144852988,
                                            "longitude": 28.1499388730826
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.116948359399,
                                            "longitude": 28.1504042766668
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1166758855601,
                                            "longitude": 28.1570196456862
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1165165119196,
                                            "longitude": 28.1582016697439
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.118655417412,
                                            "longitude": 28.1591575601899
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1196468131939,
                                            "longitude": 28.1562733896829
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1211243559618,
                                            "longitude": 28.1512161721912
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1217369477349,
                                            "longitude": 28.1459880934808
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1239364081896,
                                            "longitude": 28.1457073997239
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1243488024152,
                                            "longitude": 28.1413949229128
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1215657930482,
                                            "longitude": 28.1395305499614
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1206313774543,
                                            "longitude": 28.1375027472392
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1160841030911,
                                            "longitude": 28.1349893145386
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1079168131241,
                                            "longitude": 28.1346286895798
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.1046713577843,
                                            "longitude": 28.1273715039924
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0926663566216,
                                            "longitude": 28.1273672403814
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0862986811823,
                                            "longitude": 28.1269953780142
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0856434368634,
                                            "longitude": 28.1184552252099
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0859517875881,
                                            "longitude": 28.1145499292039
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0846862206449,
                                            "longitude": 28.1125115006489
                                        },
                                        {
                                            "Landmark": "MARLBORO",
                                            "name": "MARLBORO",
                                            "latitude": -26.0858495701361,
                                            "longitude": 28.110519717148
                                        }
                                    ],
                                    "associatedRoutes": [
                                        "Greenstone",
                                        "Linbro Business Park",
                                        "Woodlands Office Park",
                                        "Buccleuch",
                                        "Kelvin"
                                    ]
                                },
                            ] // all polygon
                        },
                        deviceRating: {
                            "b1": 1,
                            "b4": 0,
                            "b5": 4,
                            "b6": 4,
                            "bB": 0,
                            "bC": 0
                        },
                        stats: {
                            totalExceptions: 0,
                            avg: 0
                        },
                    },
                })
            }
            callback(null, response)
        } else {

        }
    } catch (error) {
        response = {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Internal server error",
                err: error,
                status: 0,
                results: [],
            })
        }
        callback(null, response)
    }
};

module.exports.getBusLocationTrace = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    let auth = await utils.checkAuth(event.headers, callback)

    var config = require('../../../config/config.json');
    moment.tz.setDefault(config.timeZone.africaCairo);
    let req = event.queryStringParameters;
    console.log("HI getBusLocationTrace");
    let busId = req && req.busId ? req.busId : null;
    let fromDate = req && req.fromDate ? req.fromDate : new Date().toISOString();
    let toDate = req && req.toDate ? req.toDate : new Date().toISOString();
    let response;
    try {
        if (busId == null) {
            throw new Error("BusId is invalid parameter")
        }
        // Total Distance covered by bus
        response = {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Bus exceptions data fetched successfully",
                status: 1,
                results: {
                    trace: [
                        {
                            "latitude": -25.7544193,
                            "longitude": 28.1614857,
                            "speed": 0,
                            "dateTime": "2021-11-07 08:09:28",
                            "device": {
                                "id": "b6"
                            },
                            "id": null
                        },
                        {
                            "latitude": -25.7543945,
                            "longitude": 28.1614857,
                            "speed": 0,
                            "dateTime": "2021-11-12 16:29:49",
                            "device": {
                                "id": "b6"
                            },
                            "id": "b8A226E"
                        },
                    ],
                    info: {
                        0: 3888,
                        1: 38
                    },
                    otherDetails: {
                        "BustotalDistance": 127.4,
                        "BusAvgSpeed": 15.607486565907797,
                        "BusFuelUsed": 0,
                        "BusIdlingTime": 143.37639951705933,
                        "totalTrips": 2
                        // BustotalDistance: Number(totalDistanceTravelled / 1000),
                        // BusAvgSpeed: BusAvgSpeed != null ? BusAvgSpeed : 0,
                        // BusFuelUsed: fuelUsed,
                        // BusIdlingTime,
                        // totalTrips: totalTrip && totalTrip.toalTrips ? totalTrip.toalTrips : 0
                    }
                }

            })

        }
        callback(null,response)
    } catch (err) {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: err.message ? err.message : "An Internal server error occured",
                status: 0,
                results: [],
            })
        })
    }
};
