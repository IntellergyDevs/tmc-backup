module.exports.insertEvents = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    try {
        const { BigQuery } = require('@google-cloud/bigquery');
        const root = process.cwd()
        const firebaseEventsModel = require('../../models/firebaseEvents.model');

        // Create a client
        const projectId = 'project-eagle-284910'
        const keyFilename = root + "/config/root-project-eagle.json";
        const optionsAuth = { keyFilename, projectId }
        const bigqueryClient = new BigQuery(optionsAuth)

        // The SQL query to run
        const sqlQuery = `SELECT event_name,COUNT(*)AS count FROM \`project-eagle-284910.analytics_271383377.events_20210628\` GROUP BY event_name`;

        const options = {
            query: sqlQuery,
        };

        // Run the query
        const [rows] = await bigqueryClient.query(options);

        console.log('Rows:', rows.length);
        let insertRecords = []
        rows.forEach(row => {
            insertRecords.push({
                EventName: row.event_name,
                Count: row.count,
            })
        });

        await firebaseEventsModel.bulkCreate(insertRecords, {
            updateOnDuplicate: ['EventName', 'Count', 'updatedAt']
        }).then(function () {
            console.log('then b sequelize');
            callback(null, {
                statusCode: 200,
                error: null,
                msg: "Records inserted successfully"
            });
        }).catch(function (err) {
            console.log(err);
            callback(null, {
                statusCode: 404,
                error: 1,
                msg: "Error Occured"
            });
        });
    } catch (err) {
        console.log(err);
        callback(null, {
            statusCode: 404,
            error: 1,
            msg: "Error Occured"
        });
    }
}