const moment = require('moment');
const momenttimezone = require('moment-timezone');
var config = require('../../config/config.json');
const GeotabApi = require('mg-api-js');
const authentication = {
    credentials: {
        database: config.geotab.database,
        userName: config.geotab.email,
        password: config.geotab.password,
    }
}
const api = new GeotabApi(authentication);
const db = require('../../config/db.sequelize');
const routeCoordinates = require('../../enums/route_coordinates');
const TripsData = require('../../models/tripsData.model');
const { RowBatch } = require('@google-cloud/bigquery');
const distanceHelper = require('../api/common/distanceCalculator');


moment.tz.setDefault(config.timeZone.africaCairo);

module.exports.insertTrips = async (event, context, callback) => {
    let limit = 50000;
    const tripModel = require('../../models/TripDataSet.model');
    const Device = require('../../models/Device.model');
    const lastRecord = await tripModel.findOne({
        attributes: ['id', 'StartDateTime'],
        order: [['id', 'DESC']],
        raw: true
    });
    if (lastRecord !== null && lastRecord.StartDateTime !== null) {
        var lastDate = moment(new Date(lastRecord.StartDateTime)).utc().format(config.dateFormat.UtcIsoString);
    }
    var devices = await Device.findAll({
        attributes: ['id', 'DeviceName'],
        raw: true
    })
    var all_devices = [];

    await devices.forEach(function (device, index) {
        all_devices[device.id] = device.DeviceName
    })
    var typeName = 'Trip';

    try {
        console.log("before API call try block");
        await api.call('Get', {
            typeName: typeName,
            resultsLimit: limit,
            search: {
                "fromDate": typeof (lastDate) != 'undefined' ? lastDate : "2019-07-03T16:34:33.063Z",
            }
        }).then(async function (records) {
            console.log('then b for records');
            var distance = 0;
            records = records.map(function (record) {
                let nrecord = {};
                nrecord['_id'] = record.id;
                nrecord['DeviceName'] = typeof (all_devices[record.device.id]) != 'undefined' ? all_devices[record.device.id] : '';
                nrecord['DeviceId'] = record.device.id;
                nrecord['StartDateTime'] = moment(record.start).format(config.dateFormat.powerBi);
                nrecord['StopDateTime'] = moment(record.stop).format(config.dateFormat.powerBi);
                nrecord['Distance'] = record.distance;
                nrecord['AverageSpeed'] = record.averageSpeed;
                nrecord['DrivingDuration'] = moment.duration(record.drivingDuration).asMinutes();
                nrecord['MaximumSpeed'] = record.maximumSpeed;
                nrecord['IdlingDuration'] = moment.duration(record.idlingDuration).asMinutes();
                nrecord['StopDuration'] = moment.duration(record.stopDuration).asMinutes();
                nrecord['StopPointX'] = record.stopPoint.x;
                nrecord['StopPointY'] = record.stopPoint.y;
                nrecord['NextTripStart'] = moment(record.nextTripStart).format(config.dateFormat.powerBi);
                nrecord['WorkDistance'] = record.workDistance;
                nrecord['WorkDrivingDuration'] = moment.duration(record.workDrivingDuration).asMinutes();
                nrecord['WorkStopDuration'] = moment.duration(record.workStopDuration).asMinutes();
                nrecord['createdAt'] = new Date();

                if (record.id != null && record.distance != null && record.distance >= 0.02) {
                    distance = 0;
                    return nrecord;
                } else if (record.id != null && ((record.distance + distance) >= 0.02)) {
                    distance = 0;
                    return nrecord;
                } else if (record.id != null) {
                    distance += record.distance;
                }
            });
            var filtered = records.filter(function (el) {
                return el != null;
            });
            await tripModel.bulkCreate(
                filtered, {
                ignoreDuplicates: true
            }).then(function () {
                console.log('then b sequelize');
                callback(null, {
                    statusCode: 200,
                    error: null,
                    msg: "Records inserted successfully"
                });
            }).catch(function (err) {
                console.log(err);
                callback(null, {
                    statusCode: 404,
                    error: 1,
                    msg: "Error Occured"
                });
            });
        }).catch(error => {
            console.log(error);
        });

    } catch (errrr) {
        console.log(errrr);
    }
    console.log('request end');
};

module.exports.busLiveLocationData = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    try {
        const statusDataModel = require('../../models/statusDataInfo.model');

        await api.call('Get', {
            typeName: 'DeviceStatusInfo',
        }).then(async function (records) {
            let filtered = records.map(record => {
                let nrecord = {};
                nrecord['currentStateDuration'] = record.currentStateDuration;
                nrecord['isDeviceCommunicating'] = record.isDeviceCommunicating == true ? 1 : 0;
                nrecord['isDriving'] = record.isDriving == true ? 1 : 0;
                nrecord['latitude'] = record.latitude;
                nrecord['longitude'] = record.longitude;
                nrecord['dateTime'] = record.dateTime;
                nrecord['deviceId'] = record.device.id;
                nrecord['updatedAt'] = new Date();
                return nrecord;
            });

            await statusDataModel.bulkCreate(filtered, {
                updateOnDuplicate: ['currentStateDuration', 'isDeviceCommunicating', 'isDriving', 'latitude', 'longitude', 'deviceId', 'dateTime', 'updatedAt']
            }).then(function () {
                callback(null, {
                    statusCode: 200,
                    error: null,
                    msg: "Records inserted successfully"
                });
            }).catch(function (err) {
                console.log(err);
                callback(null, {
                    statusCode: 404,
                    error: 1,
                    msg: "Error Occurred"
                });
            });
        }).catch(err => { throw new Error(err) });
    } catch (err) {
        callback(err, "Err");
    }
};

module.exports.determineRoute = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    const routeDeterminationModel = require('../../models/routeDetermination.model');
    const CompletedTripsModel = require('../../models/CompletedTrips.model');

    const geolib = require('geolib');

    try {
        const currentHour = moment().format('H')
        let reset = false
        if (currentHour == 5) {
            reset = true
        }
        console.log('before api call', 'utc', currentHour, reset)

        let stopsFullQuery = "SELECT * FROM stopsFullPath";
        const p1 = db.query(stopsFullQuery, {});

        let busLocationQuery = "SELECT latitude,longitude,routeDetermination.isRouteReset AS isRouteReset, routeDetermination.isBusInStation AS isBusInStation,routeDetermination.deviceName AS deviceName, routeDetermination.pastList AS pastList,currentRouteDetermined, routeDetermination.deviceId FROM deviceStatusInfo LEFT JOIN routeDetermination ON deviceStatusInfo.deviceId = routeDetermination.deviceId";
        const p2 = db.query(busLocationQuery, {});

        let routeQuery = "SELECT * FROM routeDetermination";
        const p3 = db.query(routeQuery, {});

        let getBoundary = `SELECT name, stationBoundary, associatedRoutes FROM stopsLandmarks WHERE type = 'train'`
        const p4 = db.query(getBoundary, {
            raw: true,
        })

        let getPolygonsQuery = `SELECT name, landmarkId,Latitude AS latitude,Longitude AS longitude FROM stopsSurroundingStops`
        const p5 = db.query(getPolygonsQuery, {
            raw: true,
        })

        let getStopsForStationQuery = `SELECT id, routeAllocationName,StopNumber, PointX, PointY,sequence FROM stoplocations_react WHERE include = 1`
        const p6 = db.query(getStopsForStationQuery, {
            raw: true,
        })
        let stopsObj = {}

        let completedTripsQuery = `SELECT * FROM completedTrips WHERE date >= '${moment().format('YYYY-MM-DD')} 00:00:00'`
        const p7 = db.query(completedTripsQuery, {
            raw: true,
        })
        await Promise.all([p1, p2, p3, p4, p5, p6, p7]).then(async (values) => {
            let fullPath = values[0][0]
            let busLocations = values[1][0]
            let currentRoute = values[2][0]
            let Boundary = values[3][0]
            let polygons = values[4][0]
            let stops = values[5][0]

            let isEntryCompleted = values[6][0].length == 0 ? false : true;
            let completedRecord = values[6][0]
            // console.log(completedRecord)
            const polygonSorted = {}
            let completedTrips = {
                date: moment().utc().format('YYYY-MM-DD')
            }
            polygons.forEach((element, index) => {
                if (!polygonSorted[element.name]) {
                    polygonSorted[element.name] = []
                }
                polygonSorted[element.name].push({
                    ...element
                })

            })
            stops.forEach(element => {

                if (!stopsObj[element.routeAllocationName]) {
                    stopsObj[element.routeAllocationName] = {}
                    stopsObj[element.routeAllocationName]['stops'] = []
                }
                stopsObj[element.routeAllocationName]['stops'].push({
                    StopNumber: element.StopNumber,
                    latitude: element.PointY,
                    longitude: element.PointX,
                    sequence: element.sequence,
                })
            });
            Boundary.forEach((element, index) => {
                Boundary[index]['associatedRoutes'] = JSON.parse(element.associatedRoutes)
                Boundary[index]['stationBoundary'] = JSON.parse(element.stationBoundary)
            });
            let onlyCoords = fullPath.map(rec => {
                return {
                    latitude: rec.Latitude,
                    longitude: rec.Longitude,
                }
            })

            let shortestDistance = {}
            busLocations.forEach(location => {
                let shortest = geolib.findNearest({ latitude: (location.latitude), longitude: (location.longitude) }, onlyCoords);

                shortestDistance[location.deviceId] = {}
                shortestDistance[location.deviceId]['location'] = shortest
                shortestDistance[location.deviceId]['isRouteReset'] = location.isRouteReset
                shortestDistance[location.deviceId]['deviceName'] = location.deviceName
                shortestDistance[location.deviceId]['pastList'] = JSON.parse(location.pastList)
            });

            for (const [index, bus] of Object.entries(shortestDistance)) {
                const indexFound = currentRoute.findIndex(rec => rec.deviceId == index)
                shortestDistance[index]['countables'] = indexFound == -1 ? {} : JSON.parse(currentRoute[indexFound].totalCountables)
                shortestDistance[index]['allRoutes'] = fullPath.filter(record => record.Latitude == bus.location.latitude && record.Longitude == bus.location.longitude)
            }
            for (const [index, bus] of Object.entries(shortestDistance)) {
                bus.allRoutes.forEach(route => {
                    const name = route.name
                    if (shortestDistance[index]['countables'] && shortestDistance[index]['countables'][name]) {
                        shortestDistance[index]['countables'][name] += 1
                    } else {
                        shortestDistance[index]['countables'][name] = 1
                    }
                });
            }

            let insertRecords = []
            for (const [index, bus] of Object.entries(shortestDistance)) {
                let maxName = ''
                let maxvalue = 0

                for (const [indexc, counta] of Object.entries(bus.countables)) {
                    if (counta >= maxvalue) {
                        maxvalue = counta
                        maxName = indexc
                    }
                }
                let station = ''
                let isPointInPolygon = 0
                let boundaryPoints = Boundary.find(rec => {
                    if (rec.associatedRoutes.includes(maxName)) {
                        station = rec.name
                        return true
                    }
                })
                let pastList = bus.pastList ? bus.pastList : []
                let isRouteReset = bus.isRouteReset
                const inBoundary = geolib.isPointInPolygon(bus.location, boundaryPoints.stationBoundary) ? 1 : 0;
                let nearest

                completedTrips[bus.deviceName] = 0
                if (inBoundary == 1) {
                    pastList = [2, 3, 4]
                    isRouteReset = 1
                } else {
                    if (station != '') {
                        isPointInPolygon = geolib.isPointInPolygon(bus.location, polygonSorted[station]);
                    }
                    completedTrips[bus.deviceName] = bus.isRouteReset == 1 ? 1 : 0
                    isRouteReset = 0
                    let distances = []
                    stopsObj[maxName]['stops'].forEach(element => {
                        const disBetweenBusAndStop = geolib.getDistance(
                            element,
                            bus.location
                        );
                        distances.push({
                            ...element,
                            d: disBetweenBusAndStop
                        })
                    });
                    distances.sort(function (a, b) {
                        if (a.d < b.d) return -1;
                        if (a.d > b.d) return 1;
                        return 0;
                    });
                    let Nearest = distances[0]
                    let SNearest = distances[1]

                    if (pastList.includes(Nearest.sequence)) {
                        // nearest
                        nearest = Nearest
                    } else if (pastList.includes(SNearest.sequence + 1)) {
                        // second nearest
                        nearest = SNearest
                    } else {
                        nearest = Nearest
                    }
                    pastList = [
                        nearest.sequence,
                        nearest.sequence + 1,
                        nearest.sequence + 2,
                    ]
                }

                insertRecords.push({
                    deviceId: index,
                    totalCountables: reset ? '{}' : JSON.stringify(bus.countables),
                    currentRouteDetermined: maxName,
                    isBusInStation: inBoundary,
                    updatedAt: new Date(),
                    pastList: JSON.stringify(pastList),
                    isRouteReset,
                    currentStation: nearest && nearest.StopNumber ? nearest.StopNumber : null
                })
            }
            if (isEntryCompleted) {
                // update

                // completedTrips['HD03HNGP'] = 1
                const arr = ['id', 'date', 'createdAt', 'updatedAt']
                for (const property in completedRecord[0]) {

                    if (!arr.includes(property) && typeof (completedTrips[property] != 'undefined')) {
                        console.log('<>', property)
                        completedTrips[property] += Number(completedRecord[0][property])
                    }
                }
                let id = completedRecord[0].id
                CompletedTripsModel.update(completedTrips, {
                    where: {
                        id: id
                    }
                }).then(res => {
                    console.log('updated')
                }).catch(err => {
                    throw new Error(err.message)
                })
            } else {

                // insert
                await CompletedTripsModel.create(
                    completedTrips
                ).then(res => {
                    console.log('inserted')
                }).catch(err => {
                    throw new Error(err.message)
                })
            }
            await routeDeterminationModel.bulkCreate(insertRecords, {
                updateOnDuplicate: ['totalCountables', 'currentRouteDetermined', 'updatedAt', 'isBusInStation', 'pastList', 'isRouteReset', 'currentStation']
            }).then(function () {
                callback(null, {
                    statusCode: 200,
                    error: null,
                    msg: "Records inserted successfully"
                });
            }).catch(function (err) {
                console.log(err);
                callback(null, {
                    statusCode: 404,
                    error: 1,
                    msg: "Error Occured"
                });
            });
            console.log('request end');

            // console.log(shortestDistance)
        });



    } catch (err) {
        callback(err, "Err");
    }
};

module.exports.completedTrips = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    const routeDeterminationModel = require('../../models/routeDetermination.model');

    let routeQuery = "SELECT * FROM routeDetermination";
    const p1 = db.query(routeQuery, {});

    await Promise.all([p1]).then(async (values) => {
        let routeDeterminationDetails = values[0][0]
        console.log(routeDeterminationDetails)
    })

    console.log('compl')
}

module.exports.determineRouteNew = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    const routeDeterminationModel = require('../../models/routeDetermination.model');
    const CompletedTripsModel = require('../../models/CompletedTrips.model');
    const geolib = require('geolib');

    try {
        const currentHour = moment().format('H');
        let reset = false;

        // If the current time is 5AM reset the route
        if (currentHour == 5) {
            reset = true;
        }

        let stopsFullQuery = "SELECT * FROM stopsFullPath";
        const p1 = db.query(stopsFullQuery, {});

        let busLocationQuery = `SELECT currentStation,latitude,longitude,isDriving,routeDetermination.totalCountables as totalCountables,routeDetermination.isRouteReset AS isRouteReset, routeDetermination.isBusInStation AS isBusInStation,routeDetermination.deviceName AS deviceName, routeDetermination.pastList AS pastList,currentRouteDetermined, routeDetermination.deviceId FROM deviceStatusInfo LEFT JOIN routeDetermination ON deviceStatusInfo.deviceId = routeDetermination.deviceId`;
        const p2 = db.query(busLocationQuery, {});

        let routeQuery = "SELECT * FROM routeDetermination";
        const p3 = db.query(routeQuery, {});

        let getBoundary = `SELECT name, stationBoundary, associatedRoutes FROM stopsLandmarks WHERE type = 'train'`;
        const p4 = db.query(getBoundary, {
            raw: true,
        })

        let getPolygonsQuery = `SELECT name, landmarkId,Latitude AS latitude,Longitude AS longitude FROM stopsSurroundingStops`;
        const p5 = db.query(getPolygonsQuery, {
            raw: true,
        })

        let getStopsForStationQuery = `SELECT id, routeAllocationName,StopNumber, PointX, PointY,sequence FROM stoplocations_react WHERE include = 1`;
        const p6 = db.query(getStopsForStationQuery, {
            raw: true,
        });

        let completedTripsQuery = `SELECT * FROM completedTrips WHERE date >= '${moment().format('YYYY-MM-DD')} 00:00:00'`;
        const p7 = db.query(completedTripsQuery, {
            raw: true,
        });

        let stopsObj = {};
        await Promise.all([p1, p2, p3, p4, p5, p6, p7]).then(async (values) => {
            let fullPath = values[0][0];
            let busLocations = values[1][0];
            let currentRoute = values[2][0];
            let Boundary = values[3][0];
            let polygons = values[4][0];
            let stops = values[5][0];
            let isEntryCompleted = values[6][0].length == 0 ? false : true;
            let completedRecord = values[6][0];
            let completedTrips = {
                date: moment().utc().format('YYYY-MM-DD')
            };
            const polygonSorted = {};

            //inserting polygons into polygonSorted object
            for (let element of polygons) {
                if (!polygonSorted[element.name]) {
                    polygonSorted[element.name] = [];
                }
                polygonSorted[element.name].push({
                    ...element
                });
            }

            // inserting stops into stopsObj variable
            for (let element of stops) {
                if (!stopsObj[element.routeAllocationName]) {
                    stopsObj[element.routeAllocationName] = {}
                    stopsObj[element.routeAllocationName]['stops'] = []
                }
                stopsObj[element.routeAllocationName]['stops'].push({
                    StopName: element.routeAllocationName,
                    StopNumber: element.StopNumber,
                    latitude: element.PointY,
                    longitude: element.PointX,
                    sequence: element.sequence,
                })
            }

            // converting text data type to json data type
            Boundary.forEach((element, index) => {
                Boundary[index]['associatedRoutes'] = JSON.parse(element.associatedRoutes)
                Boundary[index]['stationBoundary'] = JSON.parse(element.stationBoundary)
            });

            let boundariesOnlyCords = {};
            Boundary.forEach((boundaryElement, index) => {
                if (!boundariesOnlyCords[boundaryElement.name]) {
                    boundariesOnlyCords[boundaryElement.name] = {};
                }
                boundariesOnlyCords[boundaryElement.name]['stationBoundary'] = boundaryElement.stationBoundary;
                boundariesOnlyCords[boundaryElement.name]['associatedRoutes'] = boundaryElement.associatedRoutes;
            });

            //retrieving location coordinates from fullPath array
            let onlyCoords = fullPath.map(rec => {
                return {
                    latitude: rec.Latitude,
                    longitude: rec.Longitude,
                }
            });

            //insert data into shortestDistance variable and calculating nearest lat lng using geolib library
            let shortestDistance = {};
            for (let location of busLocations) {
                // if (location.deviceId == "b4") location['latitude'] = `-25.873981866004875`; // HighveldBox -25.873981866004875, 28.193570377306884
                // if (location.deviceId == "b4") location['longitude'] = `28.193570377306884`; // MidstreamBox -25.87777557458201, 28.20079090134727
                // if (location.deviceId == "b4") location['isRouteReset'] = 0;
                // if (location.deviceId == "b4") location['currentStation'] = "Centurion Start";
                // if (location.deviceId == "b4") location['currentStation'] = "HCS1 - 1";
                // if (location.deviceId == "b4") location['isDriving'] = 1;
                // if (location.deviceId == "b4") location['pastList'] = "[2,3,4]";

                let shortest = geolib.findNearest({ latitude: (location.latitude), longitude: (location.longitude) }, onlyCoords);

                shortestDistance[location.deviceId] = {};
                shortestDistance[location.deviceId]['location'] = shortest;
                shortestDistance[location.deviceId]['isRouteReset'] = location.isRouteReset;
                shortestDistance[location.deviceId]['deviceName'] = location.deviceName;
                shortestDistance[location.deviceId]['pastList'] = JSON.parse(location.pastList);
                shortestDistance[location.deviceId]['longitude'] = location.longitude;
                shortestDistance[location.deviceId]['latitude'] = location.latitude;
                shortestDistance[location.deviceId]['currentStation'] = location.currentStation;
                shortestDistance[location.deviceId]['isDriving'] = location.isDriving;
                shortestDistance[location.deviceId]['totalCountables'] = JSON.parse(location.totalCountables);
                shortestDistance[location.deviceId]['stops'] = [];
                shortestDistance[location.deviceId]['detectedRoute'] = null;
                shortestDistance[location.deviceId]['busStation'] = null;
                shortestDistance[location.deviceId]['isBusInsideBusStand'] = 1;

                // Detecting current route                
                //check if bus is driving
                let isBusInsideBusStand = true;
                // if (location.deviceId == "b6" || location.deviceId == "b4") {
                if (location.isDriving == 1) {
                    //check if bus is stopped outside bus station
                    let arrRoutes = [];
                    for (let [key, value] of Object.entries(JSON.parse(location.totalCountables))) {
                        arrRoutes.push(key);
                    }
                    let boundaryPoints;
                    if (arrRoutes.length > 0) {
                        for (let route of arrRoutes) {
                            //check if bus is not at bus stand
                            boundaryPoints = Boundary.find(rec => {
                                if (rec.associatedRoutes.includes(route)) {
                                    return true
                                }
                            });
                        }
                    }
                    if (boundaryPoints) {
                        isBusInsideBusStand = geolib.isPointInPolygon(
                            {
                                latitude: location.latitude,
                                longitude: location.longitude,
                            },
                            boundaryPoints.stationBoundary
                        );
                    }
                    // console.log(`${location.deviceId} is driving and isInside = ${isBusInsideBusStand} ${boundaryPoints.name}`);

                    //if bus is not at bus stand
                    if (!isBusInsideBusStand) {
                        let lastTrip = await TripsData.findOne({
                            where: {
                                DeviceId: location.deviceId
                            },
                            order: [['id', 'DESC']],
                            raw: true
                        });
                        if (lastTrip) {
                            if (lastTrip.isCompleted == 1) {
                                //create new entry
                                let routeCoordinatesObj = routeCoordinates[boundaryPoints.name] ? routeCoordinates[boundaryPoints.name] : null;
                                let isInsideBox;
                                let detectedRoute;
                                if (routeCoordinatesObj) {
                                    for (let [key, value] of Object.entries(routeCoordinatesObj)) {
                                        isInsideBox = geolib.isPointInPolygon(
                                            {
                                                latitude: location.latitude,
                                                longitude: location.longitude,
                                            },
                                            value
                                        );
                                        if (isInsideBox) {
                                            detectedRoute = key;
                                            break;
                                        }
                                    }
                                }
                                shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute ? detectedRoute : null;
                                shortestDistance[location.deviceId]['busStation'] = boundaryPoints.name ? boundaryPoints.name : null;
                                await TripsData.create({
                                    DeviceName: location.deviceName,
                                    DeviceId: location.deviceId,
                                    isDriving: location.isDriving,
                                    isCompleted: 0,
                                    busStation: boundaryPoints.name,
                                    detectedRoute: detectedRoute ? detectedRoute : null,
                                    busStation: boundaryPoints.name ? boundaryPoints.name : null,
                                    checkpoint: `[${location.latitude}, ${location.longitude}]`
                                });
                            }
                            else {
                                //check if route was detected already
                                if (lastTrip.detectedRoute) {
                                    shortestDistance[location.deviceId]['detectedRoute'] = lastTrip.detectedRoute;
                                    shortestDistance[location.deviceId]['busStation'] = lastTrip.busStation;
                                }
                                else {
                                    //check if bus is inside BOX and update old last entry
                                    let routeCoordinatesObj = routeCoordinates[boundaryPoints.name] ? routeCoordinates[boundaryPoints.name] : null;
                                    let isInsideBox;
                                    let detectedRoute;
                                    if (routeCoordinatesObj) {
                                        for (let [key, value] of Object.entries(routeCoordinatesObj)) {
                                            isInsideBox = geolib.isPointInPolygon(
                                                {
                                                    latitude: location.latitude,
                                                    longitude: location.longitude,
                                                },
                                                value
                                            );
                                            if (isInsideBox) {
                                                detectedRoute = key;
                                                break;
                                            }
                                        }
                                    }
                                    shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute ? detectedRoute : null;
                                    shortestDistance[location.deviceId]['busStation'] = boundaryPoints.name ? boundaryPoints.name : null;
                                    //update table raw with the same
                                    await TripsData.update(
                                        {
                                            detectedRoute: detectedRoute ? detectedRoute : null,
                                            busStation: boundaryPoints.name ? boundaryPoints.name : null,
                                            isDriving: location.isDriving,
                                            checkpoint: `[${location.latitude}, ${location.longitude}]`
                                        },
                                        {
                                            where: {
                                                id: lastTrip.id
                                            }
                                        }
                                    );
                                }
                            }
                        }
                        else {
                            //create new entry
                            let routeCoordinatesObj = routeCoordinates[boundaryPoints.name] ? routeCoordinates[boundaryPoints.name] : null;
                            let isInsideBox;
                            let detectedRoute;
                            if (routeCoordinatesObj) {
                                for (let [key, value] of Object.entries(routeCoordinatesObj)) {
                                    isInsideBox = geolib.isPointInPolygon(
                                        {
                                            latitude: location.latitude,
                                            longitude: location.longitude,
                                        },
                                        value
                                    );
                                    if (isInsideBox) {
                                        detectedRoute = key;
                                        break;
                                    }
                                }
                            }
                            shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute ? detectedRoute : null;
                            shortestDistance[location.deviceId]['busStation'] = boundaryPoints.name ? boundaryPoints.name : null;
                            await TripsData.create({
                                DeviceName: location.deviceName,
                                DeviceId: location.deviceId,
                                isDriving: location.isDriving,
                                isCompleted: 0,
                                busStation: boundaryPoints.name,
                                detectedRoute: detectedRoute ? detectedRoute : null,
                                busStation: boundaryPoints.name ? boundaryPoints.name : null,
                                checkpoint: `[${location.latitude}, ${location.longitude}]`
                            });
                        }
                    }
                    else {
                        shortestDistance[location.deviceId]['detectedRoute'] = null;
                        shortestDistance[location.deviceId]['busStation'] = null;
                    }
                }
                else {
                    //bus is not driving
                    //check if bus is stopped outside bus station
                    let arrRoutes = [];
                    for (let [key, value] of Object.entries(JSON.parse(location.totalCountables))) {
                        arrRoutes.push(key);
                    }
                    let boundaryPoints;
                    if (arrRoutes.length > 0) {
                        for (let route of arrRoutes) {
                            //check if bus is not at bus stand
                            boundaryPoints = Boundary.find(rec => {
                                if (rec.associatedRoutes.includes(route)) {
                                    return true
                                }
                            });
                        }
                    }
                    if (boundaryPoints) {
                        isBusInsideBusStand = geolib.isPointInPolygon(
                            {
                                latitude: location.latitude,
                                longitude: location.longitude,
                            },
                            boundaryPoints.stationBoundary
                        );
                    }
                    // console.log(`${location.deviceId} is driving and isInside = ${isBusInsideBusStand}`);

                    //if bus is not at bus stand
                    if (!isBusInsideBusStand) {
                        let lastTrip = await TripsData.findOne({
                            where: {
                                DeviceId: location.deviceId
                            },
                            order: [['id', 'DESC']],
                            raw: true
                        });
                        if (lastTrip) {
                            if (lastTrip.isCompleted == 1) {
                                //create new entry
                                let routeCoordinatesObj = routeCoordinates[boundaryPoints.name] ? routeCoordinates[boundaryPoints.name] : null;
                                let isInsideBox;
                                let detectedRoute;
                                if (routeCoordinatesObj) {
                                    for (let [key, value] of Object.entries(routeCoordinatesObj)) {
                                        isInsideBox = geolib.isPointInPolygon(
                                            {
                                                latitude: location.latitude,
                                                longitude: location.longitude,
                                            },
                                            value
                                        );
                                        if (isInsideBox) {
                                            detectedRoute = key;
                                            break;
                                        }
                                    }
                                }
                                shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute ? detectedRoute : null;
                                shortestDistance[location.deviceId]['busStation'] = boundaryPoints.name ? boundaryPoints.name : null;
                                await TripsData.create({
                                    DeviceName: location.deviceName,
                                    DeviceId: location.deviceId,
                                    isDriving: location.isDriving,
                                    isCompleted: 0,
                                    busStation: boundaryPoints.name,
                                    detectedRoute: detectedRoute ? detectedRoute : null,
                                    busStation: boundaryPoints.name ? boundaryPoints.name : null,
                                    checkpoint: `[${location.latitude}, ${location.longitude}]`
                                });
                            }
                            else {
                                //check if route was detected already
                                if (lastTrip.detectedRoute) {
                                    shortestDistance[location.deviceId]['detectedRoute'] = lastTrip.detectedRoute;
                                    shortestDistance[location.deviceId]['busStation'] = lastTrip.busStation;
                                }
                                else {
                                    //check if bus is inside BOX and update old last entry
                                    let routeCoordinatesObj = routeCoordinates[boundaryPoints.name] ? routeCoordinates[boundaryPoints.name] : null;
                                    let isInsideBox;
                                    let detectedRoute;
                                    if (routeCoordinatesObj) {
                                        for (let [key, value] of Object.entries(routeCoordinatesObj)) {
                                            isInsideBox = geolib.isPointInPolygon(
                                                {
                                                    latitude: location.latitude,
                                                    longitude: location.longitude,
                                                },
                                                value
                                            );
                                            if (isInsideBox) {
                                                detectedRoute = key;
                                                break;
                                            }
                                        }
                                    }
                                    shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute ? detectedRoute : null;
                                    shortestDistance[location.deviceId]['busStation'] = boundaryPoints.name ? boundaryPoints.name : null;
                                    //update table raw with the same
                                    await TripsData.update(
                                        {
                                            detectedRoute: detectedRoute ? detectedRoute : null,
                                            busStation: boundaryPoints.name ? boundaryPoints.name : null,
                                            isDriving: location.isDriving,
                                            checkpoint: `[${location.latitude}, ${location.longitude}]`
                                        },
                                        {
                                            where: {
                                                id: lastTrip.id
                                            }
                                        }
                                    );
                                }
                            }
                        }
                        else {
                            //create new entry
                            let routeCoordinatesObj = routeCoordinates[boundaryPoints.name] ? routeCoordinates[boundaryPoints.name] : null;
                            let isInsideBox;
                            let detectedRoute;
                            if (routeCoordinatesObj) {
                                for (let [key, value] of Object.entries(routeCoordinatesObj)) {
                                    isInsideBox = geolib.isPointInPolygon(
                                        {
                                            latitude: location.latitude,
                                            longitude: location.longitude,
                                        },
                                        value
                                    );
                                    if (isInsideBox) {
                                        detectedRoute = key;
                                        break;
                                    }
                                }
                            }
                            shortestDistance[location.deviceId]['detectedRoute'] = detectedRoute ? detectedRoute : null;
                            shortestDistance[location.deviceId]['busStation'] = boundaryPoints.name ? boundaryPoints.name : null;
                            await TripsData.create({
                                DeviceName: location.deviceName,
                                DeviceId: location.deviceId,
                                isDriving: location.isDriving,
                                isCompleted: 0,
                                busStation: boundaryPoints.name,
                                detectedRoute: detectedRoute ? detectedRoute : null,
                                busStation: boundaryPoints.name ? boundaryPoints.name : null,
                                checkpoint: `[${location.latitude}, ${location.longitude}]`
                            });
                        }
                    }
                    else {
                        let lastTrip = await TripsData.findOne({
                            where: {
                                DeviceId: location.deviceId
                            },
                            order: [['id', 'DESC']],
                            raw: true
                        });
                        if (lastTrip) {
                            if (lastTrip.isCompleted == 1) {
                                // do nothing
                                shortestDistance[location.deviceId]['detectedRoute'] = null;
                                shortestDistance[location.deviceId]['busStation'] = null;
                                await TripsData.update({
                                    isDriving: location.isDriving
                                }, {
                                    where: {
                                        id: lastTrip.id
                                    }
                                });
                            }
                            else {
                                //Update isCompleted with true
                                shortestDistance[location.deviceId]['detectedRoute'] = null;
                                shortestDistance[location.deviceId]['busStation'] = null;
                                await TripsData.update({
                                    isCompleted: 1,
                                    isDriving: location.isDriving
                                }, {
                                    where: {
                                        id: lastTrip.id
                                    }
                                });
                            }
                        }
                        else {
                            shortestDistance[location.deviceId]['detectedRoute'] = null;
                            shortestDistance[location.deviceId]['busStation'] = null;
                        }
                    }
                }
                shortestDistance[location.deviceId]['isBusInsideBusStand'] = isBusInsideBusStand ? 1 : 0;
                // }
                // else {
                //     shortestDistance[location.deviceId]['detectedRoute'] = null;
                //     shortestDistance[location.deviceId]['busStation'] = null;
                //     shortestDistance[location.deviceId]['isBusInsideBusStand'] = 1;
                // }
            }

            //insert countables and allRouted into shortestDistance object
            for (const [index, bus] of Object.entries(shortestDistance)) {
                //finding deviceId in routeDetermination table
                const indexFound = currentRoute.findIndex(rec => rec.deviceId == index);

                //assigning totalCountable from routeDetermination table
                shortestDistance[index]['countables'] = indexFound == -1 ? {} : JSON.parse(currentRoute[indexFound].totalCountables);

                //insert all routes of a bus stand
                const routes = new Set();
                shortestDistance[index]['allRoutes'] = fullPath.filter(record => {
                    if (record.Latitude == bus.location.latitude && record.Longitude == bus.location.longitude) {
                        if (routes.has(record.name)) {
                            return false;
                        }
                        routes.add(record.name);
                        return true;
                    } else {
                        return false;
                    }
                });
            }

            // increasing countables and inserting stops into shortestDistance from stopObj
            for (const [index, bus] of Object.entries(shortestDistance)) {
                bus.allRoutes.forEach(route => {
                    const name = route.name;
                    //increase count and update shortestDistance object
                    if (shortestDistance[index]['countables'] && shortestDistance[index]['countables'][name]) {
                        shortestDistance[index]['countables'][name] += 1;
                    } else {
                        shortestDistance[index]['countables'][name] = 1;
                    }

                    //insert stops in shortestDistance object
                    if (stopsObj[name]['stops'] && stopsObj[name]['stops'].length > 0) {
                        for (let stop of stopsObj[name]['stops']) {
                            shortestDistance[index]['stops'].push(stop);
                        }
                    }
                });
            }

            let insertRecords = [];
            for (const [index, bus] of Object.entries(shortestDistance)) {
                let pastList = bus.pastList ? bus.pastList : [];
                let isRouteReset = bus.isRouteReset;
                let maxName = '';
                let onlyStopCoords;
                let filterStops;

                if (bus.detectedRoute) {
                    console.log(`---------- Yes route ${bus.detectedRoute} has been detected.`);
                    //remove unwanted stops
                    bus.stops = bus.stops.filter((element) => element.StopName == bus.detectedRoute);

                    //assign bus stops to variable filterStops
                    filterStops = bus.stops;

                    //separating  coordinates from stops
                    onlyStopCoords = filterStops.map(rec => {
                        return {
                            latitude: rec.latitude,
                            longitude: rec.longitude,
                        }
                    });

                    //getting nearest stop
                    let shortestStop = geolib.findNearest({ latitude: (bus.latitude), longitude: (bus.longitude) }, onlyStopCoords);

                    //getting current route/stop
                    let getCurrentRoute = filterStops.find((x) => x.longitude == shortestStop.longitude && x.latitude == shortestStop.latitude);

                    //filter stops with current route
                    if (getCurrentRoute) {
                        maxName = getCurrentRoute.StopName;
                        // filterStops = filterStops.filter((x) => x.StopName == getCurrentRoute.StopName);
                    }

                    //get boundary points with respect to current route
                    let boundaryPoints = Boundary.find(rec => {
                        if (rec.associatedRoutes.includes(maxName)) {
                            return true
                        }
                    });

                    //check if bus is inside bus stand using geolib library
                    const inBoundary = geolib.isPointInPolygon({
                        latitude: bus.latitude,
                        longitude: bus.longitude
                    }, boundaryPoints.stationBoundary) ? 1 : 0;

                    let isPointInLine = false;

                    //check if all the points are on same line
                    filterStops.forEach((stop, index) => {
                        //if next stop available
                        if (filterStops[index + 1]) {
                            let inLine = geolib.isPointInLine(
                                {
                                    latitude: bus.latitude,
                                    longitude: bus.longitude
                                },
                                {
                                    latitude: filterStops[index].latitude,
                                    longitude: filterStops[index].longitude
                                },
                                {
                                    latitude: filterStops[index + 1].latitude,
                                    longitude: filterStops[index + 1].longitude
                                }
                            ) ? true : false;

                            if (isPointInLine != true) {
                                isPointInLine = inLine;
                            }
                        }
                    });

                    // find nearest STOP here
                    let nearest;
                    completedTrips[bus.deviceName] = 0;
                    // if bus is inside the bus stand
                    if (inBoundary == 1) {
                        pastList = [2, 3, 4];
                        isRouteReset = 1;
                    }
                    else {
                        completedTrips[bus.deviceName] = bus.isRouteReset == 1 ? 1 : 0;
                        isRouteReset = 0;
                        // let distances = [];
                        //sorting stops according to sequence
                        filterStops.sort((a, b) => a.sequence - b.sequence);

                        if (bus['currentStation'] == null) {
                            //if current station is NULL then nearest stop is first index of stops
                            nearest = filterStops[0];
                            pastList = [
                                nearest.sequence,
                                nearest.sequence + 1,
                                nearest.sequence + 2,
                            ];

                            // -----> distance calculator start
                            let arrDistances = [];
                            let lastTrip = await TripsData.findOne({
                                where: {
                                    DeviceId: index,
                                    isCompleted: 0
                                },
                                order: [['id', 'DESC']],
                                raw: true
                            });

                            if (lastTrip) {
                                let checkpoint = lastTrip.checkpoint ? JSON.parse(lastTrip.checkpoint) : [bus.latitude, bus.longitude];
                                if (lastTrip.nextStops == null) {
                                    for (let past of pastList) {
                                        if (arrDistances.length < 2) {
                                            let distanceFromBusToStop = await distanceHelper.distanceBetweenTwoPoints(checkpoint[0], checkpoint[1], filterStops[past - 1].latitude, filterStops[past - 1].longitude, "M");
                                            arrDistances.push({
                                                ...filterStops[past - 1],
                                                isStopPassed: 0,
                                                originalDistance: distanceFromBusToStop,
                                                tempDistance: 0
                                            });
                                        }
                                    }
                                    await TripsData.update({
                                        nextStops: JSON.stringify(arrDistances)
                                    }, {
                                        where: {
                                            id: lastTrip.id
                                        }
                                    });
                                }
                                else {
                                    arrDistances = JSON.parse(lastTrip.nextStops);
                                }
                            }
                            // -----> distance calculator end
                        } else {
                            console.log(`--> has current station: ${bus['currentStation']}`);
                            /* filterStops.forEach(element => {
                                //TODO: incorrect distance calculation
                                const disBetweenBusAndStop = geolib.getDistance(
                                    element,
                                    bus.location
                                );

                                distances.push({
                                    ...element,
                                    d: disBetweenBusAndStop
                                });
                            }); */

                            // -----> distance calculator start
                            let arrDistances = [];
                            let lastTrip = await TripsData.findOne({
                                where: {
                                    DeviceId: index,
                                    isCompleted: 0
                                },
                                order: [['id', 'DESC']],
                                raw: true
                            });

                            if (lastTrip) {
                                if (lastTrip.nextStops == null) {
                                    for (let past of pastList) {
                                        if (arrDistances.length < 2) {
                                            let distanceFromBusToStop = await distanceHelper.distanceBetweenTwoPoints(bus.latitude, bus.longitude, filterStops[past - 1].latitude, filterStops[past - 1].longitude, "M");
                                            arrDistances.push({
                                                ...filterStops[past - 1],
                                                isStopPassed: 0,
                                                originalDistance: distanceFromBusToStop,
                                                tempDistance: 0
                                            });
                                        }
                                    }
                                    await TripsData.update({
                                        nextStops: JSON.stringify(arrDistances)
                                    }, {
                                        where: {
                                            id: lastTrip.id
                                        }
                                    });
                                }
                                else {
                                    console.log(`Next stops lat lng available`);
                                    let checkpoint = JSON.parse(lastTrip.checkpoint); // it needs to be updated periodically
                                    let nextStops = JSON.parse(lastTrip.nextStops);
                                    console.log(`NextStop: ${nextStops.length}`);
                                    console.log(`PastList: ${pastList}`);
                                    console.log('---> Distances -----\n');
                                    let pastIndex = 0;
                                    for (let past of pastList) {
                                        if (past != 1 && past <= filterStops.length) {
                                            if (past == pastList[0] || past == pastList[1]) {
                                                if (nextStops[pastIndex].isStopPassed != 1) {
                                                    console.log(`\nSequence: ${past}`);
                                                    let distanceFromBusToStop = await distanceHelper.distanceBetweenTwoPoints(bus.latitude, bus.longitude, filterStops[past - 1].latitude, filterStops[past - 1].longitude, "M");
                                                    let distanceFromCheckpointToBus = await distanceHelper.distanceBetweenTwoPoints(checkpoint[0], checkpoint[1], bus.latitude, bus.longitude, "M");
                                                    let distanceFromCheckpointToStop = nextStops[pastIndex].originalDistance;
                                                    console.log(`BusToStop: ${distanceFromBusToStop}`);
                                                    console.log(`BoxToBus: ${distanceFromCheckpointToBus}`);
                                                    console.log(`BoxToStop: ${distanceFromCheckpointToStop}`);
                                                    if (distanceFromBusToStop <= distanceFromCheckpointToStop && distanceFromCheckpointToBus <= distanceFromCheckpointToStop) {
                                                        // it means bus hasn't reached the STOP yet
                                                        nextStops[pastIndex].tempDistance = distanceFromBusToStop;
                                                    }
                                                    else {
                                                        console.log(`${past} has marked as isStopPassed`);
                                                        // it tells bus has passed the STOP                                                
                                                        nextStops[pastIndex].isStopPassed = 1; //isStopPassed
                                                        nextStops[pastIndex].tempDistance = 0;
                                                    }
                                                }
                                            }
                                        }
                                        pastIndex++;
                                    }

                                    //if one of stop has passed then remove the first stop from the sequence
                                    let isRemovedFromNextStops = 0;
                                    let nextStopIndex = 0;
                                    for (let nextStop of nextStops) {
                                        if (nextStop.isStopPassed == 1 && nextStopIndex != 0) {
                                            console.log(`Removing stop ${nextStops[0].StopNumber}`);
                                            nextStops.shift();
                                            isRemovedFromNextStops = 1;
                                            // break;
                                        }
                                        nextStopIndex++;
                                    }

                                    //if the pastList (sequences) are not 3 in length, add the next one.
                                    //Also update "checkpoint" in trip table
                                    if (nextStops.length < 2 && pastList.length != 1) {
                                        //update pastList
                                        // pastList = [];
                                        let tempPastList = [];
                                        for (let p of pastList) {
                                            if ((p + 1) <= filterStops.length) {
                                                tempPastList.push(p + 1);
                                            }
                                        }
                                        // pastList = [pastList[0] + 1, pastList[1] + 1, pastList[2] + 1];
                                        pastList = tempPastList;
                                        //update new checkpoint when pastList gets updated
                                        checkpoint = JSON.parse(`[${filterStops[pastList[0] - 1].latitude}, ${filterStops[pastList[0] - 1].longitude}]`);
                                        console.log(`--- updated pastList: ${pastList}`);
                                        //add next Stop
                                        if (pastList.length >= 2) {
                                            let distanceFromCheckpointToStop = await distanceHelper.distanceBetweenTwoPoints(checkpoint[0], checkpoint[1], filterStops[pastList[1] - 1].latitude, filterStops[pastList[1] - 1].longitude, "M");
                                            console.log(`--- Entering new stop ${filterStops[pastList[1] - 1].StopNumber} => ${distanceFromCheckpointToStop}`);
                                            nextStops.push({
                                                ...filterStops[pastList[1] - 1],
                                                isStopPassed: 0,
                                                originalDistance: distanceFromCheckpointToStop,
                                                tempDistance: 0
                                            });
                                        }

                                        //update original distance of other stops with the new checkpoint
                                        for (let s of nextStops) {
                                            let distanceFromCheckpointToStop = await distanceHelper.distanceBetweenTwoPoints(checkpoint[0], checkpoint[1], s.latitude, s.longitude, "M");
                                            s.originalDistance = distanceFromCheckpointToStop;
                                        }
                                    }
                                    //update trip with new future STOPS
                                    await TripsData.update({
                                        nextStops: JSON.stringify(nextStops),
                                        checkpoint: isRemovedFromNextStops == 1 ? `[${filterStops[pastList[0] - 1].latitude}, ${filterStops[pastList[0] - 1].longitude}]` : JSON.stringify(checkpoint)
                                    }, { where: { id: lastTrip.id } });
                                }
                            }
                            // -----> distance calculator end

                            //removing stops those were past
                            // distances = distances.filter((f) => f.sequence >= pastList[0] || f.sequence >= (pastList[0] - 1));
                            // filterStops = filterStops.filter((f) => f.sequence >= pastList[0] || f.sequence >= (pastList[0] - 1));
                            // console.log(filterStops);
                            // console.log(pastList);
                            // filterStops = filterStops.filter((f) => f.sequence >= (pastList[0] + 1));
                            //TODO: incorrect sorting sue to incorrect distance between STOPS
                            /* distances.sort(function (a, b) {
                                if (a.d < b.d) return -1;
                                if (a.d > b.d) return 1;
                                return 0;
                            }); */

                            // let NearestSequenceIndex = 0;

                            /* if (distances[NearestSequenceIndex] && distances[NearestSequenceIndex + 1]) {
                                if (distances[NearestSequenceIndex + 1].d > distances[NearestSequenceIndex].d && (distances[NearestSequenceIndex + 1].sequence < distances[NearestSequenceIndex].sequence)) {
                                    NearestSequenceIndex = 1;
                                }
                            } */

                            // while (!(distances[NearestSequenceIndex] <= pastList[0] || distances[NearestSequenceIndex] <= pastList[1])) {
                            //     NearestSequenceIndex = NearestSequenceIndex + 1;

                            //     if (!distances[NearestSequenceIndex]) {
                            //         break;
                            //     }
                            // }

                            // let NearestS = distances[NearestSequenceIndex];
                            // let NearestS = filterStops[NearestSequenceIndex];
                            // let SNearestS = distances[NearestSequenceIndex + 1];
                            // let SNearestS = filterStops[NearestSequenceIndex + 1];
                            /* if (NearestS || SNearestS) {
                                if (pastList.includes(NearestS.sequence)) {
                                    // nearest
                                    nearest = NearestS
                                } else if (pastList.includes(SNearestS.sequence)) {
                                    // second nearest
                                    nearest = SNearestS
                                } else {
                                    nearest = NearestS
                                }
                                pastList = [
                                    nearest.sequence,
                                    nearest.sequence + 1,
                                    nearest.sequence + 2,
                                ]
                            } */
                            nearest = filterStops[pastList[0] - 1];
                            console.log(`-----> Current station: ${nearest.StopNumber}`);
                        }
                    }

                    insertRecords.push({
                        deviceId: index,
                        totalCountables: reset ? '{}' : JSON.stringify(bus.countables),
                        currentRouteDetermined: maxName,
                        isBusInStation: inBoundary,
                        updatedAt: new Date(),
                        pastList: JSON.stringify(pastList),
                        isRouteReset,
                        currentStation: nearest && nearest.StopNumber ? nearest.StopNumber : null
                    });

                }
                else {
                    //assign bus stops to variable filterStops
                    filterStops = bus.stops;

                    //separating  coordinates from stops
                    onlyStopCoords = filterStops.map(rec => {
                        return {
                            latitude: rec.latitude,
                            longitude: rec.longitude,
                        }
                    });

                    //getting nearest stop
                    let shortestStop = geolib.findNearest({ latitude: (bus.latitude), longitude: (bus.longitude) }, onlyStopCoords);

                    //getting current route/stop
                    let getCurrentRoute = filterStops.find((x) => x.longitude == shortestStop.longitude && x.latitude == shortestStop.latitude);

                    //filter stops with current route
                    if (getCurrentRoute) {
                        maxName = getCurrentRoute.StopName;
                        filterStops = filterStops.filter((x) => x.StopName == getCurrentRoute.StopName);
                    }

                    //get boundary points with respect to current route
                    let boundaryPoints = Boundary.find(rec => {
                        if (rec.associatedRoutes.includes(maxName)) {
                            return true
                        }
                    });

                    //check if bus is inside bus stand using geolib library
                    const inBoundary = geolib.isPointInPolygon({
                        latitude: bus.latitude,
                        longitude: bus.longitude
                    }, boundaryPoints.stationBoundary) ? 1 : 0;

                    let isPointInLine = false;

                    //check if all the points are on same line
                    filterStops.forEach((stop, index) => {
                        //if next stop available
                        if (filterStops[index + 1]) {
                            let inLine = geolib.isPointInLine(
                                {
                                    latitude: bus.latitude,
                                    longitude: bus.longitude
                                },
                                {
                                    latitude: filterStops[index].latitude,
                                    longitude: filterStops[index].longitude
                                },
                                {
                                    latitude: filterStops[index + 1].latitude,
                                    longitude: filterStops[index + 1].longitude
                                }
                            ) ? true : false;

                            if (isPointInLine != true) {
                                isPointInLine = inLine;
                            }
                        }
                    });

                    // find nearest STOP here
                    let nearest;
                    completedTrips[bus.deviceName] = 0;
                    // if bus is inside the bus stand
                    if (inBoundary == 1) {
                        pastList = [2, 3, 4];
                        isRouteReset = 1;
                    }
                    else {
                        completedTrips[bus.deviceName] = bus.isRouteReset == 1 ? 1 : 0;
                        isRouteReset = 0;
                        // let distances = [];
                        //sorting stops according to sequence
                        filterStops.sort((a, b) => a.sequence - b.sequence);

                        if (bus['currentStation'] == null) {
                            //if current station is NULL then nearest stop is first index of filterStops
                            // nearest = filterStops[0];
                            pastList = [2, 3, 4];
                            // pastList = [
                            //     nearest.sequence,
                            //     nearest.sequence + 1,
                            //     nearest.sequence + 2,
                            // ];
                        } else {
                            /* filterStops.forEach(element => {
                                //TODO: incorrect distance calculation
                                const disBetweenBusAndStop = geolib.getDistance(
                                    element,
                                    bus.location
                                );

                                distances.push({
                                    ...element,
                                    d: disBetweenBusAndStop
                                });
                            }); */

                            //removing stops those were past
                            // distances = distances.filter((f) => f.sequence >= pastList[0] || f.sequence >= (pastList[0] - 1));
                            // filterStops = filterStops.filter((f) => f.sequence >= pastList[0] || f.sequence >= (pastList[0] - 1));
                            //TODO: incorrect sorting sue to incorrect distance between STOPS
                            /* distances.sort(function (a, b) {
                                if (a.d < b.d) return -1;
                                if (a.d > b.d) return 1;
                                return 0;
                            }); */

                            let NearestSequenceIndex = 0;

                            /* if (distances[NearestSequenceIndex] && distances[NearestSequenceIndex + 1]) {
                                if (distances[NearestSequenceIndex + 1].d > distances[NearestSequenceIndex].d && (distances[NearestSequenceIndex + 1].sequence < distances[NearestSequenceIndex].sequence)) {
                                    NearestSequenceIndex = 1;
                                }
                            } */

                            // while (!(distances[NearestSequenceIndex] <= pastList[0] || distances[NearestSequenceIndex] <= pastList[1])) {
                            //     NearestSequenceIndex = NearestSequenceIndex + 1;

                            //     if (!distances[NearestSequenceIndex]) {
                            //         break;
                            //     }
                            // }

                            // let NearestS = distances[NearestSequenceIndex];
                            let NearestS = filterStops[NearestSequenceIndex];
                            // let SNearestS = distances[NearestSequenceIndex + 1];
                            let SNearestS = filterStops[NearestSequenceIndex + 1];
                            if (NearestS || SNearestS) {
                                if (pastList.includes(NearestS.sequence)) {
                                    // nearest
                                    nearest = NearestS
                                } else if (pastList.includes(SNearestS.sequence)) {
                                    // second nearest
                                    nearest = SNearestS
                                } else {
                                    nearest = NearestS
                                }
                                /* pastList = [
                                    nearest.sequence,
                                    nearest.sequence + 1,
                                    nearest.sequence + 2,
                                ] */
                                pastList = [2, 3, 4];
                            }
                            nearest = null;
                        }
                    }

                    insertRecords.push({
                        deviceId: index,
                        totalCountables: reset ? '{}' : JSON.stringify(bus.countables),
                        currentRouteDetermined: maxName,
                        isBusInStation: inBoundary,
                        updatedAt: new Date(),
                        pastList: JSON.stringify(pastList),
                        isRouteReset,
                        currentStation: nearest && nearest.StopNumber ? nearest.StopNumber : null
                    });
                }


            }

            //updating completed trips table
            if (isEntryCompleted) {
                const arr = ['id', 'date', 'createdAt', 'updatedAt'];
                for (const property in completedRecord[0]) {
                    if (!arr.includes(property) && typeof (completedTrips[property] != 'undefined')) {
                        completedTrips[property] += Number(completedRecord[0][property])
                    }
                }
                let id = completedRecord[0].id
                CompletedTripsModel.update(completedTrips, {
                    where: {
                        id: id
                    }
                }).then(res => {
                    console.log('updated')
                }).catch(err => {
                    throw new Error(err.message)
                })
            }
            //inserting new record in completed trips table
            else {
                await CompletedTripsModel.create(
                    completedTrips
                ).then(res => {
                    console.log('inserted')
                }).catch(err => {
                    throw new Error(err.message)
                })
            }

            //updating/inserting data into routeDetermination table 
            await routeDeterminationModel.bulkCreate(insertRecords, {
                updateOnDuplicate: ['totalCountables', 'currentRouteDetermined', 'updatedAt', 'isBusInStation', 'pastList', 'isRouteReset', 'currentStation']
            }).then(function () {
                callback(null, {
                    statusCode: 200,
                    error: null,
                    msg: "Records inserted successfully"
                });
            }).catch(function (err) {
                console.log(err);
                callback(null, {
                    statusCode: 404,
                    error: 1,
                    msg: "Error Occured"
                });
            });
        });



    } catch (err) {
        callback(err, "Err");
    }
};