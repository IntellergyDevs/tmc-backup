const moment = require('moment');
const momenttimezone = require('moment-timezone');
var config = require('../../config/config.json');
const GeotabApi = require('mg-api-js');
const authentication = {
    credentials: {
        database: config.geotab.database,
        userName: config.geotab.email,
        password: config.geotab.password,
    }
}
const api = new GeotabApi(authentication);
moment.tz.setDefault(config.timeZone.africaCairo);

module.exports.insertLogRecords = async (event, context, callback) => {
    try {
        var typeName = 'LogRecord';
        let limit = 50000;
        const logModel = require('../../models/LogRecord.model');

        const Device = require('../../models/Device.model');
        const lastRecord = await logModel.findOne({
            attributes: ['id', 'DateTime'],
            order: [['id', 'DESC']],
            raw: true
        });
        if (lastRecord !== null && lastRecord.DateTime !== null) {
            var lastDate = moment(new Date(lastRecord.DateTime)).utc().format(config.dateFormat.UtcIsoString);
        }
        var devices = await Device.findAll({
            attributes: ['id', 'DeviceName'],
            raw: true
        })
        var all_devices = [];
        await devices.forEach(function (device, index) {
            all_devices[device.id] = device.DeviceName
        })
        try {
            console.log("before API call try block", lastDate);
            await api.call('Get', {
                typeName: typeName,
                resultsLimit: limit,
                search: {
                    "fromDate": typeof (lastDate) != 'undefined' ? lastDate : "2019-12-16T16:34:33.063Z",
                }
            }).then(async function (records) {
                console.log('then b for records', records.length);
                records = records.map(function (record) {
                    let nrecord = {};
                    nrecord['_id'] = record.id;
                    nrecord['DateTime'] = moment(record.dateTime).format(config.dateFormat.powerBi);
                    nrecord['DeviceName'] = typeof (all_devices[record.device.id]) != 'undefined' ? all_devices[record.device.id] : '';
                    nrecord['DeviceId'] = record.device.id;
                    nrecord['Latitude'] = record.latitude;
                    nrecord['Longitude'] = record.longitude;
                    nrecord['Speed'] = record.speed;
                    nrecord['createdAt'] = new Date();
                    return nrecord;
                });
                var filtered = records.filter(function (el) {
                    return el != null;
                });

                await logModel.bulkCreate(
                    filtered, {
                    ignoreDuplicates: true
                }).then(function () {
                    console.log('then b sequelize');
                    callback(null, {
                        statusCode: 200,
                        error: null,
                        msg: "Records inserted successfully"
                    });
                }).catch(function (err) {
                    console.log('insert error',err.message);
                    callback(null, {
                        statusCode: 404,
                        error: 1,
                        msg: "Error Occured"
                    });
                });
            }).catch(error => {
                console.log('error occured',error);
            });

        } catch (errrr) {
            console.log('catch try error',errrr);
        }
        console.log('request end');
    } catch (errorr) {
        console.log('last catch',errorr);
    }

};