const moment = require('moment');
const momenttimezone = require('moment-timezone');
var config = require('../../config/config.json');
const GeotabApi = require('mg-api-js');
const authentication = {
    credentials: {
        database: config.geotab.database,
        userName: config.geotab.email,
        password: config.geotab.password,
    }
}
const api = new GeotabApi(authentication);

moment.tz.setDefault(config.timeZone.africaCairo);

module.exports.insertFuelData = async (event, context, callback) => {
    var typeName = 'StatusData';
    let limit = 50000;
    const fuelUsageModel = require('../../models/FuelUsage.model');
    const Device = require('../../models/Device.model');
    const lastRecord = await fuelUsageModel.findOne({
        attributes: ['id', 'DateTime'],
        order: [['id', 'DESC']],
        raw: true
    });


    if (lastRecord !== null && lastRecord.DateTime !== null) {
        var lastDate = moment(new Date(lastRecord.DateTime)).utc().format(config.dateFormat.UtcIsoString);
    }
    var devices = await Device.findAll({
        attributes: ['id', 'DeviceName'],
        raw: true
    })
    var all_devices = [];
    await devices.forEach(function (device, index) {
        all_devices[device.id] = device.DeviceName
    })

    let fromDate = new Date("2019-01-01");
    let toDate = new Date();
    console.log('last > ', lastDate)
    try {
        console.log("before API call try block");
        await api.call('Get', {
            typeName: typeName,
            resultsLimit: limit,
            search: {
                "fromDate": typeof (lastDate) != 'undefined' ? lastDate : "2019-07-03T16:34:33.063Z",
                diagnosticSearch: {
                    id: "DiagnosticDeviceTotalFuelId"
                },
            }
        }).then(async function (records) {
            console.log('then b for records');
            console.log('total', records.length)

            // var distance = {};
            var date_time = {};

            Object.keys(all_devices).forEach(function (key) {
                // distance[key] = typeof (max_records['b1']) !== "undefined" ? max_records['b1'] : 0;
                date_time[key] = '';
            })

            records = records.map(function (record) {
                let nrecord = {};
                nrecord['_id'] = record.id;
                nrecord['DateTime'] = moment(record.dateTime).format(config.dateFormat.powerBi);;
                nrecord['DeviceName'] = typeof (all_devices[record.device.id]) != 'undefined' ? all_devices[record.device.id] : '';
                nrecord['DeviceId'] = record.device.id;
                nrecord['DiagnosticId'] = record.diagnostic.id;
                nrecord['DiagnosticName'] = "Total fuel used (since telematics device install)";//record.diagnostic.id;
                nrecord['Data'] = record.data;
                nrecord['createdAt'] = new Date();

                if (date_time[record.device.id] != '') {
                    let diffMins = moment(new Date(nrecord['DateTime'])).diff(moment(new Date(date_time[record.device.id])), 'minutes');
                    if (diffMins > 20) {
                        date_time[record.device.id] = nrecord['DateTime'];
                        return nrecord;
                    }
                } else {
                    date_time[record.device.id] = nrecord['DateTime'];
                    return nrecord;
                }
            });

            var filtered = records.filter(function (el) {
                return el != null;
            });
            console.log('filtered', filtered.length)
            await fuelUsageModel.bulkCreate(
                filtered, {
                ignoreDuplicates: true
            }).then(function () {
                console.log('then b sequelize');
                callback(null, {
                    statusCode: 200,
                    error: null,
                    msg: "Records inserted successfully"
                });
            }).catch(function (err) {
                console.log(err);
                callback(null, {
                    statusCode: 404,
                    error: 1,
                    msg: "Error Occured"
                });
            });

        }).catch(error => {
            console.log(error);
        });
        console.log('request end');
    } catch (errrr) {
        console.log(errrr);
    }
};