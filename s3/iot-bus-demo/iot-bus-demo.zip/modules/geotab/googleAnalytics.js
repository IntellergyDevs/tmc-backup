const moment = require('moment');
const momenttimezone = require('moment-timezone');
var config = require('../../config/config.json');
const propertyId = '271383377';
const root = process.cwd()
console.log(require('path').resolve('./'))
const keyFilename = root + "/config/root-project-eagle.json";

const { BetaAnalyticsDataClient } = require('@google-analytics/data');
const analyticsDataClient = new BetaAnalyticsDataClient({
    keyFilename
})

module.exports.runReport = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    const firebaseStatisticsModel = require('../../models/firebaseStatistics.model');
    // const firebaseUserStartLocationModel = require('../../models/firebaseUserStartLocation.model');
    const db = require('../../config/db.sequelize');


    moment.tz.setDefault(config.timeZone.africaCairo);

    // console.log('utc time', moment().utc().format('YYYY-MM-DD HH:mm:ss'))
    const today = moment().utc().format('YYYY-MM-DD')
    const date1DayAgo = moment().utc().subtract(1, 'days').format('YYYY-MM-DD')
    const date2DaysAgo = moment().utc().subtract(2, 'days').format('YYYY-MM-DD')
    const date30DaysAgo = moment().utc().subtract(30, 'days').format('YYYY-MM-DD')
    let objToSave = {
        dailyActiveUsers: 0,
        monthlyActiveUsers: 0
    }
    console.log('today >', today)
    console.log('1 day ago >', date1DayAgo)
    console.log('2 days ago >', date2DaysAgo)
    console.log('30 days ago >', date30DaysAgo)

    let queryForServiceSplit = `SELECT COUNT(id) AS trips, SUM(noOfWalks) AS walks,SUM(noOfBuses) AS bus,SUM(noOfTrains) AS train FROM firebase_passengerStartLocations WHERE createdAt > '${today} 00-00-00' AND createdAt <= '${today} 23:59:59'`;
    var [serviceSplits, meta] = await db.query(queryForServiceSplit, {});
    serviceSplits = serviceSplits && serviceSplits[0] ? serviceSplits[0] : [];
    let appUsageQuery = `SELECT ( createdAt ) AS date, HOUR ( createdAt ) AS Hour, count(*) AS Count FROM firebase_passengerStartLocations WHERE createdAt > '${today} 00-00-00' AND createdAt <= '${today} 23:59:59' GROUP BY DAY ( createdAt ), HOUR (createdAt)ORDER BY Count DESC Limit 1`;
    var [appUsage, meta] = await db.query(appUsageQuery, {});
    appUsage = appUsage && appUsage[0] ? appUsage[0] : [];

    const utcHour = appUsage.Hour ? Number(appUsage.Hour) : null
    const hour = utcHour != null ? moment(utcHour, 'H').utcOffset("+04:00").format('HH') : 0

    objToSave['highestAppUsagePeriodFrom'] = utcHour != null ? Number(hour) : 0
    objToSave['highestAppUsagePeriodTo'] = utcHour != null ? Number(hour) + 1 : 0

    const walkSplits = serviceSplits['walks'] ? Number(serviceSplits['walks']) : 0
    const trainSplits = serviceSplits['train'] ? Number(serviceSplits['train']) : 0
    const busSplits = serviceSplits['bus'] ? Number(serviceSplits['bus']) : 0

    const totalSplits = walkSplits + trainSplits + busSplits
    objToSave['gauTripServiceSplitWalk'] = serviceSplits['walks'] ? Number((walkSplits / totalSplits).toFixed(2)) : 0
    objToSave['gauTripServiceSplitBus'] = serviceSplits['bus'] ? Number((busSplits / totalSplits).toFixed(2)) : 0
    objToSave['gauTripServiceSplitTrain'] = serviceSplits['train'] ? Number((trainSplits / totalSplits).toFixed(2)) : 0
    objToSave['tripsPlanned'] = serviceSplits['trips'] ? Number(serviceSplits['trips']) : 0

    

    const [stats] = await analyticsDataClient.runReport({
        property: `properties/${propertyId}`,
        dateRanges: [
            {
                startDate: date1DayAgo,
                endDate: 'today',
            },
        ],
        dimensions: [],
        metrics: [
            {
                name: 'sessionsPerUser',
            },
            {
                name: 'userEngagementDuration',
            },
        ],
        // limit:'10'
    });
    const [events] = await analyticsDataClient.runReport({
        property: `properties/${propertyId}`,
        dateRanges: [
            {
                startDate: date1DayAgo,
                endDate: 'today',
            },
        ],
        dimensions: [
            {
                name: 'eventName',
            },
        ],
        metrics: [
            {
                name: 'eventCount',
            },
        ],
        // limit:'10'
    });
    // const incl = ['app_exception', 'app_remove']
    events.rows.forEach(element => {
        if (element.dimensionValues[0].value == 'app_remove') {
            objToSave['totalUninstalls'] = element && element.metricValues && element.metricValues[0] ? Number(element.metricValues[0].value) : 0
        }
        if (element.dimensionValues[0].value == 'app_exception') {
            objToSave['totalErrors'] = element && element.metricValues && element.metricValues[0] ? Number(element.metricValues[0].value) : 0
        }

        if (element.dimensionValues[0].value == 'first_open') { // downloads temporary
            objToSave['downloads'] = element && element.metricValues && element.metricValues[0] ? Number(element.metricValues[0].value) : 0
        }
    });

    const [cohort] = await analyticsDataClient.runReport({
        property: `properties/${propertyId}`,
        "dimensions": [{ "name": "cohort" }, { "name": "cohortNthDay" }],
        "metrics": [{ "name": "cohortActiveUsers" }, { "name": "cohortTotalUsers" }],
        "cohortSpec": {
            "cohorts": [
                {
                    "dimension": "firstSessionDate",
                    "dateRange": { "startDate": date2DaysAgo, "endDate": today }
                },
                {
                    "dimension": "firstSessionDate",
                    "dateRange": { "startDate": date30DaysAgo, "endDate": today }
                }
            ],
            "cohortsRange": {
                "endOffset": 5,
                "granularity": "DAILY"
            }
        },
    });
    const [factor] = await analyticsDataClient.runReport({
        property: `properties/${propertyId}`,
        dateRanges: [
            {
                startDate: date30DaysAgo,
                endDate: 'today',
            }
        ],
        dimensions: [],
        metrics: [
            {
                name: 'active28DayUsers',
            },
            {
                name: 'activeUsers',
            },
        ],
        // limit:'10'
    });
    objToSave['dailySessionsPerUser'] = Number(Number(stats.rows[0].metricValues[0].value).toFixed(2))
    objToSave['platform'] = 'Android'
    objToSave['createdAt'] = moment().utc().format('YYYY-MM-DD HH:mm:ss')
    objToSave['sessionUsageInMinutes'] = Number(((stats.rows[0].metricValues[1].value) / 60).toFixed(2))

    cohort.rows.forEach(row => {
        if (row.dimensionValues[0].value == 'cohort_0') {
            objToSave['dailyActiveUsers'] += row.metricValues && row.metricValues[0] && row.metricValues[0].value ? Number(row.metricValues[0].value) : 0
        }
        if (row.dimensionValues[0].value == 'cohort_1') {
            objToSave['monthlyActiveUsers'] += row.metricValues && row.metricValues[0] && row.metricValues[0].value ? Number(row.metricValues[0].value) : 0
        }
    });

    const totalUsers = factor.rows && factor.rows[0] && factor.rows[0]['metricValues'] && factor.rows[0]['metricValues'][0] ? factor.rows[0]['metricValues'][0].value : 0
    const activeUsers = factor.rows && factor.rows[0] && factor.rows[0]['metricValues'] && factor.rows[0]['metricValues'][1] ? factor.rows[0]['metricValues'][1].value : 0
    // console.log(totalUsers, activeUsers)

    objToSave['retentionRate'] = Number((Number(activeUsers) / Number(totalUsers)).toFixed(2))
    objToSave['ChurnRate'] = Number((1 - objToSave['retentionRate']).toFixed(2))
    console.log(objToSave)

    await firebaseStatisticsModel.create(objToSave, {
        // updateOnDuplicate: ['EventName', 'Count', 'updatedAt']
    }).then(function () {
        console.log('then b sequelize');
        callback(null, {
            statusCode: 200,
            error: null,
            msg: "Records inserted successfully"
        });
    }).catch(function (err) {
        console.log(err);
        callback(null, {
            statusCode: 404,
            error: 1,
            msg: "Error Occured"
        });
    });
}

module.exports.insertFirebaseEvents = async (event, context, callback) => {
    try {
        moment.tz.setDefault(config.timeZone.africaCairo);

        context.callbackWaitsForEmptyEventLoop = false;
        console.log('propertyId ', propertyId)
        const date = moment().utc().subtract(1, 'days').format('YYYY-MM-DD')
        console.log('utc date', date)
        const firebaseEventsModel = require('../../models/firebaseEvents.model');

        const [events] = await analyticsDataClient.runReport({
            property: `properties/${propertyId}`,
            dateRanges: [
                {
                    startDate: '2021-01-01',
                    endDate: 'today',
                },
            ],
            dimensions: [
                {
                    name: 'eventName',
                },
            ],
            metrics: [
                {
                    name: 'eventCount',
                },
            ],
            // limit:'10'
        });
        console.log('Report result:');
        // console.log((events.rows))

        let records = events.rows.map((event, index) => {
            // console.log(event)
            return {
                EventName: event.dimensionValues[0].value,
                Count: Number(event.metricValues[0].value)
            }
        })

        await firebaseEventsModel.bulkCreate(records, {
            updateOnDuplicate: ['EventName', 'Count', 'updatedAt']
        }).then(function () {
            console.log('then b sequelize');
            callback(null, {
                statusCode: 200,
                error: null,
                msg: "Records inserted successfully"
            });
        }).catch(function (err) {
            console.log(err);
            callback(null, {
                statusCode: 404,
                error: 1,
                msg: "Error Occured"
            });
        });
    } catch (error) {
        console.log(error);
        callback(null, {
            statusCode: 404,
            error: 1,
            msg: "Error Occured"
        });
    }
}