const moment = require('moment');
const momenttimezone = require('moment-timezone');
var config = require('../../config/config.json');
const GeotabApi = require('mg-api-js');
const authentication = {
    credentials: {
        database: config.geotab.database,
        userName: config.geotab.email,
        password: config.geotab.password,
    }
}
const api = new GeotabApi(authentication);

const sequelize = require('sequelize');
moment.tz.setDefault(config.timeZone.africaCairo);


module.exports.insertOdometerData = async (event, context, callback) => {
    var typeName = 'StatusData';
    let limit = 50000;
    const odometerDataModel = require('../../models/OdometerData.model');
    const Device = require('../../models/Device.model');

    var devices = await Device.findAll({
        attributes: ['id', 'DeviceName'],
        raw: true
    })
    var all_devices = [];
    await devices.forEach(function (device, index) {
        all_devices[device.id] = device.DeviceName
    })

    const lastRecord = await odometerDataModel.findOne({
        attributes: ['id', 'DateTime', 'Data'],
        order: [['id', 'DESC']],
        raw: true
    });

    const lastRecordsData = await odometerDataModel.findAll({
        attributes: ['DeviceId', [sequelize.fn('max', sequelize.col('Data')), 'DataMax']],
        order: [['id', 'DESC']],
        group: ['odometerdataset.DeviceId'],
        raw: true
    });
    var max_records = [];
    await lastRecordsData.forEach(function (device, index) {
        max_records[device.DeviceId] = device.DataMax
    })
    if (lastRecord !== null && lastRecord.DateTime !== null) {
        var lastDate = moment(new Date(lastRecord.DateTime)).utc().format(config.dateFormat.UtcIsoString);
    }
    console.log('last', lastDate)
    try {
        console.log("before API call try block");
        await api.call('Get', {
            typeName: typeName,
            resultsLimit: limit,
            search: {
                "fromDate": typeof (lastDate) != 'undefined' ? lastDate : "2019-07-03T16:34:33.063Z",
                diagnosticSearch: {
                    id: "DiagnosticOdometerId"
                },
            }
        }).then(async function (records) {
            console.log('then b for records');
            records.sort(function (a, b) {
                return a.dateTime.localeCompare(b.dateTime);
            });
            var distance = {};
            var date_time = {};

            Object.keys(all_devices).forEach(function (key) {
                distance[key] = typeof (max_records['b1']) !== "undefined" ? max_records['b1'] : 0;
                date_time[key] = '';
            })
            console.log(records.length);
            records = records.map(function (record) {
                let nrecord = {};
                nrecord['_id'] = record.id;
                nrecord['DateTime'] = moment(record.dateTime).format(config.dateFormat.powerBi);
                nrecord['DeviceName'] = typeof (all_devices[record.device.id]) != 'undefined' ? all_devices[record.device.id] : '';
                nrecord['DeviceId'] = record.device.id;
                nrecord['DiagnosticId'] = record.diagnostic.id;
                nrecord['DiagnosticName'] = "Odometer";
                nrecord['Data'] = record.data;
                nrecord['DistanceCovered'] = distance[record.device.id] == 0 ? 0 : (record.data - distance[record.device.id]) / 1000;//record.data; // For distance in Km
                nrecord['createdAt'] = new Date();

                if (date_time[record.device.id] != '') {
                    let diffMins = moment(new Date(nrecord['DateTime'])).diff(moment(new Date(date_time[record.device.id])), 'minutes');
                    if (diffMins > 10) {
                        distance[record.device.id] = record.data;
                        date_time[record.device.id] = nrecord['DateTime'];
                        return nrecord;
                    }
                } else {
                    date_time[record.device.id] = nrecord['DateTime'];
                    return nrecord;
                }
            });
            var filtered = records.filter(function (el) {
                return el != null;
            });
console.log('filter', filtered.length)
            
            await odometerDataModel.bulkCreate(
                filtered, {
                ignoreDuplicates: true
            }).then(function () {
                console.log('then b sequelize');
                callback(null, {
                    statusCode: 200,
                    error: null,
                    msg: "Records inserted successfully"
                });
            }).catch(function (err) {
                console.log(err);
                callback(null, {
                    statusCode: 404,
                    error: 1,
                    msg: "Error Occured"
                });
            });
        }).catch(error => {
            console.log(error);
        });

    } catch (errrr) {
        console.log(errrr);
    }
    console.log('request end');
};