const moment = require('moment');
const momenttimezone = require('moment-timezone');
var config = require('../../config/config.json');
const GeotabApi = require('mg-api-js');
const authentication = {
    credentials: {
        database: config.geotab.database,
        userName: config.geotab.email,
        password: config.geotab.password,
    }
}
const api = new GeotabApi(authentication);

moment.tz.setDefault(config.timeZone.africaCairo);

module.exports.insertExceptionEvent = async (event, context, callback) => {
    var typeName = 'ExceptionEvent';
    let limit = 50000;
    const exceptionModel = require('../../models/ExceptionEvent.model');
    const RulesModel = require('../../models/Rules.model');
    const Device = require('../../models/Device.model');

    const lastRecord = await exceptionModel.findOne({
        attributes: ['id', 'ActiveFrom'],
        order: [['ActiveFrom', 'DESC']],
        raw: true
    });
    if (lastRecord !== null && lastRecord.ActiveFrom !== null) {
        var onlyDate = moment(new Date(lastRecord.ActiveFrom)).format("YYYY-MM-DD");
        var lastDate = moment(new Date(onlyDate)).utc().format(config.dateFormat.UtcIsoString);
        console.log(onlyDate);
        console.log(lastDate);
    }
    
    var devices = await Device.findAll({
        attributes: ['id', 'DeviceName'],
        raw: true
    })
    var all_devices = [];
    await devices.forEach(function (device, index) {
        all_devices[device.id] = device.DeviceName
    })
    var all_rules = await RulesModel.findAll({
        attributes: ['_id', 'Name'],
        where: {
            isActiveRule: 1
        },
        raw: true
    }).then(async function (ruless) {
        let rules = [];
        ruless.forEach(function (rule, index) {
            rules[rule._id] = rule.Name
        })
        try {
            console.log("before API call try block");
            await api.call('Get', {
                typeName: typeName,
                resultsLimit: limit,
                search: {
                    "fromDate": typeof (lastDate) != 'undefined' ? lastDate : "2019-07-03T16:34:33.063Z",
                }
            }).then(async function (records) {
                console.log("from api", records.length);
                console.log('then b for records');
                records = records.map(function (record) {
                    let nrecord = {};
                    nrecord['_id'] = record['id'];
                    nrecord['DeviceName'] = typeof (all_devices[record['device']['id']]) != 'undefined' ? all_devices[record['device']['id']] : '';
                    nrecord['DeviceId'] = record['device']['id'];
                    nrecord['ActiveFrom'] = moment(record['activeFrom']).format(config.dateFormat.powerBi);
                    nrecord['ActiveTo'] = moment(record['activeTo']).format(config.dateFormat.powerBi);
                    nrecord['RuleId'] = record['rule']['id'];
                    nrecord['RuleName'] = typeof (rules[record['rule']['id']]) != 'undefined' ? rules[record['rule']['id']] : '';
                    nrecord['Distance'] = record['distance'];
                    nrecord['Duration'] = moment.duration(record['duration']).asMinutes();
                    nrecord['createdAt'] = new Date();
                    if (typeof (rules[record['rule']['id']]) != 'undefined') {
                        return nrecord;
                    }
                });
                var filtered = records.filter(function (el) {
                    return el != null;
                });
                console.log("filtered", records.length);

                await exceptionModel.bulkCreate(
                    filtered, {
                    ignoreDuplicates: true
                }
                ).then(function () {
                    console.log('then b sequelize');
                    callback(null, {
                        statusCode: 200,
                        error: null,
                        msg: "Records inserted successfully"
                    });
                }).catch(function (err) {
                    console.log(err);
                    callback(null, {
                        statusCode: 404,
                        error: 1,
                        msg: "Error Occured"
                    });
                });

            }).catch(error => {
                console.log(error);
            });

        } catch (errrr) {
            console.log(errrr);
        }
        console.log('request end');
    }).catch(function (err) {
        console.log(err);
    });

};
