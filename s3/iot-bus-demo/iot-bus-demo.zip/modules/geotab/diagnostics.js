const API = require('mg-api-node');
const moment = require('moment');
const momenttimezone = require('moment-timezone');
var config = require('../../config/config.json');
moment.tz.setDefault(config.timeZone.africaCairo);

module.exports.insertDiagnostic = (event, context, callback) => {
    var typeName = 'Diagnostic';

    const DiagnosticModel = require('../../models/Diagnostic.model');

    var api = new API(config.geotab.email, config.geotab.password, config.geotab.database);

    api.authenticate(function (err, result) {
        if (err) {
            return JSON.stringify(err);
        }
        // For calling multiple api to get fuel and odometer data on a single API call
        api.authenticate(function (err, result) {
            if (err) {
                return JSON.stringify(err);
            }

            api.call('Get', {
                typeName: typeName,
            }, function (err, records) {
                records = records.map(function (record) {
                    let nrecord = {};
                    nrecord['_id'] = record.id;
                    nrecord['code'] = record.code;
                    nrecord['diagnosticType'] = record.diagnosticType;
                    nrecord['engineType'] = record.engineType;
                    nrecord['isLogGuaranteedOnEstimateError'] = record.isLogGuaranteedOnEstimateError;
                    nrecord['name'] = record.name;
                    nrecord['version'] = record.version;
                    return nrecord;
                });

                if (err) {
                    return JSON.stringify(err);
                }
                const rules = DiagnosticModel.bulkCreate(
                    records, {
                    ignoreDuplicates: true
                }
                ).then(function () {
                    callback(null, "inserted");
                }).catch(function (err) {
                    callback(err, "Err");
                });
            });
        });
    });
};
