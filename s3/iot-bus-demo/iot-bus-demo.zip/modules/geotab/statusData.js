const moment = require('moment');
const momenttimezone = require('moment-timezone');
var config = require('../../config/config.json');
var diagData = require('../../config/diagnosticDataAll.json');
const GeotabApi = require('mg-api-js');
const authentication = {
    credentials: {
        database: config.geotab.database,
        userName: config.geotab.email,
        password: config.geotab.password,
    }
}
const api = new GeotabApi(authentication);

moment.tz.setDefault(config.timeZone.africaCairo);

module.exports.insertStatusData = async (event, context, callback) => {
    let limit = 50000;
    var typeName = 'StatusData';
    let requiredValues = ['Acceleration forward or braking', 'Acceleration side to side', 'Acceleration up down', 'Accelerometer calibrated (1 = calibrated)', 'Cranking voltage', 'Device power change (1 = powered)', 'Diesel engine detected', 'Driver seat belt (1 = unbuckled)', 'Engine coolant temperature', 'Engine road speed', 'Engine speed', 'Fuel level (percentage)', 'Ignition', 'Odometer', 'Odometer adjustment', 'Outside air temperature', 'Parking brake (1 = on)', 'Passenger occupancy (1 = occupied)', 'Passenger seat belt violation (1 = unbuckled)', 'Raw odometer', 'Telematics device voltage', 'Total amount of fuel used', 'Total fuel used (since telematics device install)', 'Trip fuel used', 'Vehicle active (idle or driving)'];

    //diagData = JSON.parse(diagData);
    const statusModel = require('../../models/StatusData.model');
    const Device = require('../../models/Device.model');
    const lastRecord = await statusModel.findOne({
        attributes: ['id', 'DateTime'],
        order: [['id', 'DESC']],
        raw: true
    });
    if (lastRecord !== null && lastRecord.DateTime !== null) {
        var lastDate = moment(new Date(lastRecord.DateTime)).utc().format(config.dateFormat.UtcIsoString);
    }
    var devices = await Device.findAll({
        attributes: ['id', 'DeviceName'],
        raw: true
    })
    var all_devices = {};
    await devices.forEach(function (device, index) {
        all_devices[device.id] = device.DeviceName
    })

    let deviceDiagMap = {};

    Object.keys(all_devices).forEach(function (key) {
        deviceDiagMap[key] = [];
        requiredValues.forEach(function (diag, indexDiag) {
            var d = diag;
            deviceDiagMap[key][diag] = '';
        })

    });

    try {
        console.log("before API call try block");
        await api.call('Get', {
            typeName: typeName,
            resultsLimit: limit,
            search: {
                "fromDate": typeof (lastDate) != 'undefined' ? lastDate : "2019-07-03T16:34:33.063Z",
            }
        }).then(async function (records) {

            console.log('then b for records');
            records = records.map(function (record) {
                let nrecord = {};
                nrecord['_id'] = record.id;
                nrecord['DateTime'] = moment(record.dateTime).format(config.dateFormat.powerBi);
                nrecord['DeviceName'] = typeof (all_devices[record.device.id]) != 'undefined' ? all_devices[record.device.id] : '';
                nrecord['DeviceId'] = record.device.id;
                nrecord['DiagnosticId'] = record.diagnostic.id;
                nrecord['DiagnosticName'] = typeof (diagData[record.diagnostic.id]) !== 'undefined' ? diagData[record.diagnostic.id] : '';
                nrecord['Data'] = record.data;
                nrecord['createdAt'] = new Date();

                if (requiredValues.includes(nrecord['DiagnosticName'])) {
                    let diagName = nrecord['DiagnosticName'];
                    if (deviceDiagMap[record.device.id][diagName] != '') {
                        let diffSecs = moment(new Date(nrecord['DateTime'])).diff(moment(new Date(deviceDiagMap[record.device.id][diagName])), 'seconds');
                        if (diffSecs > 30) {
                            deviceDiagMap[record.device.id][diagName] = nrecord['DateTime'];
                            return nrecord;
                        }
                    } else {
                        deviceDiagMap[record.device.id][diagName] = nrecord['DateTime'];
                        return nrecord;
                    }
                }
            });

            var filtered = records.filter(function (el) {
                return el != null;
            });

            await statusModel.bulkCreate(
                filtered, {
                ignoreDuplicates: true
            }).then(function () {
                console.log('then b sequelize');
                callback(null, {
                    statusCode: 200,
                    error: null,
                    msg: "Records inserted successfully"
                });
            }).catch(function (err) {
                console.log(err);
                callback(null, {
                    statusCode: 404,
                    error: 1,
                    msg: "Error Occured"
                });
            });
        }).catch(error => {
            console.log(error);
        });

    } catch (errrr) {
        console.log(errrr);
    }
    console.log('request end');

};
