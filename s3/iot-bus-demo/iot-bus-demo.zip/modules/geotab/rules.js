const API = require('mg-api-node');
const moment = require('moment');
const momenttimezone = require('moment-timezone');
var config = require('../../config/config.json');
moment.tz.setDefault(config.timeZone.africaCairo);

module.exports.insertRules = (event, context, callback) => {
    var typeName = 'Rule';

    const RulesModel = require('../../models/Rules.model');

    var api = new API(config.geotab.email, config.geotab.password, config.geotab.database);
    api.authenticate(function (err, result) {
        if (err) {
            return JSON.stringify(err);
        }
        api.authenticate(function (err, result) {
            if (err) {
                return JSON.stringify(err);
            }

            api.call('Get', {
                typeName: typeName,
            }, function (err, records) {
                records = records.map(function (record) {
                    let nrecord = {};
                    nrecord['_id'] = record.id;
                    nrecord['Name'] = record.name;
                    nrecord['Version'] = record.version;
                    nrecord['BaseType'] = record.baseType;
                    nrecord['ActiveFrom'] = record.activeFrom;
                    nrecord['ActiveTo'] = record.activeTo;
                    //nrecord['createdAt'] = new Date();
                    return nrecord;
                });

                if (err) {
                    return JSON.stringify(err);
                }
                const rules = RulesModel.bulkCreate(
                    records, {
                    ignoreDuplicates: true
                }
                ).then(function () {
                    callback(null, "inserted");
                }).catch(function (err) {
                    callback(err, "Err");
                });
            });
        });
    });
};