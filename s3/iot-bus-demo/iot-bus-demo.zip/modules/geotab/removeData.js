const API = require('mg-api-node');
const moment = require('moment');
const momenttimezone = require('moment-timezone');
var config = require('../../config/config.json');
moment.tz.setDefault(config.timeZone.africaCairo);

module.exports.removeOlderData = (event, context, callback) => {
    let noOfDays = 90;
    let dataset = [
        ['tripdataset', 'StartDateTime'],
        ['statusdatadataset', 'DateTime'],
        ['odometerdataset', 'DateTime'],
        ['fuelusagedataset', 'DateTime'],
        ['logrecorddataset', 'DateTime'],
        ['exceptioneventdataset', 'ActiveFrom'],
    ];

    dataset.forEach(function (record, i) {
        let sql = "DELETE FROM `" + record[0] + "` WHERE " + record[1] + " < now() - interval " + noOfDays + " DAY";
        conn.query(sql, (err, res) => {
            if (err) {
                console.log("Delete failed for ", record[0], ", no:", err.errno, ", message:", err.sqlMessage);
            } else {
                console.log(res);
                console.log("Deleted records older than ", noOfDays, "days");
            }
        });
    });
};
