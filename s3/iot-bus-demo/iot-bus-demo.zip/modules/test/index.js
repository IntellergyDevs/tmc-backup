const db = require('../../config/db.sequelize');
const distanceHelper = require('../api/common/distanceCalculator')
const axios = require('axios');


let main = async () => {

    let query = "SELECT * FROM trainGraphLocations WHERE id >= 333 ORDER BY currentStation ASC ";
    var [trainGraphLocations_new, meta] = await db.query(query, {});
    let totalDuration = 0
    console.log(trainGraphLocations_new.length)
    // return
    for await (element of trainGraphLocations_new) {

        // let element = trainGraphLocations_new[i]
        // let distance = distanceHelper.distanceBetweenTwoPoints(element.startYLat, element.startXLong, element.endYLat, element.endXLong, 'M')
        // distance = distance.toFixed(0)

        let APIURL = `https://maps.googleapis.com/maps/api/directions/json?origin=${element.startYLat},${element.startXLong}&destination=-26.0836862867187,28.1117156048987&key=AIzaSyDwKsPZQWY-2KsAVsIHX_TizRLbR2HAfvI`
        // console.log(APIURL)

        const response = await axios.get(APIURL);
        const duration = response.data.routes[0] && response.data.routes[0].legs[0].duration.value ? response.data.routes[0].legs[0].duration.value : 'Infinity'

        const distance = response.data.routes[0] && response.data.routes[0].legs[0].distance.value ? response.data.routes[0].legs[0].distance.value : 'Infinity'

        totalDuration += duration
        // let qu = `UPDATE trainGraphLocations SET distanceMeters = ${distance}, duration= ${duration}, totalDuration=${totalDuration} WHERE id = ${element.id}`
        let disFromStation = 0
        // let qu = `UPDATE trainGraphLocations SET distanceFromStation=${disFromStation} WHERE id = ${element.id}`
        console.log(distance)
        // var [trainGraphLocations_new, meta] = await db.query(qu, {});
        // console.log(element.id, duration, totalDuration)
    }
}

main()