const db = require('../../config/db.sequelize');
const distanceHelper = require('../api/common/distanceCalculator')
const axios = require('axios');

let main = async () => {

    let query = "SELECT start, end, routeAllocationName, distanceFromStation FROM trainGraphLocations";
    var [trainGraphLocations_new, meta] = await db.query(query, {});
    let totalDuration = 0

    let from = {
        latitude: -26.0837865886268,
        longitude: 28.1108449262413
    }

    console.log(trainGraphLocations_new)
}

main()