module.exports.trackingDetails = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    moment.tz.setDefault(config.timeZone.africaCairo);
    let req = event.queryStringParameters;
    let busId = req && req.busId ? req.busId : '';

    let error = {};
    if (Object.keys(error).length == 0) {

        const tdate = moment().format("YYYY-MM-DD");
        var query;
        var eventsQuery;
        if (busId && busId != 'all') {
            // query = "SELECT DeviceId, DeviceName,Latitude,Longitude,MAX( createdAt ) AS createdAt FROM logrecorddataset WHERE DeviceId = '" + busId + "' GROUP BY DeviceId";
            query = "SELECT DeviceId, DeviceName,Latitude,Longitude FROM logrecorddataset WHERE id IN (SELECT MAX(id) FROM logrecorddataset WHERE DeviceId = '" + busId + "' GROUP BY DeviceId)";
            eventsQuery = "SELECT DeviceId,RuleId, RuleName, DeviceName, ActiveFrom AS createdAt FROM exceptioneventdataset WHERE DeviceId = '" + busId + "' AND createdAt >= DATE('" + tdate + "') ORDER BY id DESC";
        } else {
            query = "SELECT DeviceId, DeviceName,Latitude,Longitude FROM logrecorddataset WHERE id IN (SELECT MAX(id) FROM logrecorddataset GROUP BY DeviceId) AND DeviceId IN (SELECT id FROM device WHERE isActive = 1)";
            eventsQuery = "SELECT DeviceId,RuleId, RuleName, DeviceName, ActiveFrom AS createdAt FROM exceptioneventdataset WHERE createdAt >= DATE('" + tdate + "') ORDER BY id DESC";
        }

        var [records, meta] = await db.query(query, {});
        records = records ? records : [];



        var [eventRecords, meta] = await db.query(eventsQuery, {});

        eventRecords = eventRecords ? eventRecords : [];

        let responseObj = {};
        responseObj['exceptionEvents'] = [];
        responseObj['location'] = [];


        records.forEach(element => {
            responseObj['location'].push({
                "geometry": {
                    "type": "Point",
                    "coordinates": [Number(element.Longitude), Number(element.Latitude)]
                },
                "type": "Feature",
                "busInfo": {
                    'busId': element.DeviceId,
                    'busName': element.DeviceName
                },
                "properties": {

                }
            });
        });
        eventRecords.forEach(element => {
            if (typeof (responseObj['exceptionEvents'][element.DeviceId]) === 'undefined') {
                responseObj['exceptionEvents'][element.DeviceId] = [];
            }
            responseObj['exceptionEvents'][element.DeviceId].push({
                'RuleId': element.RuleId,
                'RuleName': element.RuleName,
                'DeviceName': element.DeviceName,
                'DeviceId': element.DeviceId,
                // 'date': moment(element.createdAt).format("YYYY-MM-DD HH:mm:ss"),
                'date': element.createdAt,

            });
        });
        let eventsList = [];
        Object.keys(responseObj['exceptionEvents']).forEach(element => {
            eventsList.push({
                [element]: responseObj['exceptionEvents'][element]
            });
        });

        if (records && records[0]) {
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    location: responseObj['location'],
                    exceptionEvents: eventsList,

                }, null, 2)
            })
        } else {
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "No data found",
                    //err: error,
                    status: 0,
                    results: [],
                })
            })
        }



    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }


};

module.exports.busTrackingDetail = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    moment.tz.setDefault(config.timeZone.africaCairo);
    let req = event.queryStringParameters;
    let busId = req && req.busId ? req.busId : '';

    let error = {};

    if (Object.keys(error).length == 0) {
        const tdate = moment().format("YYYY-MM-DD");
        var query;
        var eventsQuery;
        if (busId && busId != 'all') {
            // query = "SELECT DeviceId, DeviceName,Latitude,Longitude,MAX( createdAt ) AS createdAt FROM logrecorddataset WHERE DeviceId = '" + busId + "' GROUP BY DeviceId";
            query = "SELECT DeviceId, DeviceName,Latitude,Longitude FROM logrecorddataset WHERE id IN (SELECT MAX(id) FROM logrecorddataset WHERE DeviceId = '" + busId + "' GROUP BY DeviceId)";
            eventsQuery = "SELECT DeviceId,RuleId, RuleName, DeviceName, ActiveFrom AS createdAt FROM exceptioneventdataset WHERE DeviceId = '" + busId + "' AND createdAt >= DATE('" + tdate + "') ORDER BY id DESC";
        } else {
            query = "SELECT DeviceId, DeviceName,Latitude,Longitude FROM logrecorddataset WHERE id IN (SELECT MAX(id) FROM logrecorddataset GROUP BY DeviceId)";
            eventsQuery = "SELECT DeviceId,RuleId, RuleName, DeviceName, ActiveFrom AS createdAt FROM exceptioneventdataset WHERE createdAt >= DATE('" + tdate + "') ORDER BY id DESC";
        }

        var [records, meta] = await db.query(query, {});
        records = records ? records : [];



        var [eventRecords, meta] = await db.query(eventsQuery, {});

        eventRecords = eventRecords ? eventRecords : [];

        let responseObj = {};
        responseObj['exceptionEvents'] = [];
        responseObj['location'] = [];


        records.forEach(element => {
            responseObj['location'].push({
                "geometry": {
                    "type": "Point",
                    "coordinates": [Number(element.Longitude), Number(element.Latitude)]
                },
                "type": "Feature",
                "busInfo": {
                    'busId': element.DeviceId,
                    'busName': element.DeviceName
                },
                "properties": {

                }
            });
        });
        eventRecords.forEach(element => {
            if (typeof (responseObj['exceptionEvents'][element.DeviceId]) === 'undefined') {
                responseObj['exceptionEvents'][element.DeviceId] = [];
            }
            responseObj['exceptionEvents'][element.DeviceId].push({
                'RuleId': element.RuleId,
                'RuleName': element.RuleName,
                'DeviceName': element.DeviceName,
                'DeviceId': element.DeviceId,
                'date': element.createdAt,
                // 'date': moment(element.createdAt).format("YYYY-MM-DD HH:mm:ss"),
            });
        });
        let eventsList = [];
        Object.keys(responseObj['exceptionEvents']).forEach(element => {
            eventsList.push({
                [element]: responseObj['exceptionEvents'][element]
            });
        });

        if (records && records[0]) {
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    "geometry": responseObj['location'][0].geometry,
                    "type": "Feature",
                    "busInfo": responseObj['location'][0].busInfo,
                    exceptionEvents: eventsList,
                }, null, 2)
            })
        } else {
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "No data found",
                    //err: error,
                    status: 0,
                    results: [],
                })
            })
        }



    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }


};

module.exports.busTrackingDetailGeo = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    const GeotabApi = require('mg-api-js');
    var config = require('../../config/config.json');
    const authentication = {
        credentials: {
            database: config.geotab.database,
            userName: config.geotab.email,
            password: config.geotab.password,
        }
    }
    const api = new GeotabApi(authentication);


    moment.tz.setDefault(config.timeZone.africaCairo);
    let req = event.queryStringParameters;
    let busId = req && req.busId ? req.busId : '';

    let error = {};
    let liveLocation;

    if (Object.keys(error).length == 0) {
        const tdate = moment().format("YYYY-MM-DD");
        var query;
        var eventsQuery;
        if (busId) {
            eventsQuery = "SELECT DeviceId,RuleId, RuleName, DeviceName, ActiveFrom AS createdAt FROM exceptioneventdataset WHERE DeviceId = '" + busId + "' AND createdAt >= DATE('" + tdate + "') ORDER BY id ";

            await api.call('Get', {
                "typeName": "DeviceStatusInfo",
                "resultsLimit": 10,
                "search": {
                    deviceSearch: { id: busId },
                }
            }).then(async function (records) {
                liveLocation = records;
            }).catch((err) => {
                console.log("Err : ", err);
                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "No data found",
                        //err: error,
                        status: 0,
                        results: [],
                    })
                })
            })
        }
        else {
            console.log("BusId missing")
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "No data found",
                    //err: error,
                    status: 0,
                    results: [],
                })
            })
        }

        var [eventRecords, meta] = await db.query(eventsQuery, {});
        eventRecords = eventRecords ? eventRecords : [];

        let responseObj = {};
        responseObj['exceptionEvents'] = [];
        responseObj['location'] = [];

        liveLocation.forEach(element => {
            responseObj['location'].push({
                "geometry": {
                    "type": "Point",
                    "coordinates": [Number(element.longitude), Number(element.latitude)]
                },
                "type": "Feature",
                "busInfo": {
                    'busId': element.device.id,
                    'busName': element.deviceName
                },
                "properties": {

                }
            });
        });
        eventRecords.forEach(element => {
            if (typeof (responseObj['exceptionEvents'][element.DeviceId]) === 'undefined') {
                responseObj['exceptionEvents'][element.DeviceId] = [];
            }
            responseObj['exceptionEvents'][element.DeviceId].push({
                'RuleId': element.RuleId,
                'RuleName': element.RuleName,
                'DeviceName': element.DeviceName,
                'DeviceId': element.DeviceId,
                'date': element.createdAt,
            });
        });
        let eventsList = [];
        Object.keys(responseObj['exceptionEvents']).forEach(element => {
            eventsList.push({
                [element]: responseObj['exceptionEvents'][element]
            });
        });

        if (liveLocation && liveLocation[0]) {
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    "geometry": responseObj['location'][0].geometry,
                    "type": "Feature",
                    "busInfo": responseObj['location'][0].busInfo,
                    exceptionEvents: eventsList,
                }, null, 2)
            })
        } else {
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "No data found",
                    //err: error,
                    status: 0,
                    results: [],
                })
            })
        }



    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }


};

module.exports.getBusesStationEtaData = async (event, context, callback) => {
    try {
        const geolib = require('geolib');
        const routeDeterminationModel = require('../../models/routeDetermination.model');

        context.callbackWaitsForEmptyEventLoop = false;
        let auth = await utils.checkAuth(event.headers, callback)
        let user = jwt_decode(event.headers.Authorization.split(' ')[1]);

        let parsedRoutes = user.associatedRoutes
        if (!user.associatedRoutes) {
            throw new Error('You are not authorized to access that location')
        }
        let routesStopsUser = parsedRoutes.map(id => "'" + id + "'").join()

        let getStopsForStationQuery = `SELECT id, routeAllocationName,StopNumber, PointX, PointY,sequence FROM stoplocations_react WHERE include = 1 AND routeAllocationName IN (${routesStopsUser})`
        const p1 = db.query(getStopsForStationQuery, {
            raw: true,
        })

        let getPolygonsQuery = `SELECT name, landmarkId,Latitude,Longitude FROM stopsSurroundingStops WHERE name = '${user.associatedStation}'`
        const p2 = db.query(getPolygonsQuery, {
            raw: true,
        })

        let getDeviceInfoQuery = `SELECT latitude,longitude,routeDetermination.pastList AS pastList,currentRouteDetermined, routeDetermination.deviceId FROM deviceStatusInfo LEFT JOIN routeDetermination ON deviceStatusInfo.deviceId = routeDetermination.deviceId`
        const p3 = db.query(getDeviceInfoQuery, {
            raw: true,
        })

        let getBoundary = `SELECT stationBoundary FROM stopsLandmarks WHERE name = '${user.associatedStation}'`
        const p4 = db.query(getBoundary, {
            raw: true,
        })

        let stopsObj = {}
        let polygonArray = []
        let busesInPolygon = {}
        await Promise.all([p1, p2, p3, p4]).then(async (values) => {
            let stops = values[0][0]
            let polygons = values[1][0]
            let deviceInfo = values[2][0]
            let Boundary = values[3][0]


            polygons.forEach(element => {
                polygonArray.push({
                    latitude: element.Latitude,
                    longitude: element.Longitude,
                })
            });

            stops.forEach(element => {

                if (!stopsObj[element.routeAllocationName]) {
                    stopsObj[element.routeAllocationName] = {}
                    stopsObj[element.routeAllocationName]['stops'] = []
                }
                stopsObj[element.routeAllocationName]['stops'].push({
                    StopNumber: element.StopNumber,
                    latitude: element.PointY,
                    longitude: element.PointX,
                    sequence: element.sequence,
                })
            });
            var updateRouteDeterminationObj = []

            deviceInfo.forEach((bus, index) => {

                const isPointInPolygon = geolib.isPointInPolygon({ latitude: bus.latitude, longitude: bus.longitude }, polygonArray);
                if (isPointInPolygon) {
                    busesInPolygon[bus.deviceId] = {}
                    busesInPolygon[bus.deviceId]['stops'] = []
                    busesInPolygon[bus.deviceId]['route'] = bus.currentRouteDetermined
                    busesInPolygon[bus.deviceId]['location'] = {
                        latitude: bus.latitude,
                        longitude: bus.longitude,
                    }

                    let distances = []
                    stopsObj[bus.currentRouteDetermined]['stops'].forEach(element => {
                        const disBetweenBusAndStop = geolib.getDistance(
                            element,
                            bus
                        );
                        distances.push({
                            ...element,
                            d: disBetweenBusAndStop

                        })
                        // console.log(disBetweenBusAndStop)
                    });
                    distances.sort(function (a, b) {
                        if (a.d < b.d) return -1;
                        if (a.d > b.d) return 1;
                        return 0;
                    });


                    let Nearest = distances[0]
                    let SNearest = distances[1]
                    let nearest

                    console.log('1', Nearest.StopNumber)
                    console.log('2', SNearest.StopNumber)
                    bus.pastList = bus.pastList ? JSON.parse(bus.pastList) : []
                    if (bus.pastList.includes(Nearest.sequence)) {
                        // nearest
                        nearest = Nearest
                    } else if (bus.pastList.includes(SNearest.sequence + 1)) {
                        // second nearest
                        nearest = SNearest
                    } else {
                        nearest = Nearest
                    }


                    bus.pastList = [
                        Nearest.sequence + 1,
                        Nearest.sequence + 2,
                        Nearest.sequence + 3,
                        SNearest.sequence + 1,
                        SNearest.sequence + 2,
                        SNearest.sequence + 3,
                    ]

                    updateRouteDeterminationObj.push({
                        deviceId: bus.deviceId,
                        pastList: JSON.stringify(bus.pastList),
                    })
                    busesInPolygon[bus.deviceId]['nearest'] = nearest

                    let i = 0
                    let stopsCount = 0
                    let Firstindex = stopsObj[bus.currentRouteDetermined]['stops'].findIndex(val => val.StopNumber == nearest['StopNumber'])

                    while (i < 3) {
                        if (stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount]) {
                            busesInPolygon[bus.deviceId]['stops'].push({
                                StopNumber: stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount].StopNumber,
                                latitude: stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount].latitude,
                                longitude: stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount].longitude
                            })
                        }
                        i++;
                        stopsCount++;
                    }

                    busesInPolygon[bus.deviceId]['stops'].forEach((stopElement, index) => {
                        let getDistance
                        if (index == 0) {
                            getDistance = distanceHelper.distanceBetweenTwoPoints(bus.latitude, bus.longitude, stopElement.latitude, stopElement.longitude, "K")

                        } else {
                            let prevElement = busesInPolygon[bus.deviceId]['stops'][index - 1]
                            getDistance = distanceHelper.distanceBetweenTwoPoints(prevElement.latitude, prevElement.longitude, stopElement.latitude, stopElement.longitude, "K")
                        }

                        const speed = 20//kmph
                        let durationInSecs = getDistance / speed
                        duration = distanceCalc.secondsToHms(durationInSecs * 3600)// secs
                        // console.log(speed, getDistance, duration)

                        busesInPolygon[bus.deviceId]['stops'][index]['distance'] = {
                            km: getDistance.toFixed(2),
                            m: (getDistance / 1000).toFixed(2)
                        }
                        busesInPolygon[bus.deviceId]['stops'][index]['eta'] = {
                            text: duration,
                            seconds: Number(durationInSecs * 3600).toFixed(2)
                        }
                    });

                }
            });

            console.log(updateRouteDeterminationObj)


            await routeDeterminationModel.bulkCreate(updateRouteDeterminationObj, {
                updateOnDuplicate: ['pastList']
            }).then(function () {
                console.log('then b sequelize');
                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "Bus data fetched successfully",
                        status: 1,
                        results: {
                            busesInPolygon,
                        }
                    }, null, 2)
                })
            }).catch(function (err) {
                console.log(err);
                callback(null, {
                    statusCode: 404,
                    error: 1,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    msg: "Error Occured"
                });
            });
        });
        console.log('req end')


    } catch (err) {
        console.log(err)
        callback(null, {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Internal server error occured",
                err: err.message,
                status: 0,
                results: [],
            })
        })
    }
}