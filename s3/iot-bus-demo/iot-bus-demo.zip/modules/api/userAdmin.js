const querystring = require('querystring');
const UserAdminModel = require('../../models/UserAdmin.model');
const db = require('../../config/db.sequelize');
const bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
const JWT_SECRET_KEY = "aGPuWz7Q3V2mJMBqixCL"
var config = require('../../config/config.json');
const userAdminStaticModel = require('../../models/userAdminStatic.model')
module.exports.Login = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {

        const req = JSON.parse(event.body);

        const email = req.email ? req.email : '';
        const password = req.password ? req.password : '';
        const isMicrosoftUser = req.isMicrosoftUser ? req.isMicrosoftUser : false;
        if (!(email || password)) {
            throw new Error('Please enter all the details')
        }
        const user = await UserAdminModel.findOne({
            where: {
                email: email
            },
            raw: true
        });
        if (!user && isMicrosoftUser) {
            throw new Error("You are not authorized to access this. Please contact to sensifeye administrator.")
        }
        if (!user && !isMicrosoftUser) {
            throw new Error("Your account is not registered")
        }
        if (user.isVerified == 0) {
            throw new Error("Your account is not yet verified")
        }
        if (user.status == 0) {
            throw new Error("Your account has been made inactive")
        }
        const isValidPass = await bcrypt.compare(
            password,
            user.password
        );

        if (!isValidPass && !isMicrosoftUser) {
            throw new Error('Password is incorrect');
        }

        let expiry = user.role == 'ADMIN' ? { expiresIn: '1h' } : {}
        const token = jwt.sign({
            userId: user.id, email: user.email, role: user.role, associatedStation: user.associatedStation,
            associatedRoutes: JSON.parse(user.associatedRoutes),
        }, JWT_SECRET_KEY, expiry);
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'X-Frame-Options': 'DENY', 'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "You have successfully logged in",
                status: 1,
                results: {
                    user: {
                        email: user.email,
                        firstName: user.firstName,
                        lastName: user.lastName,
                        name: user.name,
                        station: user.associatedStation,
                        routes: JSON.parse(user.associatedRoutes),
                        role: user.role,
                    },
                    token
                }
            }, null, 2)
        })

    } catch (err) {
        console.log(err)
        callback(null, {
            statusCode: 401,
            headers: {
                'Content-Type': 'application/json',
                'X-Frame-Options': 'DENY', 'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: err.message,
                err: err.message,
                status: 0,
                results: [],
            })
        })
    }
}

module.exports.SignUp = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        const req = JSON.parse(event.body);


        const email = req.email ? req.email : '';
        const password = req.password ? req.password : '';
        const firstName = req.firstName ? req.firstName : '';
        const lastName = req.lastName ? req.lastName : '';

        let passwordErrors = validatePassword(password)
        if (passwordErrors.length > 0) {
            throw new Error(passwordErrors);
        }
        const passwordHash = await bcrypt.hash(password, 10);
        let user = {
            email,
            firstName,
            lastName,
            name: firstName + " " + lastName,
            password: passwordHash,
            isVerified: 1,
            status: 1
        }

        const userExist = await UserAdminModel.findOne({
            where: {
                email: email
            },
            raw: true
        });
        if (userExist) {
            throw new Error("This email is already registered")
        }

        await UserAdminModel.create(
            user
        ).then(async function (user){
            let userInfo = await UserAdminModel.findOne({
                where: {
                    email: email
                },
                raw: true
            });
            const userDetail = {
                headerText:"#ffffff",
                headerColor:"#2d2d2d",
                legendBackground:"#2d2d2d",
                busInfoBackground:"#2d2d2d",
                logo:"Mini Bus Tracker",
                userAdmin_id:userInfo.id
            }
           return await userAdminStaticModel.create(userDetail);
        }).then(function (user) {
            console.log("user========>",user);
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'X-Frame-Options': 'DENY', 'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "User added successfully",
                    err: {},
                    status: 1,
                    results: {
                        user: {
                            email: user.email,
                            name: user.name,
                        }
                    },
                })
            })
        }).catch(async function (err) {
            console.log("errors===========>",err)
            let errors = err.errors.map(function (record) {
                return record.message;
            });
            callback(null, {
                statusCode: 401,
                headers: {
                    'Content-Type': 'application/json',
                    'X-Frame-Options': 'DENY', 'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Validation Failed",
                    err: errors,
                    status: 0,
                    results: [],
                })
            })
        })

    } catch (err) {
        console.log(err.message)
        callback(null, {
            statusCode: 401,
            headers: {
                'Content-Type': 'application/json',
                'X-Frame-Options': 'DENY', 'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: err.message,
                err: err.message,
                status: 0,
                results: [],
            })
        })
    }
}

function validatePassword(p) {
    errors = [];
    if (p.length < 8) {
        errors.push("Your password must be at least 8 characters");
    }
    if (p.search(/[a-z]/i) < 0) {
        errors.push("Your password must contain at least one letter.");
    }
    if (p.search(/[0-9]/) < 0) {
        errors.push("Your password must contain at least one digit.");
    }
    return errors;
}