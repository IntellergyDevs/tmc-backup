// Import required AWS SDK clients and commands for Node.js
// import { GetItemCommand } from "@aws-sdk/client-dynamodb";
// import { ddbClient } from "./libs/ddbClient.js";
const { ddbClient } = require('./ddbClient')
const { GetItemCommand, BatchGetItemCommand, QueryCommand, ScanCommand } = require('@aws-sdk/client-dynamodb')

// Set the parameters
const params = {
    RequestItems: {
        'pilabs-trips-database': {
            Keys: [
                {
                    tripId: { S: "7cbee101-38f8-3d60-bb8c-2f1bd07c21dd" },
                },
                {
                    tripId: { S: "87df88a0-8c0b-3391-a456-2a1e10ed29f9" },
                },
            ],
            ProjectionExpression: "tripId, tripLength",
        },
    },
};
const params2 = {
    // KeyConditionExpression: "",
    FilterExpression: "tripLength > :zero and tripLength > :nnn",
    ExpressionAttributeValues: {
        ':zero': { N: '0' },
        ':nnn': { N: '17968' },
    },
    // ProjectionExpression: "tripId, tripLength, timestampStart",
    TableName: "pilabs-trips-database",
    ScanIndexForward: false,

};

// const run = async () => {
//     try {
//         const statement = `SELECT * FROM pilabs-trips-database`
//         const results = await ddbClient.executeStatement({ Statement: statement }).promise();
//     } catch (err) {
//         console.log("Error", err);
//     }
// }
module.exports.run = async () => {
    try {
        const data = await ddbClient.send(new ScanCommand(params2));
        console.log("daata",data.Items[0])
        // data.Items.forEach(rec => {
        //     // var d = Number(rec.timestampStart.N)
        //     // console.log(new Date(d))
        //     console.log(rec.tripId)
        // })
        // console.log("Success, items retrieved", JSON.stringify(data.Responses));
        return data;
    } catch (err) {
        console.log("Error", err);
    }
};
