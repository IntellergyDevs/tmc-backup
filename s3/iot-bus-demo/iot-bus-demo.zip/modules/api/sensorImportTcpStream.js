const querystring = require('querystring');
const LogRecordModel = require('../../models/LogRecord.model');
const db = require('../../config/db.sequelize');

var config = require('../../config/config.json');
const moment = require('moment');

module.exports.importSensorData = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    let req = event.queryStringParameters;
    let stream = req && req.stream ? req.stream : '';

    let error = {};

    if (!stream) {
        error['stream'] = "Stream cannot be null"
    }
    if (Object.keys(error).length == 0) {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                stream: stream,
                msg: "Stream imported successfully (test)",
            }, null, 2)
        })
    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "No data found",
                err: error,
                status: 0,
                results: [],
            })
        })
    }

};

