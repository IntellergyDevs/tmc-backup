const NotificationsModel = require('../../models/Notifications.model');

module.exports.getAll = async (event, context, callback) => {
    console.log('query start - ', new Date())
    const records = await NotificationsModel.findAndCountAll({
        raw: true,
        limit: 100,
    })
    console.log('inside async after if - ', new Date())
        // let response = await records.rows.map(function (record) {
        //     //let currentTime = moment().tz(config.timeZone.africaCairo).format("x")
        //     //let notifTime = moment(record.createdAt).tz(config.timeZone.africaCairo).format("x")

        //     let nrecord = {};
        //     nrecord = record;
        //     //nrecord['diff'] = timeDiff(currentTime, notifTime);
        //     return nrecord
        // });
        console.log('after time diff loop and before sending in response - ', new Date())
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: records.count == 0 ? "No Notifications found" : "Notifications fetched successfully",
                err: {},
                status: 1,
                results: records,
            })
        })

    // .then(async function (records) {
        
    // }).catch(function (err) {
    //     callback(err)
    // });
};