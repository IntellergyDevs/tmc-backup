const moment = require('moment');
const momenttimezone = require('moment-timezone');
// const querystring = require('querystring');
// const LogRecordModel = require('../../models/LogReco/rd.model');
const db = require('../../config/db.sequelize');
const utils = require('./common/utils')
const errorMessages = {
    'JSONRPCError - Incorrect login credentials': 'You can\'t view respective bus details that frequently',
    'JSONRPCError - API calls quota exceeded. Maximum admitted 10 per 1m.': 'You can\'t view respective bus details that frequently'
}

const userAdminStaticModel = require('../../models/userAdminStatic.model')
const userAdmin = require('../../models/UserAdmin.model');
const { raw } = require('mysql');
// var config = require('../../config/config.json');
// React current APIs

module.exports.getAllBuses = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    let auth = await utils.checkAuth(event.headers, callback)

    var config = require('../../config/config.json');
    // const GeotabApi = require('mg-api-js');
    // const authentication = {
    //     credentials: {
    //         database: config.geotab.database,
    //         userName: config.geotab.email,
    //         password: config.geotab.password,
    //     }
    // }
    // const api = new GeotabApi(authentication);

    moment.tz.setDefault(config.timeZone.africaCairo);
    let error = {};
    if (Object.keys(error).length == 0) {
        var busLocations = {};

        let query = "SELECT * FROM device LEFT JOIN deviceStatusInfo ON device.id = deviceStatusInfo.deviceID WHERE isActive = 1";
        var [records, meta] = await db.query(query, {});
        records = records ? records : [];

        if (records && records[0]) {
            // let calls = [];
            // records.forEach(value => {
            //     calls.push(['Get', { typeName: 'DeviceStatusInfo', resultsLimit: 1, search: { deviceSearch: { id: value.id } } }]);
            //     busLocations[value.id] = value;
            // })
            // let myMultiCall = api.multiCall(calls);
            const idleTime = 5//mins

            let finalResponse = records.map((value, index) => {
                console.log(value)
                let isDriving = value.isDriving
                let duration = value.currentStateDuration
                let durationInMins = Number(moment(duration, 'hh:mm:ss').format("m"))
                let status = '';
                if (isDriving) {
                    status = 'running'
                }
                if (!isDriving) {
                    if (durationInMins <= idleTime) {
                        status = 'idle'
                    } else {
                        status = 'stopped'
                    }
                }
                console.log(isDriving, duration, durationInMins, status)
                return {
                    status,
                    statusDuration: duration,
                    latitude: Number(value.latitude),
                    longitude: Number(value.longitude),
                    id: value.deviceId,
                    DeviceName: value.DeviceName
                }
            })
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Bus data fetched successfully",
                    status: 1,
                    results: {
                        buses: finalResponse
                    }
                }, null, 2)
            })

        } else {
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "No bus data found",
                    //err: error,
                    status: 0,
                    results: [],
                })
            })
        }



    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }
};

module.exports.getBusExceptions = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    let auth = await utils.checkAuth(event.headers, callback)

    var config = require('../../config/config.json');
    moment.tz.setDefault(config.timeZone.africaCairo);
    let req = event.queryStringParameters;
    let busId = req && req.busId ? req.busId : null;
    let fromDate = req && req.fromDate ? req.fromDate : new Date().toISOString().split('T')[0];
    let toDate = req && req.toDate ? req.toDate : new Date().toISOString().split('T')[0];

    const GeotabApi = require('mg-api-js');
    const authentication = {
        credentials: {
            database: config.geotab.database,
            userName: config.geotab.email,
            password: config.geotab.password,
        }
    }
    const api = new GeotabApi(authentication);

    let error = {};
    if (busId == null) {
        error['Invalid Param'] = "BusId is invalid parameter"
    }
    if (Object.keys(error).length == 0) {
        let calls = [
            ['Get', {
                typeName: 'ExceptionEvent',
                search: {
                    toDate: toDate,
                    fromDate: fromDate,//,new Date().toISOString().split('T')[0],
                    deviceSearch: { id: busId }
                }
            }],
            // ['Get', { typeName: 'DeviceStatusInfo', resultsLimit: 1, search: { deviceSearch: { id: busId } } }],
            ['Get', { typeName: 'Rule' }],

        ];
        await api.multiCall(calls).then(data => {
            let events = [];
            var rules = [];
            data[1].forEach(function (rule) {
                rules[rule.id] = rule.name
            })
            if (data[0].length > 0) {

                data[0].sort((a, b) => {
                    return new Date(b.activeFrom) - new Date(a.activeFrom)
                });

                data[0].forEach((value) => {
                    events.push({
                        ...value,
                        rule: {
                            id: value.rule.id,
                            name: typeof (rules[value['rule']['id']]) != 'undefined' ? rules[value['rule']['id']] : '',
                        },
                        activeFrom: moment(value['activeFrom']).tz(config.timeZone.africaCairo).format(config.dateFormat.powerBi),
                        activeTo: moment(value['activeTo']).tz(config.timeZone.africaCairo).format(config.dateFormat.powerBi)
                    })
                })
            }
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Bus exceptions data fetched successfully",
                    status: 1,
                    results: {
                        exceptions: events,
                        // location: location,
                    }
                }, null, 2)
            })
        }).catch(error => {
            let err = 'An internal server error occured'
            console.log(error)

            if (error.message && errorMessages[error.message]) {
                err = errorMessages[String(error.message)]
            } else {
                err = error.message
            }
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: err,//error.message ? error.message : "An internal server error occured",
                    //err: error,
                    status: 0,
                    results: [],
                })
            })
        });

    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }
};

module.exports.getAllStaticDetails = async (event, context, callback) => {

    context.callbackWaitsForEmptyEventLoop = false;
    let auth = await utils.checkAuth(event.headers, callback)

    const stopLocationsModel = require('../../models/StopLocations.model');
    const stopsLandmarksModel = require('../../models/stopsLandmarks.model');
    const stopsSurroundingStopsModel = require('../../models/stopsSurroundingStops.model');

    let error = {};
    if (Object.keys(error).length == 0) {

        let queryforStops = "SELECT B.id, A.name as Landmark, B.name, A.Latitude AS landmarkLat, A.Longitude AS landmarkLong, B.Latitude AS surroundLat, B.Longitude AS surroundLong, associatedRoutes FROM stopsLandmarks A LEFT JOIN stopsSurroundingStops B ON A.id = B.landmarkId";

        // var [records, meta] = await db.query(query, {});
        // records = records ? records : [];
        let queryforFullPath = "SELECT id, name, colorScheme, landmarkId, Latitude, Longitude FROM stopsFullPath"

        // let busRoutes = stopLocationsModel.findAll({
        // });
        let busRoutes = db.query("SELECT * FROM stoplocations_react", {
            nest: true
        });
        const stopsAndLandmarks = db.query(queryforStops, {
            nest: true
        });
        console.log('stopsAndLandmarks======>',stopsAndLandmarks)

        let fullPath = db.query(queryforFullPath, {
            nest: true
        });
        // records = records ? records : [];
        var toDate = moment().format("YYYY-MM-DD");
        var fromDate = moment().add(-30, 'days').format("YYYY-MM-DD");
        let getCountQuery = `SELECT DeviceId, COUNT(_id) AS count FROM exceptioneventdataset WHERE createdAt >= '${fromDate}' GROUP BY DeviceId`
        var [getExceptionCounts, meta] = await db.query(getCountQuery, {
            raw: true,
        })
        console.log('getExceptionCounts',getExceptionCounts)
        let totalExceptions = 0
        const totalDevice = getExceptionCounts.length
        let deviceRating = {}
        getExceptionCounts.forEach(element => {
            totalExceptions += element.count
            deviceRating[element.DeviceId] = element.count
        });

        const avg = totalExceptions / totalDevice
        const percentile = avg / 5

        let outOf = [0, 0, 0, 0, 0]

        outOf.forEach((element, index) => {
            let num = avg - (index * percentile)
            outOf[index] = num
        });

        getExceptionCounts.forEach((element, index) => {
            let count = element.count
            let rating = outOf.filter(elem => count <= elem).length
            deviceRating[element.DeviceId] = rating
        });
        console.log(toDate, fromDate)
        await Promise.all([busRoutes, stopsAndLandmarks, fullPath]).then((values) => {
            let records = values[0]
            let landmarksRaw = values[1]
            let fullPath = values[2]
            let fullPathLocation = {};

            fullPath.forEach(element => {
                if (typeof (fullPathLocation[element.name]) === 'undefined') {

                    fullPathLocation[element.name] = [];
                    // fullPathLocation[element.name]['id'] = element.name;
                    // fullPathLocation[element.name]['name'] = element.name;
                    // fullPathLocation[element.name]['routeCoordinates'] = [];
                }
                fullPathLocation[element.name].push({
                    id: element.id,
                    latitude: Number(element.Latitude),
                    longitude: Number(element.Longitude),
                })
            });
            let stopLocations = {};
            records.forEach(element => {
                if (typeof (stopLocations[element.routeAllocationName]) === 'undefined') {
                    stopLocations[element.routeAllocationName] = {};
                    stopLocations[element.routeAllocationName]['id'] = element.routeAllocationName;
                    stopLocations[element.routeAllocationName]['name'] = element.routeAllocationName;
                    stopLocations[element.routeAllocationName]['routeStops'] = [];
                    stopLocations[element.routeAllocationName]['routeCoordinates'] = fullPathLocation[element.routeAllocationName] ? fullPathLocation[element.routeAllocationName] : []
                    stopLocations[element.routeAllocationName]['colorScheme'] = "#" + element.colorScheme;
                }
                stopLocations[element.routeAllocationName].routeStops.push({
                    message: element.StopNumber,
                    // colorScheme: "#" + element.colorScheme,
                    id: element.id,
                    longitude: Number(element.PointX),
                    latitude: Number(element.PointY),
                    // geometry: {
                    //     coordinates: [
                    //         Number(element.PointY),
                    //         Number(element.PointX)
                    //     ]
                    // }
                })
            });
            let responseStops = [];

            Object.keys(stopLocations).forEach(element => {
                responseStops.push(stopLocations[element]);
            });
            let landmarks = landmarksRaw.filter((item, index, objects) => {
                if (index === 0) {
                    return item
                } else if (item.Landmark !== objects[index - 1].Landmark) {
                    return {
                        "name": item.Landmark,
                        "latitude": Number(item.landmarkLat),
                        "longitude": Number(item.landmarkLong),
                        "associatedRoutes": item.associatedRoutes
                    };
                }
            }).map(function (item) {
                return {
                    "name": item.Landmark,
                    "latitude": Number(item.landmarkLat),
                    "longitude": Number(item.landmarkLong),
                    "associatedRoutes": JSON.parse(item.associatedRoutes)
                };
            });

            let landmarksWithStops = landmarksRaw.filter(({ id }) => id != null).map(function (item) {
                return {
                    "Landmark": item.Landmark,
                    "name": item.name,
                    "latitude": Number(item.surroundLat),
                    "longitude": Number(item.surroundLong),
                };
            }).reduce((r, a) => {
                r[a.Landmark] = [...r[a.Landmark] || [], a];
                return r;
            }, {});
            let responseLandmarksStops = [];
            Object.keys(landmarksWithStops).forEach((element, key) => {
                responseLandmarksStops.push({
                    id: element,
                    name: element,
                    routeCoordinates: landmarksWithStops[element]
                })
                // console.log(element)
            });
            responseLandmarksStops.forEach((element, index) => {
                let landmark = landmarks.filter(lm => lm.name == element.name)

                responseLandmarksStops[index]['associatedRoutes'] = landmark && landmark[0] && landmark[0].associatedRoutes ? landmark[0].associatedRoutes : []
            })

            if (records && records[0]) {

                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Frame-Options': 'DENY', 'X-Frame-Options': 'DENY',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "Stops and landmarks data fetched successfully",
                        status: 1,
                        results: {
                            "type": "FeatureCollection",
                            // routes: {
                            //     routeStops: responseStops, //black main stops
                            //     routeCoordinates: fullPathLocation // full path trace
                            // },
                            routes: responseStops,
                            landmarks: {
                                landmarkStops: landmarks, // main station points
                                landmarkAreaCoordinates: responseLandmarksStops // all polygon
                            },
                            deviceRating,
                            stats: {
                                totalExceptions,
                                avg
                            },
                        },
                    }, null, 2)
                })
            } else {
                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Frame-Options': 'DENY', 'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "No data found",
                        //err: error,
                        status: 0,
                        results: [],
                    })
                })
            }
        });

    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }
};

module.exports.getBusLocationTrace = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    let auth = await utils.checkAuth(event.headers, callback)

    var config = require('../../config/config.json');
    moment.tz.setDefault(config.timeZone.africaCairo);
    let req = event.queryStringParameters;

    let busId = req && req.busId ? req.busId : null;
    let fromDate = req && req.fromDate ? req.fromDate : new Date().toISOString();
    let toDate = req && req.toDate ? req.toDate : new Date().toISOString();

    const GeotabApi = require('mg-api-js');
    const authentication = {
        credentials: {
            database: config.geotab.database,
            userName: config.geotab.email,
            password: config.geotab.password,
        }
    }
    const api = new GeotabApi(authentication);
    console.log(fromDate, "  <> ", toDate)

    try {
        if (busId == null) {
            throw new Error("BusId is invalid parameter")
        }
        // Total Distance covered by bus

        // let queryTotalDis = `SELECT SUM(DistanceCovered) AS DistanceCovered FROM odometerdataset WHERE DeviceId = '${busId}' AND DateTime >= '${fromDate}' AND DateTime <= '${toDate}' AND DistanceCovered > 0`;
        // let queryTotalDis = `SELECT Data FROM odometerdataset WHERE DeviceId = '${busId}' AND DateTime >= '${fromDate}' AND DateTime <= '${toDate}' ORDER BY DateTime DESC`
        let queryAvgSpeed = `SELECT AVG(AverageSpeed) AS AverageSpeed FROM tripdataset WHERE DeviceId = '${busId}' AND StartDateTime >= '${fromDate}' AND StartDateTime <= '${toDate}'`;
        let queryFuelUsed = `SELECT Data AS FuelUsed FROM fuelusagedataset WHERE DeviceId = '${busId}' AND DateTime >= '${fromDate}' AND DateTime <= '${toDate}' ORDER BY FuelUsed ASC`;
        let queryIdlingTime = `SELECT SUM( Duration ) AS IdlingDuration FROM exceptioneventdataset WHERE DeviceId = 'bC' AND RuleId = 'RuleIdlingId' AND ActiveFrom >= '${fromDate}' AND ActiveFrom <= '${toDate}'`
        let totalTripQ = `SELECT DeviceId, COUNT(DeviceId) AS toalTrips FROM tripdataset WHERE DeviceId = '${busId}' AND StartDateTime >= '${fromDate}' AND StopDateTime <= '${toDate}' GROUP BY DeviceId`
        // var [BustotalDistance, meta] = await db.query(queryTotalDis, {});
        var [BusAvgSpeed, meta] = await db.query(queryAvgSpeed, {});
        var [BusFuelUsed, meta] = await db.query(queryFuelUsed, {});
        var [BusIdlingTime, meta] = await db.query(queryIdlingTime, {});
        var [totalTrip, meta] = await db.query(totalTripQ, {});
        let totalDistanceTravelled = 0
        // BustotalDistance = BustotalDistance[0] ? BustotalDistance[0] : []


        BusAvgSpeed = BusAvgSpeed[0] ? BusAvgSpeed[0].AverageSpeed : ''
        // BusFuelUsed = BusFuelUsed[0] ? BusFuelUsed[0].FuelUsed : ''
        BusIdlingTime = BusIdlingTime[0] ? BusIdlingTime[0].IdlingDuration : ''
        totalTrip = totalTrip[0] ? totalTrip[0] : []

        let calls = [
            ['Get',
                {
                    typeName: 'LogRecord',
                    search: {
                        fromDate: fromDate,
                        ToDate: toDate,
                        deviceSearch: { id: busId }
                    }
                }
            ],
            ['Get', {
                typeName: 'StatusData',
                search: {
                    fromDate: fromDate,
                    ToDate: toDate,
                    deviceSearch: { id: busId },
                    diagnosticSearch: {
                        id: "DiagnosticOdometerId"
                    },
                }
            }],
        ];
        console.time('test');
        await api.multiCall(calls).then(data => {
            let BustotalDistance = data[1]
            console.log(BustotalDistance.length)
            if (BustotalDistance.length > 1) {
                let first = BustotalDistance[0].data
                let last = BustotalDistance[BustotalDistance.length - 1].data
                console.log(first, last)
                totalDistanceTravelled = last - first
            }

            console.timeEnd('test');
            let totalRecords = Math.floor(data[0].length / 100);
            let tracedRecords = [];
            if (totalRecords >= 2) {
                // trim records
                data[0].forEach((val, key) => {
                    if (key % totalRecords == 0) {
                        tracedRecords.push({
                            ...val,
                            // "dateTime_utc": val.dateTime,
                            "dateTime": moment(val.dateTime).tz(config.timeZone.africaCairo).format(config.dateFormat.powerBi),
                        })
                    }
                })

            } else {
                data[0].forEach((val, key) => {
                    tracedRecords.push({
                        ...val,
                        // "dateTime_utc": val.dateTime,
                        "dateTime": moment(val.dateTime).tz(config.timeZone.africaCairo).format(config.dateFormat.powerBi),
                    })
                })
            }

            let fuelUsed = 0
            if (BusFuelUsed.length >= 2) {
                fuelUsed = BusFuelUsed[BusFuelUsed.length - 1].FuelUsed - BusFuelUsed[0].FuelUsed
            }
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Bus exceptions data fetched successfully",
                    status: 1,
                    results: {
                        trace: tracedRecords,
                        info: {
                            0: data[0].length,
                            1: totalRecords
                        },
                        otherDetails: {
                            BustotalDistance: Number(totalDistanceTravelled / 1000),
                            BusAvgSpeed: BusAvgSpeed != null ? BusAvgSpeed : 0,
                            BusFuelUsed: fuelUsed,
                            BusIdlingTime,
                            totalTrips: totalTrip && totalTrip.toalTrips ? totalTrip.toalTrips : 0
                        }
                    }
                }, null, 2)
            })
        }).catch(error => {
            let err = 'An internal server error occured'
            console.log(error)
            if (error.message && errorMessages[error.message]) {
                err = errorMessages[error.message]
            } else {
                err = error.message
            }
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: err,//error.message ? error.message : "An internal server error occured",
                    //err: error,
                    status: 0,
                    results: [],
                })
            })
        });
    } catch (err) {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: err.message ? err.message : "An Internal server error occured",
                status: 0,
                results: [],
            })
        })
    }
};

module.exports.getDriverRatings = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    let auth = await utils.checkAuth(event.headers, callback)

    var config = require('../../config/config.json');
    moment.tz.setDefault(config.timeZone.africaCairo);
    var toDate = moment().format("YYYY-MM-DD");
    var fromDate = moment().add(-30, 'days').format("YYYY-MM-DD");

    let error = {};

    if (true) {
        let getCountQuery = `SELECT DeviceId, COUNT(_id) AS count FROM exceptioneventdataset WHERE createdAt >= '${fromDate}' GROUP BY DeviceId`
        var [getExceptionCounts, meta] = await db.query(getCountQuery, {
            raw: true,
        })

        let totalExceptions = 0
        const totalDevice = getExceptionCounts.length
        let deviceRating = {}
        getExceptionCounts.forEach(element => {
            totalExceptions += element.count
            deviceRating[element.DeviceId] = element.count
        });

        const avg = totalExceptions / totalDevice
        const percentile = avg / 5

        let outOf = [0, 0, 0, 0, 0]

        outOf.forEach((element, index) => {
            let num = avg - (index * percentile)
            outOf[index] = num
        });

        getExceptionCounts.forEach((element, index) => {
            let count = element.count
            let rating = outOf.filter(elem => count <= elem).length
            deviceRating[element.DeviceId] = rating
        });
        console.log(toDate, fromDate)

        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Driver Ratings fetched successfully",
                timePeriod: {
                    fromDate,
                    toDate
                },
                err: {},
                status: 1,
                results: {
                    deviceRating,
                    stats: {
                        totalExceptions,
                        avg
                    }
                },
            })
        })



    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }
}

module.exports.getAllStaticDetailsByUser = async(event, context,callback)=>{
    context.callbackWaitsForEmptyEventLoop = false;
    let auth = await utils.checkAuth(event.headers, callback)
    try {
        if(auth.role === 'ADMIN'){
            const result = await userAdminStaticModel.findOne({
                where:{userAdmin_id:auth.userId},
                attributes:['headerText','headerColor','legendBackground','busInfoBackground','logo'],
                raw:true
            });
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "static Details fetched successfully",
                    err: {},
                    status: 1,
                    results: result
                })
            })
        }
    } catch (error) {
        callback(null, {
            statusCode: 400,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Not available",
                err: error,
                status: 0,
                results: [],
            })
        })
    }
  
}

module.exports.updateStaticDetailsByUser = async(event,context,callback)=>{
    context.callbackWaitsForEmptyEventLoop = false;
    let requestBody = JSON.parse(event.body)
    try {
        let auth = await utils.checkAuth(event.headers, callback)
        if(auth.role === 'ADMIN'){
            let userDetailsExist;
            userDetailsExist = await userAdminStaticModel.findOne({where:{userAdmin_id:auth.userId},raw:true});
            if(userDetailsExist){
                console.log(JSON.parse(event.body))
                let updatedStaticData = await userAdminStaticModel.update(requestBody,{ where: {userAdmin_id: auth.userId}})
                    userDetailsExist = await userAdminStaticModel.findOne({where:{userAdmin_id:auth.userId},raw:true});
                    callback(null, {
                        statusCode: 200,
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        },
                        body: JSON.stringify({
                            msg: "Static details updated successfully",
                            err: {},
                            status: 1,
                            results: userDetailsExist
                        })
                    })
                } 
        }
    } catch (error) {
        callback(null, {
            statusCode: 400,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg:error.message,
                err: error,
                status: 0,
                results: [],
            })
        })
    }

}