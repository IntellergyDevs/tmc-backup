var main = require('./main')
const querystring = require('querystring');
const routesModel = require('../../models/Routes.model');
const tripModel = require('../../models/TripDataSet.model');
const db = require('../../config/db.sequelize');

var config = require('../../config/config.json');
const moment = require('moment');

const { Op } = require("sequelize");
const NodeGeocoder = require('node-geocoder');
const options = {
    provider: 'google',
    apiKey: config.google.map, // for Mapquest, OpenCage, Google Premier
    formatter: null // 'gpx', 'string', ...
};
const geocoder = NodeGeocoder(options);

module.exports.getAll = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    let req = querystring.parse(event.body);
    let error = {};
    let limit = req.limit ? Number(req.limit) : 20;
    let page = 0;
    if (req != null && req.page != null) {
        page = 0 + Number(req.page) * limit || 0;
    }

    let sortBy = req != null && req.sort_by != null && req.sort_by != '' ? req.sort_by : 'id';
    let sortOrder = req != null && req.sort_order != null && req.sort_order != '' ? req.sort_order : 'ASC';

    let search = {};

    if (req.routeAllocation) {
        search['RouteAllocation'] = {
            [Op.eq]: req.routeAllocation
        }
    } else {
        error['routeAllocation'] = "Route Allocation cannot be empty"
    }

    if (req.userLat && req.userLng) {

    } else {
        error['Location'] = "Location cannot be empty"
    }
    if (req.Date && req.Time) { // For Date
        let datetime = moment(req.Date + " " + req.Time, config.dateFormat.ApiBusFormat).format(config.dateFormat.powerBi);
        // search['StartDateTime'] = {
        //     [Op.eq]: datetime
        // }
    } else {
        error['DateTime'] = "Date Time cannot be empty"
    }
    if (Object.keys(error).length == 0) {
        var [results, metadata] = await db.query("SELECT StopPointX, StopPointY, DeviceId FROM tripdataset GROUP BY DeviceId", {
            raw: true,
        });
        let coords = {};

        await results.forEach(function (record, index) {
            coords[record.DeviceId] = record
        })

        var [routeTimings, meta] = await db.query("SELECT id,time FROM routetimings WHERE routeAllocationName = '" + req.routeAllocation + "'", {
            raw: true,
        });

        var timings = {};

        await routeTimings.forEach(function (record, index) {
            timings[record.id] = record.time
        })


        await routesModel.findAndCountAll({
            raw: true,
            limit: limit,
            offset: page,
            where: search,
            order: [
                [sortBy, sortOrder],
            ],
        }).then(async function (records) {
            let resRecords = records.rows;

            var resultsFiltered = [];
            records.rows.forEach(function (record, index) {
                let points = coords[record.BusId];
                console.log(points)
                resRecords[index].distanceFromUser = main.calcCrow(req.userLat, req.userLng, points.StopPointY, points.StopPointX).toFixed(5);
                resRecords[index].routeTimings = timings;
                if (resRecords[index].distanceFromUser <= 5) {
                    resultsFiltered.push(resRecords[index])
                }
                console.log(resRecords[index].distanceFromUser);
            })

            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: resultsFiltered.length == 0 ? "No Buses found" : "Records fetched successfully",
                    err: {},
                    status: 1,
                    results: resultsFiltered,
                })
            })
        }).catch(function (err) {
            callback(err)
        });
    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }


};

module.exports.getAllRoutes = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    let search = {};
    search['isActive'] = {
        [Op.eq]: 1
    }

    //const routesModel = require('../../models/Routes.model');
    await routesModel.findAndCountAll({
        raw: true,
        where: search,
        attributes: ['id', 'RouteAllocation', 'routeStart', 'routeEnd'],
        group: ['routeStart', 'routeEnd'],
    }).then(function (records) {

        let startRoutes = [];
        let allRoutes = {};
        let allRoutesSend = [];

        records.rows.forEach(function (route, index) {
            if (startRoutes.indexOf(route.routeStart) === -1) {
                startRoutes.push(route.routeStart);
                allRoutes[route.routeStart] = [];
            }
        })
        records.rows.forEach(function (route, index) {
            allRoutes[route.routeStart].push({
                "routeEnd": route.routeEnd,
                "allocation": route.RouteAllocation,
            });
            
        })
        Object.keys(allRoutes).forEach(function (route, index) {
            allRoutesSend.push(allRoutes[route]);  
        })
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Records fetched successfully",
                err: {},
                status: 1,
                results: {
                    "startUniqueRoutes": startRoutes,
                    "allRoutes": allRoutesSend,
                },
            })
        })
    }).catch(function (err) {
        callback(err)
    });


};