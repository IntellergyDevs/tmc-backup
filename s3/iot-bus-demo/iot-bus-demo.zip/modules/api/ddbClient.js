const REGION = "af-south-1";
const { DynamoDBClient } = require("@aws-sdk/client-dynamodb")
const AWS = require("aws-sdk")
AWS.config.update({ region: REGION })
const dynamoDB = new AWS.DynamoDB.DocumentClient()

const ddbClient = new DynamoDBClient({ region: REGION });
module.exports = { ddbClient, dynamoDB };
