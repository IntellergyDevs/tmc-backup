const querystring = require('querystring');
const UserAdminModel = require('../../models/UserAdmin.model');
const db = require('../../config/db.sequelize');
const bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
const JWT_SECRET_KEY = "aGPuWz7Q3V2mJMBqixCL"
var config = require('../../config/config.json');
const utils = require('./common/utils')
const distanceCalc = require('./common/distanceCalculator')
const jwt_decode = require('jwt-decode');
const distanceHelper = require('./common/distanceCalculator')
const Stops = require('../../enums/stop');
const moment = require('moment');

module.exports.userGetStaticDetails = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        // const req = JSON.parse(event.body);
        let auth = await utils.checkAuth(event.headers, callback)
        let user = jwt_decode(event.headers.Authorization.split(' ')[1]);

        // get routes
        let busRoutes
        var responseStops = [];
        let landmarks
        let responseLandmarksStops = [];
        if (user.associatedRoutes) {
            let parsedRoutes = user.associatedRoutes
            let sts = parsedRoutes.map(id => "'" + id + "'").join()

            let queryforStops = `SELECT B.id, A.centerPoint, A.name as Landmark, B.name, A.Latitude AS landmarkLat, A.Longitude AS landmarkLong, B.Latitude AS surroundLat, B.Longitude AS surroundLong, associatedRoutes FROM stopsLandmarks A LEFT JOIN stopsSurroundingStops B ON A.id = B.landmarkId WHERE A.name = '${user.associatedStation}'`;
            let queryforFullPath = `SELECT id, name, colorScheme, landmarkId, Latitude, Longitude FROM stopsFullPath WHERE name IN (${sts})`

            let busRoutes = db.query(`SELECT * FROM stoplocations_react WHERE routeAllocationName IN (${sts})`, {
                nest: true
            });
            const stopsAndLandmarks = db.query(queryforStops, {
                nest: true
            });

            let fullPath = db.query(queryforFullPath, {
                nest: true
            });

            await Promise.all([busRoutes, stopsAndLandmarks, fullPath]).then((values) => {
                let records = values[0]
                let landmarksRaw = values[1]
                let fullPath = values[2]
                let fullPathLocation = {};

                fullPath.forEach(element => {
                    if (typeof (fullPathLocation[element.name]) === 'undefined') {
                        fullPathLocation[element.name] = [];
                    }
                    fullPathLocation[element.name].push({
                        id: element.id,
                        latitude: Number(element.Latitude),
                        longitude: Number(element.Longitude),
                    })
                });
                let stopLocations = {};
                records.forEach(element => {
                    if (typeof (stopLocations[element.routeAllocationName]) === 'undefined') {
                        stopLocations[element.routeAllocationName] = {};
                        stopLocations[element.routeAllocationName]['id'] = element.routeAllocationName;
                        stopLocations[element.routeAllocationName]['name'] = element.routeAllocationName;
                        stopLocations[element.routeAllocationName]['routeStops'] = [];
                        stopLocations[element.routeAllocationName]['routeCoordinates'] = fullPathLocation[element.routeAllocationName] ? fullPathLocation[element.routeAllocationName] : []
                        stopLocations[element.routeAllocationName]['colorScheme'] = "#" + element.colorScheme;
                    }
                    stopLocations[element.routeAllocationName].routeStops.push({
                        message: element.StopNumber,
                        id: element.id,
                        longitude: Number(element.PointX),
                        latitude: Number(element.PointY),
                    })
                });
                Object.keys(stopLocations).forEach(element => {
                    responseStops.push(stopLocations[element]);
                });
                landmarks = landmarksRaw.filter((item, index, objects) => {
                    if (index === 0) {
                        return item
                    } else if (item.Landmark !== objects[index - 1].Landmark) {
                        return {
                            "name": item.Landmark,
                            "latitude": Number(item.landmarkLat),
                            "longitude": Number(item.landmarkLong),
                            "associatedRoutes": item.associatedRoutes,
                            "centerPoint": item.centerPoint,
                        };
                    }
                }).map(function (item) {
                    return {
                        "name": item.Landmark,
                        "latitude": Number(item.landmarkLat),
                        "longitude": Number(item.landmarkLong),
                        "associatedRoutes": JSON.parse(item.associatedRoutes),
                        "centerPoint": JSON.parse(item.centerPoint),
                    };
                });

                let landmarksWithStops = landmarksRaw.filter(({ id }) => id != null).map(function (item) {
                    return {
                        "Landmark": item.Landmark,
                        "name": item.name,
                        "latitude": Number(item.surroundLat),
                        "longitude": Number(item.surroundLong),
                        // "centerPoint": JSON.parse(item.centerPoint),
                    };
                }).reduce((r, a) => {
                    r[a.Landmark] = [...r[a.Landmark] || [], a];
                    return r;
                }, {});

                Object.keys(landmarksWithStops).forEach((element, key) => {
                    responseLandmarksStops.push({
                        id: element,
                        name: element,
                        routeCoordinates: landmarksWithStops[element]
                    })
                });
                responseLandmarksStops.forEach((element, index) => {
                    let landmark = landmarks.filter(lm => lm.name == element.name)

                    responseLandmarksStops[index]['associatedRoutes'] = landmark && landmark[0] && landmark[0].associatedRoutes ? landmark[0].associatedRoutes : []
                })
            })
        }
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Data fetched successfully",
                status: 1,
                results: {
                    routes: responseStops,
                    landmarks: {
                        landmarkStops: landmarks, // main station points
                        landmarkAreaCoordinates: responseLandmarksStops, // all polygon,
                        centerPoint: landmarks && landmarks[0] && landmarks[0].centerPoint ? landmarks[0].centerPoint : null
                    }
                }
            }, null, 2)
        })

    } catch (err) {
        console.log(err)
        callback(null, {
            statusCode: 401,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: err.message,
                err: err.message,
                status: 0,
                results: [],
            })
        })
    }
}

module.exports.getBusesStationEtaData_1 = async (event, context, callback) => {
    try {
        const geolib = require('geolib');
        const routeDeterminationModel = require('../../models/routeDetermination.model');

        context.callbackWaitsForEmptyEventLoop = false;
        let auth = await utils.checkAuth(event.headers, callback)
        let user = jwt_decode(event.headers.Authorization.split(' ')[1]);

        let parsedRoutes = user.associatedRoutes
        if (!user.associatedRoutes) {
            throw new Error('You are not authorized to access that location')
        }
        let routesStopsUser = parsedRoutes.map(id => "'" + id + "'").join()

        let getStopsForStationQuery = `SELECT id, routeAllocationName,StopNumber, PointX, PointY,sequence FROM stoplocations_react WHERE include = 1 AND routeAllocationName IN (${routesStopsUser})`
        const p1 = db.query(getStopsForStationQuery, {
            raw: true,
        })

        let getPolygonsQuery = `SELECT name, landmarkId,Latitude,Longitude FROM stopsSurroundingStops WHERE name = '${user.associatedStation}'`
        const p2 = db.query(getPolygonsQuery, {
            raw: true,
        })

        let getDeviceInfoQuery = `SELECT latitude,longitude,routeDetermination.isBusInStation AS isBusInStation, routeDetermination.pastList AS pastList,currentRouteDetermined, routeDetermination.deviceId FROM deviceStatusInfo LEFT JOIN routeDetermination ON deviceStatusInfo.deviceId = routeDetermination.deviceId`
        const p3 = db.query(getDeviceInfoQuery, {
            raw: true,
        })

        let getBoundary = `SELECT stationBoundary FROM stopsLandmarks WHERE name = '${user.associatedStation}'`
        const p4 = db.query(getBoundary, {
            raw: true,
        })

        let stopsObj = {}
        let polygonArray = []
        let busesInPolygon = {}
        await Promise.all([p1, p2, p3, p4]).then(async (values) => {
            let stops = values[0][0]
            let polygons = values[1][0]
            let deviceInfo = values[2][0]
            let Boundary = values[3][0]

            Boundary = Boundary[0] && Boundary[0].stationBoundary ? JSON.parse(Boundary[0].stationBoundary) : Boundary
            polygons.forEach(element => {
                polygonArray.push({
                    latitude: element.Latitude,
                    longitude: element.Longitude,
                })
            });

            stops.forEach(element => {

                if (!stopsObj[element.routeAllocationName]) {
                    stopsObj[element.routeAllocationName] = {}
                    stopsObj[element.routeAllocationName]['stops'] = []
                }
                stopsObj[element.routeAllocationName]['stops'].push({
                    StopNumber: element.StopNumber,
                    latitude: element.PointY,
                    longitude: element.PointX,
                    sequence: element.sequence,
                })
            });
            var updateRouteDeterminationObj = []

            deviceInfo.forEach((bus, index) => {
                const inBoundary = geolib.isPointInPolygon({ latitude: bus.latitude, longitude: bus.longitude }, Boundary);
                if (inBoundary) {
                    busesInPolygon[bus.deviceId] = {}
                    busesInPolygon[bus.deviceId]['stops'] = []
                    busesInPolygon[bus.deviceId]['route'] = bus.currentRouteDetermined
                    busesInPolygon[bus.deviceId]['location'] = {
                        latitude: bus.latitude,
                        longitude: bus.longitude,
                    }
                    let az = stopsObj[bus.currentRouteDetermined]['stops'][0]
                    bus.pastList = [
                        az.sequence + 1,
                        az.sequence + 2,
                        az.sequence + 3,
                    ]
                    updateRouteDeterminationObj.push({
                        deviceId: bus.deviceId,
                        isBusInStation: 1,
                        pastList: JSON.stringify(bus.pastList),
                    })

                } else {
                    const isPointInPolygon = geolib.isPointInPolygon({ latitude: bus.latitude, longitude: bus.longitude }, polygonArray);
                    if (isPointInPolygon) {

                        busesInPolygon[bus.deviceId] = {}
                        busesInPolygon[bus.deviceId]['stops'] = []
                        busesInPolygon[bus.deviceId]['route'] = bus.currentRouteDetermined
                        busesInPolygon[bus.deviceId]['location'] = {
                            latitude: bus.latitude,
                            longitude: bus.longitude,
                        }

                        let distances = []
                        stopsObj[bus.currentRouteDetermined]['stops'].forEach(element => {
                            const disBetweenBusAndStop = geolib.getDistance(
                                element,
                                bus
                            );
                            distances.push({
                                ...element,
                                d: disBetweenBusAndStop

                            })
                        });
                        distances.sort(function (a, b) {
                            if (a.d < b.d) return -1;
                            if (a.d > b.d) return 1;
                            return 0;
                        });


                        let Nearest = distances[0]
                        let SNearest = distances[1]
                        let nearest

                        bus.pastList = bus.pastList ? JSON.parse(bus.pastList) : []
                        if (bus.pastList.includes(Nearest.sequence)) {
                            // nearest
                            nearest = Nearest
                        } else if (bus.pastList.includes(SNearest.sequence + 1)) {
                            // second nearest
                            nearest = SNearest
                        } else {
                            nearest = Nearest
                        }


                        bus.pastList = [
                            Nearest.sequence + 1,
                            Nearest.sequence + 2,
                            Nearest.sequence + 3,
                        ]

                        updateRouteDeterminationObj.push({
                            deviceId: bus.deviceId,
                            pastList: JSON.stringify(bus.pastList),
                            isBusInStation: 0
                        })
                        busesInPolygon[bus.deviceId]['nearest'] = nearest

                        let i = 0
                        let stopsCount = 0
                        let Firstindex = stopsObj[bus.currentRouteDetermined]['stops'].findIndex(val => val.StopNumber == nearest['StopNumber'])

                        while (i < 3) {
                            if (stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount]) {
                                busesInPolygon[bus.deviceId]['stops'].push({
                                    StopNumber: stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount].StopNumber,
                                    latitude: stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount].latitude,
                                    longitude: stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount].longitude
                                })
                            }
                            i++;
                            stopsCount++;
                        }

                        busesInPolygon[bus.deviceId]['stops'].forEach(async (stopElement, index) => {
                            let getDistance
                            if (index == 0) {
                                getDistance = distanceHelper.distanceBetweenTwoPoints(bus.latitude, bus.longitude, stopElement.latitude, stopElement.longitude, "K")

                            } else {
                                let prevElement = busesInPolygon[bus.deviceId]['stops'][index - 1]
                                getDistance = distanceHelper.distanceBetweenTwoPoints(prevElement.latitude, prevElement.longitude, stopElement.latitude, stopElement.longitude, "K")
                            }

                            // const speed = 20//kmph
                            let getBusSpeed = `SELECT * FROM logrecorddataset where DeviceId = '${bus.deviceId}' order by createdAt DESC`;
                            let speed = await db.query(getBusSpeed, {
                                raw: true,
                            });
                            speed = speed[0].speed;
                            let durationInSecs = getDistance / speed
                            duration = distanceCalc.secondsToHms(durationInSecs * 3600)// secs

                            busesInPolygon[bus.deviceId]['stops'][index]['distance'] = {
                                km: getDistance.toFixed(2),
                                m: (getDistance / 1000).toFixed(2)
                            }
                            busesInPolygon[bus.deviceId]['stops'][index]['eta'] = {
                                text: duration,
                                seconds: Number(durationInSecs * 3600).toFixed(2)
                            }
                        });

                    }
                }

            });


            await routeDeterminationModel.bulkCreate(updateRouteDeterminationObj, {
                updateOnDuplicate: ['pastList', 'isBusInStation']
            }).then(function () {
                console.log('then b sequelize');
                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "Bus data fetched successfully",
                        status: 1,
                        results: {
                            busesInPolygon,
                        }
                    }, null, 2)
                })
            }).catch(function (err) {
                console.log(err);
                callback(null, {
                    statusCode: 404,
                    error: 1,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    msg: "Error Occured"
                });
            });
        });
        console.log('req end')
    } catch (err) {
        console.log(err)
        callback(null, {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Internal server error occured",
                err: err.message,
                status: 0,
                results: [],
            })
        })
    }
}

module.exports.getBusesStationEtaData = async (event, context, callback) => {
    try {
        context.callbackWaitsForEmptyEventLoop = false;
        let user = await utils.checkAuth(event.headers, callback)
        // let user = jwt_decode(event.headers.Authorization.split(' ')[1]);
        // console.log('user associatedRoutes', user);
        const responseBusRecords = await getBusRecord(user);

        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Bus data fetched successfully",
                status: 1,
                results: {
                    busesInPolygon: responseBusRecords,
                }
            }, null, 2)
        })
    } catch (err) {
        console.log(err)
        callback(null, {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Internal server error occured",
                err: err.message,
                status: 0,
                results: [],
            })
        })
    }
}

function getDistance1(obj){
    return (obj.distanceMeters / 1000);
 }

function getEndDistance(obj){
  return (obj.distanceFromStation / 1000);
}

async function getBusRecord(user) {
    const geolib = require('geolib');
  
    let location;
    let parsedRoutes = user.associatedRoutes
    if (!user.associatedRoutes) {
        throw new Error('You are not authorized to access that location')
    }
    if (user.associatedStation) {
        location = user.associatedStation.toLowerCase();
    }
    let routesStopsUser = parsedRoutes.map(id => "'" + id + "'").join()
  
    let getStopsForStationQuery = `SELECT id, routeAllocationName,StopNumber, PointX, PointY,sequence, colorScheme FROM stoplocations_react WHERE include = 1 AND routeAllocationName IN (${routesStopsUser})`
    const p1 = db.query(getStopsForStationQuery, {
        raw: true,
    })

    let getPolygonsQuery = `SELECT name, landmarkId,Latitude,Longitude FROM stopsSurroundingStops WHERE name = '${user.associatedStation}'`
    const p2 = db.query(getPolygonsQuery, {
        raw: true,
    })

    let getDeviceInfoQuery = `SELECT currentStation,isRouteReset,latitude,longitude,routeDetermination.isBusInStation AS isBusInStation, routeDetermination.pastList AS pastList,device.isActive AS isActive,currentRouteDetermined, routeDetermination.deviceId, routeDetermination.deviceName, deviceStatusInfo.currentStateDuration FROM deviceStatusInfo LEFT JOIN routeDetermination ON deviceStatusInfo.deviceId = routeDetermination.deviceId LEFT JOIN device ON device.id = deviceStatusInfo.deviceId WHERE device.isActive = 1`
    const p3 = db.query(getDeviceInfoQuery, {
        raw: true,
    })

    let getBoundary = `SELECT stationBoundary FROM stopsLandmarks WHERE name = '${user.associatedStation}'`
    const p4 = db.query(getBoundary, {
        raw: true,
    })

    let getAllGraphLocs = `SELECT start, end, routeAllocationName,distanceMeters, distanceFromStation FROM trainGraphLocations_new`
    const p5 = db.query(getAllGraphLocs, {
        raw: true,
    })
  
    let stopsObj = {};
    let polygonArray = [];
    let busesInPolygon = {};
  
    const values = await Promise.all([p1, p2, p3, p4, p5]);
    let stops = values[0][0]
    let polygons = values[1][0]
    let deviceInfo = values[2][0]
    let Boundary = values[3][0]
    let trainGraphs = values[4][0]
    let uniqueStops = []
  
    //inserting stops
    for (let stop of stops) {
        if (!stopsObj[stop.routeAllocationName]) {
            stopsObj[stop.routeAllocationName] = {}
            stopsObj[stop.routeAllocationName]['stops'] = []
            stopsObj[stop.routeAllocationName]['color'] = stop.colorScheme
            uniqueStops.push(stop.routeAllocationName)
        }
        stopsObj[stop.routeAllocationName]['stops'].push({
            StopNumber: stop.StopNumber,
            latitude: stop.PointY,
            longitude: stop.PointX,
            sequence: stop.sequence,
        });
    }
  
    let responseBusRecords = [];
    let hasRouteAllocated = [];
    for (let bus of deviceInfo) {
        if (user.associatedRoutes.includes(bus.currentRouteDetermined)) {
            let busRecord = {};
            hasRouteAllocated.push(bus.currentRouteDetermined);
            let isDeviated = false;
  
            //check if bus is in polygon
            const isInPoly = geolib.isPointInPolygon({ latitude: bus.latitude, longitude: bus.longitude }, polygons) ? 1 : 0;
            if (!isInPoly) {
                isDeviated = true;
            }
  
            //inserting bus data into new busRecord object
            busRecord['locationName'] = location;
            busRecord['deviceId'] = bus.deviceId;
            busRecord['deviceName'] = bus.deviceName;
            busRecord['stops'] = [];
            busRecord['isDeviated'] = isDeviated;
            busRecord['route'] = {
                name: bus.currentRouteDetermined,
                color: stopsObj[bus.currentRouteDetermined]['color'] ? `#${stopsObj[bus.currentRouteDetermined]['color']}` : ''
            }
            busRecord['location'] = {
                latitude: bus.latitude,
                longitude: bus.longitude
            }
  
            //proceed only if bus is not at station
            if (bus.isBusInStation == 0) {
                let currentStation;
                let foundCurrentStationDistance;
                let remainingDistanceFromCurrentStopInSecs = 0;
                let coveredDistanceFromCurrentStopInSecs = 0;
                let speed = 20; //kmph
                let getCurrentBusSpeed = `SELECT * FROM logrecorddataset where DeviceId = '${bus.deviceId}' order by createdAt DESC`;
                let busSpeedResult = await db.query(getCurrentBusSpeed, {
                    raw: true,
                });
                
                // speed = busSpeedResult[0][0].Speed;
                // if (speed <= 0) speed = 20;

                speed = busSpeedResult[0][0].Speed;
                if (speed <= 20) speed = 20;
  
                if (stopsObj[bus.currentRouteDetermined]['stops'] && stopsObj[bus.currentRouteDetermined]['stops'].length > 0) {
                    // sort the array by sequence
                    await stopsObj[bus.currentRouteDetermined]['stops'].sort((a, b) => a.sequence - b.sequence);
                    let duplicateBusStand = {
                        "StopNumber": stopsObj[bus.currentRouteDetermined]['stops'][0].StopNumber,
                        "latitude": stopsObj[bus.currentRouteDetermined]['stops'][0].latitude,
                        "longitude": stopsObj[bus.currentRouteDetermined]['stops'][0].longitude,
                        "sequence": stopsObj[bus.currentRouteDetermined]['stops'][stopsObj[bus.currentRouteDetermined]['stops'].length - 1].sequence + 1,
                        "duplicate": true
                    };
                    stopsObj[bus.currentRouteDetermined]['stops'].push(duplicateBusStand);
                    let Firstindex = stopsObj[bus.currentRouteDetermined]['stops'].findIndex(val => val.StopNumber == bus['currentStation']);
                    if (Firstindex !== -1) {
                        // remove stops that bus has passed
                        let filterStops = [...stopsObj[bus.currentRouteDetermined]['stops']];
                        filterStops = filterStops.splice(Firstindex);
  
                        if (filterStops && filterStops.length > 0) {
                            // get currentStation
                            currentStation = filterStops[0];
                            // console.log('currentStation', currentStation);
  
                            //getting current station distance from DB
                            foundCurrentStationDistance = trainGraphs.find(rec => rec.start == currentStation.StopNumber);
  
                            // get only 3 stops, remove rest
                            let nextStops = filterStops.slice(0, 4);
  
                            //inserting stop details into stops array of busRecord
                            if (nextStops && nextStops.length > 0) {
                                for (let nextStop of nextStops) {
                                    busRecord['stops'].push({
                                        StartStopName: Stops[nextStop.StopNumber],
                                        StartStopNumber: nextStop.StopNumber,
                                        latitude: nextStop.latitude,
                                        longitude: nextStop.longitude,
                                        sequence: nextStop.sequence
                                    })
                                }
                            }
                        }
                    }
                }
                let index = 0;
                let distanceArr = [...trainGraphs].filter(x => x.routeAllocationName == bus.currentRouteDetermined);
                if(busRecord['stops'].length > 0){
                for (let stopElement of busRecord['stops']) {
                    //getting next stop of current stop
                    let found = trainGraphs.find(rec => rec.start == stopElement.StartStopNumber);
  
                    busRecord['stops'][index]['EndStopNumber'] = found['end'];
                    busRecord['stops'][index]['EndStopName'] = Stops[found['end']];
  
                    //calculating next bus stop
                    let nextStop;
                    let firstStopObj;
                    if (busRecord['stops'].length == 1) {
                        nextStop = busRecord['stops'][index];
                        firstStopObj = busRecord['stops'][0];
                    } else {
                        nextStop = busRecord['stops'][index + 1];
                        firstStopObj = busRecord['stops'][1];
                    }
  
  
                    if (nextStop) {
                        //calculating distance between two locations
                        let remainingDistanceFromCurrentStop = await distanceHelper.distanceBetweenTwoPoints(bus.latitude, bus.longitude, firstStopObj.latitude, firstStopObj.longitude, "K");
                        if(index > 0){
                            const countIndex = busRecord['stops'][0].sequence;
                            let _distance = 0;
                            for(let i = 0; i < index; i++) {    
                                let _d = getDistance1(distanceArr[countIndex + i]);
                                _distance = _distance + _d;
                            }
                            remainingDistanceFromCurrentStop = remainingDistanceFromCurrentStop + _distance;
                        }
  
                        //Calculating distance in seconds
                        remainingDistanceFromCurrentStopInSecs = remainingDistanceFromCurrentStop / speed;
  
                        let getDistance;
                        // getDistance = (found.distanceMeters / 1000); //distance in KM
                        getDistance = remainingDistanceFromCurrentStop; //distance in KM
  
                        let durationInSecs = getDistance / speed;
                        let duration = distanceCalc.secondsToHms(durationInSecs * 3600) //secs
                        console.log(`from bus to ${nextStop.StartStopNumber} in seconds => ${durationInSecs * 3600} => ${duration} inserting in ${busRecord['stops'][index].StartStopNumber}`);;
  
                        //inserting distance in km and m
                        busRecord['stops'][index]['distance'] = {
                            km: getDistance.toFixed(2),
                            m: (getDistance * 1000).toFixed(2)
                        }
  
                        // inserting ETA
                        busRecord['stops'][index]['eta'] = {
                            text: duration,
                            timestamp: moment().add(Number(durationInSecs * 3600), 'seconds').unix(),
                            time: moment().add(Number(durationInSecs * 3600), 'seconds').utcOffset('+0200').format('h:mm A'),
                            seconds: Number(durationInSecs * 3600).toFixed(2),
                            currentTimeStamp: moment().add(Number(remainingDistanceFromCurrentStopInSecs * 3600), 'seconds').unix(),
                            currentTime: moment().add(Number(remainingDistanceFromCurrentStopInSecs * 3600), 'seconds').utcOffset('+0200').format('h:mm A'),
                            currentSeconds: Number(remainingDistanceFromCurrentStopInSecs * 3600).toFixed(2)
                        }
                        
                        coveredDistanceFromCurrentStopInSecs = (durationInSecs * 3600) - (remainingDistanceFromCurrentStopInSecs * 3600);
                    }
                    index++;
                }
                }
                
                if (busRecord['stops'].length > 1) busRecord['stops'].splice(busRecord['stops'].length - 1, 1);
                if (busRecord['stops'].length > 1) busRecord['stops'] = busRecord['stops'].filter((stop) => Number(stop.distance.m) >= Number(busRecord['stops'][0].distance.m));
                // last stop eta
                stopsObj[bus.currentRouteDetermined]['stops'] = stopsObj[bus.currentRouteDetermined]['stops'].filter(x => !x['duplicate']);
                let isLastIndex = busRecord['stops'].findIndex(x => x.sequence == stopsObj[bus.currentRouteDetermined]['stops'].length);
                if(isLastIndex == -1 && busRecord['stops'].length > 1){
                let endStopObj = {
                    StartStopName: busRecord['stops'][0].StartStopName,
                    StartStopNumber: busRecord['stops'][0].StopNumber,
                    latitude: busRecord['stops'][0].latitude,
                    longitude: busRecord['stops'][0].longitude,
                    EndStopNumber: 'end',
                    EndStopName: Stops[`${location[0].toUpperCase()}${location.slice(1)} End`]
                  }
                  let distanceTofirstStop = busRecord['stops'][0].distance.km;
                  let _d = getEndDistance(distanceArr[busRecord['stops'][0].sequence]);
                  let remainingDistanceFromCurrentStop = Number(distanceTofirstStop) + Number(_d);
                  
                  let remainingDistanceFromCurrentStopInSecs = 0;
                  remainingDistanceFromCurrentStopInSecs = remainingDistanceFromCurrentStop / speed;
                  
                  let getDistance;
                  getDistance = remainingDistanceFromCurrentStop; //distance in KM
  
                  let durationInSecs = getDistance / speed;
                  let duration = distanceCalc.secondsToHms(durationInSecs * 3600) //secs
                  
  
                  //inserting distance in km and m
                  endStopObj['distance'] = {
                      km: getDistance.toFixed(2),
                      m: (getDistance * 1000).toFixed(2)
                  }
  
                  // inserting ETA
                  endStopObj['eta'] = {
                      text: duration,
                      timestamp: moment().add(Number(durationInSecs * 3600), 'seconds').unix(),
                      time: moment().add(Number(durationInSecs * 3600), 'seconds').utcOffset('+0200').format('h:mm A'),
                      seconds: Number(durationInSecs * 3600).toFixed(2),
                      currentTimeStamp: moment().add(Number(remainingDistanceFromCurrentStopInSecs * 3600), 'seconds').unix(),
                      currentTime: moment().add(Number(remainingDistanceFromCurrentStopInSecs * 3600), 'seconds').utcOffset('+0200').format('h:mm A'),
                      currentSeconds: Number(remainingDistanceFromCurrentStopInSecs * 3600).toFixed(2)
                  }
                  
                  busRecord['stops'].push(endStopObj);
                }
                
            }
            // if(busRecord['stops'] && busRecord['stops'].length > 0){
                
            // }
            responseBusRecords.push(busRecord);
            //stopsObj[bus.currentRouteDetermined]['stops'] = stopsObj[bus.currentRouteDetermined]['stops'].filter(x => !x['duplicate']);  
        }
        
    }

    responseBusRecords = responseBusRecords.sort((a,b) => b.stops.length - a.stops.length);
  
    hasRouteAllocated = [...new Set(hasRouteAllocated)]
    uniqueStops = uniqueStops.filter(function (el) {
        return !hasRouteAllocated.includes(el);
    });
  
    for (let unique of uniqueStops) {
        let index = responseBusRecords.indexOf((x) => x.deviceId == unique);
        if (index == -1) {
            let record = {
                locationName: location,
                deviceName: null,
                deviceId: null,
                stops: [],
                route: {
                    name: unique,
                    color: stopsObj[unique]['color'] ? '#' + stopsObj[unique]['color'] : ''
                }
            }
            //responseBusRecords.push(record);
        }
    }
    return responseBusRecords;
}