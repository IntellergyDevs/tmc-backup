var main = require('./main')
const querystring = require('querystring');
const db = require('../../config/db.sequelize');
var config = require('../../config/config.json');

module.exports.addContact = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    const contactsModel = require('../../models/Contacts.model');
    let req = querystring.parse(event.body);
    let error = {};

    if (!req.queryType) {
        error['queryType'] = "Query Type cannot be empty"
    }
    // if (!req.name) {
    //     error['name'] = "Name cannot be empty"
    // }
    // if (!req.emailId) {
    //     error['emailId'] = "Email cannot be empty"
    // }
    // if (!req.ticketDetails) {
    //     error['ticketDetails'] = "Ticket details cannot be empty"
    // }
    if (!req.description) {
        error['description'] = "Description cannot be empty"
    }

    try {
        if (Object.keys(error).length == 0) {
            await contactsModel.create(
                req
            ).then(function (contact) {
                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "Contact added successfully",
                        err: {},
                        status: 1,
                        results: contact,
                    })
                })
            }).catch(async function (err) {

                let errors = err.errors.map(function (record) {
                    return record.message;
                });

                console.log(errors)
                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "Validation Failed",
                        err: errors,
                        status: 0,
                        results: {},
                    })
                })
            })
        } else {
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Insufficient Data provided",
                    err: error,
                    status: 0,
                    results: {},
                })
            })
        }
    } catch (catE) {

    }

};