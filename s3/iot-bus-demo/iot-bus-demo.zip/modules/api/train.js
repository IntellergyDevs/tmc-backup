const moment = require('moment');
const momenttimezone = require('moment-timezone');
const querystring = require('querystring');
const LogRecordModel = require('../../models/LogRecord.model');
const db = require('../../config/db.sequelize');
const distanceHelper = require('./common/distanceCalculator')
var config = require('../../config/config.json');

module.exports.getTrainStops = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    var config = require('../../config/config.json');

    let error = {};
    if (Object.keys(error).length == 0) {
        var busLocations = {};
        let query = "SELECT id, type,commonName, refname AS trainStop, Latitude, Longitude FROM stopsLandmarks WHERE isActive = 1";
        var [trainStops, meta] = await db.query(query, {});
        trainStops = trainStops ? trainStops : [];

        let query2 = "SELECT id, PointX AS Longitude, PointY AS Latitude,StopNumber, routeAllocationName FROM stoplocations";
        var [alllocations, meta] = await db.query(query2, {});
        alllocations = alllocations ? alllocations : [];
        let mapping = {}
        alllocations.forEach(element => {
            if (typeof (mapping[element.routeAllocationName]) === 'undefined') {
                mapping[element.routeAllocationName] = []
            }
            mapping[element.routeAllocationName].push(element)
        });
        // console.log(mapping)
        trainStops.forEach((element, index) => {
            if (mapping[element.commonName]) {
                trainStops[index]['stops'] = mapping[element.commonName]
            } else {
                trainStops[index]['stops'] = []
            }
        });
        if (trainStops && trainStops[0]) {

            // trainStops.forEach((record, index) => {
            //     trainStops[index]['trainStop'] = toTitleCase(`${record.trainStop} - ${record.type}`)
            // })

            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Train stops fetched successfully",
                    status: 1,
                    results: trainStops,
                    mapping
                }, null, 2)
            })

        } else {
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "No train routes data found",
                    //err: error,
                    status: 0,
                    results: {},
                })
            })
        }
    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: {},
            })
        })
    }
};

module.exports.getTrainRoute = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    moment.tz.setDefault(config.timeZone.africaCairo);
    const peakHours = [
        {
            s: '0600',
            e: '0830'
        },
        {
            s: '1600',
            e: '1830'
        }
    ]
    let isPeakHours
    let feesTable
    const cTime = moment().format('HHmm')
    if ((cTime >= peakHours[0].s && cTime <= peakHours[0].e) || (cTime >= peakHours[1].s && cTime <= peakHours[1].e)) {
        isPeakHours = true
        feesTable = 'trainFeesPeak'
    } else {
        isPeakHours = false
        feesTable = 'trainFees'
    }
    console.log(cTime)
    console.log(isPeakHours)
    let req = event.queryStringParameters;
    console.log(req)
    let startLocation = req && req.startLocation ? req.startLocation : null;
    let endLocation = req && req.endLocation ? req.endLocation : null;
    let userLat = req && req.userLat ? req.userLat : null;
    let userLong = req && req.userLong ? req.userLong : null;

    let userHomeLat = req && req.userHomeLat ? req.userHomeLat : null;
    let userHomeLong = req && req.userHomeLong ? req.userHomeLong : null;

    try {
        if (!startLocation) {
            throw new Error("Start Location is required")
        }
        // if (startLocation == endLocation) {
        //     throw new Error("Start and End Location are same")
        // }
        if (!(userLat || userLat)) {
            throw new Error("User Current Location is required")
        }
        if (!(userHomeLat || userHomeLong)) {
            throw new Error("User destination address is required")
        }
        let currTime = moment().tz(config.timeZone.africaCairo).format("HH:mm")

        let query = "SELECT * FROM trainGraphLocations";
        let getTrainTimes = "SELECT `from`, `to`, `duration`, `time` FROM `trainTimings` WHERE TIME(`time`) >= '" + currTime + "' GROUP BY `from`,`to`";
        let trainFullquery = "SELECT * FROM trainFullPath";
        let trainFeesQuery = `SELECT * FROM ${feesTable}`;
        var [graphRoute, meta] = await db.query(query, {});
        graphRoute = graphRoute ? graphRoute : [];

        var [trainFullPath, meta] = await db.query(trainFullquery, {});
        trainFullPath = trainFullPath ? trainFullPath : [];

        var [trainTimes, meta] = await db.query(getTrainTimes, {});
        trainTimes = trainTimes ? trainTimes : [];

        var [trainFeesList, meta] = await db.query(trainFeesQuery, {});
        trainFeesList = trainFeesList ? trainFeesList : [];
        let graph = {}
        let distanceFromUser = { distance: Infinity }
        let LatLongMap = {}
        let typesObjMap = {}

        graphRoute.forEach((element, key) => {
            if (!graph[element.start]) {
                graph[element.start] = {}
                LatLongMap[element.start] = {}
                typesObjMap[element.start] = {}
            }
            graph[element.start][element.end] = element.distanceMeters
            typesObjMap[element.start][element.end] = { transportType: element.transportType }
            LatLongMap[element.start][element.end] = {
                startLat: element.startYLat,
                startLong: element.startXLong,
                endLat: element.endYLat,
                endLong: element.endXLong,
                platform: element.platform,
                duration: element.duration,
                totalDuration: element.totalDuration,
                routeAllocationName: element.routeAllocationName,
                currentStation: element.currentStation,
            }

            // distance from user
            const distance = distanceHelper.distanceBetweenTwoPoints(userLat, userLong, element.startYLat, element.startXLong, "M")

            if (distanceFromUser.distance > distance) {
                distanceFromUser = {
                    distance: distance,
                    start: "Start From Current Location",
                    end: element.start,
                    startLat: userLat,
                    startLong: userLong,
                    endLat: element.startYLat,
                    endLong: element.startXLong
                }
            }
        });
        let userHomeClosest = { distance: Infinity }
        graphRoute.forEach((element, key) => {
            const distance = distanceHelper.distanceBetweenTwoPoints(userHomeLat, userHomeLong, element.startYLat, element.startXLong, "M")
            if (userHomeClosest.distance > distance) {
                userHomeClosest = {
                    distance: distance,
                    end: element.start,
                    endLat: element.startYLat,
                    endLong: element.startXLong,
                }
            }
        })
        const axios = require('axios');

        let googleURLUserToStartStation = `https://maps.googleapis.com/maps/api/directions/json?origin=${distanceFromUser.startLat},${distanceFromUser.startLong}&destination=${distanceFromUser.endLat},${distanceFromUser.endLong}&sensor=false&mode=walking&key=AIzaSyDwKsPZQWY-2KsAVsIHX_TizRLbR2HAfvI`
        const response = await axios.get(googleURLUserToStartStation)
        const userWalkDistance = response.data.routes[0] && response.data.routes[0].legs[0].duration.text ? response.data.routes[0].legs[0].duration.text : 0

        const userWalkTimeValue = response.data.routes[0] && response.data.routes[0].legs[0].duration.value ? response.data.routes[0].legs[0].duration.value : 0


        let googleURLUserToHome = `https://maps.googleapis.com/maps/api/directions/json?origin=${userHomeClosest.endLat},${userHomeClosest.endLong}&destination=${userHomeLat},${userHomeLong}&sensor=false&mode=walking&key=AIzaSyDwKsPZQWY-2KsAVsIHX_TizRLbR2HAfvI`
        const responseHome = await axios.get(googleURLUserToHome)
        const userWalkDistanceToHome = responseHome.data.routes[0] && responseHome.data.routes[0].legs[0].duration.text ? responseHome.data.routes[0].legs[0].duration.text : 0
        const userWalkToHomeFar = responseHome.data.routes[0] && responseHome.data.routes[0].legs[0].distance.value ? responseHome.data.routes[0].legs[0].distance.value : 0

        const userDriveDistanceToHomeValue = responseHome.data.routes[0] && responseHome.data.routes[0].legs[0].distance.value ? responseHome.data.routes[0].legs[0].distance.value : 0

        const userDriveDurationToHomeValue = responseHome.data.routes[0] && responseHome.data.routes[0].legs[0].duration.value ? responseHome.data.routes[0].legs[0].duration.value : 0
        //console.log(googleURLUserToStartStation, googleURLUserToHome)
        // console.log(userWalkDistance, userWalkDistanceToHome)

        // console.log(distanceFromUser)
        let googleURLUserToHomeDrive = `https://maps.googleapis.com/maps/api/directions/json?origin=${userHomeClosest.endLat},${userHomeClosest.endLong}&destination=${userHomeLat},${userHomeLong}&sensor=false&mode=drive&key=AIzaSyDwKsPZQWY-2KsAVsIHX_TizRLbR2HAfvI`
        const responseHomeDrive = await axios.get(googleURLUserToHomeDrive)
        const userDriveDistanceToHome = responseHomeDrive.data.routes[0] && responseHomeDrive.data.routes[0].legs[0].duration.text ? responseHomeDrive.data.routes[0].legs[0].duration.text : 0


        // console.log(googleURLUserToHome)
        // console.log(googleURLUserToHomeDrive)
        // console.log(userDriveDistanceToHome)

        graph['START'] = {
            [distanceFromUser.end]: distanceFromUser.distance == 0 ? 1 : distanceFromUser.distance.toFixed(2)
        }
        LatLongMap['START'] = {
            [distanceFromUser.end]: {
                startLat: distanceFromUser.startLat,
                startLong: distanceFromUser.startLong,
                endLat: distanceFromUser.endLat,
                endLong: distanceFromUser.endLong
            }
        }
        const resDistance = distanceHelper.findShortestPath(graph, 'START', userHomeClosest.end)
        console.log('user close', distanceFromUser)
        console.log('home close', userHomeClosest)
        console.log(resDistance)
        const totalDistance = resDistance.distance
        if (totalDistance == 'Infinity') {
            throw new Error("Path Cannot be found for the given route")
        }

        const path = resDistance.path
        let pathTrace = []
        let transportTypes = { 1: "Train", 2: "Bus", 3: "Walk" }
        let walkRoutes = []
        let busRoutes = { 0: [], 1: [] }
        let trainRoutes = { 0: [], 1: [] }
        let startStop = null
        let endStop = null
        let trainStartStop = null
        let trainEndStop = null
        let busStation = trainStation = ''
        let totDis = 0
        let totTime = 0
        let commonRoute = ['MARLBORO', 'SANDTON', 'RHODESFIELD']
        let westRoute = ['RHODESFIELD', 'ORTIA']
        let totalTrainTime = [0, 0]
        let totalBusTime = [0, 0]
        let routeAllocationName = null

        let currentBusKey = 0
        let currentTrainKey = 0
        let currentMode = null
        let order = []
        let currentOrder = 0
        let trainFees = 0
        let busFees = 0
        let feesForBus = [0, 0]
        let feesForTrain = [0, 0]
        path.forEach((start, index, array) => {

            if (index + 1 == path.length) {
                return
            }
            if (currentMode == null) {
                currentBusKey = currentTrainKey = 0
            }

            let end = array[index + 1]
            indexMode = start == "START" ? "Walk" : transportTypes[typesObjMap[start][end].transportType]

            if (currentMode || indexMode != 'Walk') {

                if (currentMode != indexMode) {
                    if (currentMode == 'Bus') {
                        if (busRoutes[0].length) {
                            currentBusKey += 1
                        }
                    } else {
                        if (trainRoutes[0].length) {
                            currentTrainKey += 1
                        }
                    }
                }
            }

            if (start == "START") {
                walkRoutes.push({
                    start,
                    end,
                    distance: Number(graph[start][end]),
                    unit: 'meters',
                    startLat: Number(LatLongMap[start][end].startLat),
                    startLong: Number(LatLongMap[start][end].startLong),
                    endLat: Number(LatLongMap[start][end].endLat),
                    endLong: Number(LatLongMap[start][end].endLong),
                    transportType: start == "START" ? "Walk" : transportTypes[typesObjMap[start][end].transportType]
                })
            } else if (typesObjMap[start][end].transportType == 2) {
                startStop = startStop == null ? LatLongMap[start][end].currentStation : startStop
                endStop = LatLongMap[start][end].currentStation
                busStation = start
                routeAllocationName = LatLongMap[start][end].routeAllocationName
                // totalBusTime += Number(LatLongMap[start][end].duration)
                busRoutes[currentBusKey].push({
                    start,
                    end,
                    distance: Number(graph[start][end]),
                    unit: 'meters',
                    startLat: Number(LatLongMap[start][end].startLat),
                    startLong: Number(LatLongMap[start][end].startLong),
                    endLat: Number(LatLongMap[start][end].endLat),
                    endLong: Number(LatLongMap[start][end].endLong),
                    transportType: start == "START" ? "Walk" : transportTypes[typesObjMap[start][end].transportType],
                    // platform: LatLongMap[start].platform,
                    duration: LatLongMap[start][end].duration,
                    totalDuration: LatLongMap[start][end].totalDuration,
                    routeAllocationName
                })
                totTime += Number(LatLongMap[start][end].duration)
            } else {
                let platform = LatLongMap[start][end].platform
                let timeSlot;
                if (westRoute.includes(start) && commonRoute.includes(end)) {
                    platform = "D" //westbound
                }
                if (westRoute.includes(end) && commonRoute.includes(start)) {
                    platform = "C" //eastbound
                }

                trainStartStop = trainStartStop == null ? start : trainStartStop
                trainEndStop = end
                trainStation = start
                // let fees = trainFeesList.find(rec => rec.from == start)[end]
                // console.log(start, end, fees)
                // trainFees += Number(fees)
                let namefull = start + '-' + end
                let filteredCoords = trainFullPath.filter(rec => namefull == rec.from || namefull == rec.to)
                timeSlot = trainTimes.find(element => element.from == start && element.to == end)
                // console.log('for duration > ', element, start, end)
                console.log(timeSlot, start, end)
                let platformColor = ''
                if (platform == 'A' || platform == 'B') {
                    platformColor = 'red'
                }
                if (platform == 'C') {
                    platformColor = end == 'RHODESFIELD' ? 'blue' : 'gold'
                }
                if (platform == 'D') {
                    platformColor = start == 'ORTIA' ? 'blue' : 'gold'
                }
                trainRoutes[currentTrainKey].push({
                    start,
                    end,
                    distance: Number(graph[start][end]),
                    unit: 'meters',
                    startLat: Number(LatLongMap[start][end].startLat),
                    startLong: Number(LatLongMap[start][end].startLong),
                    endLat: Number(LatLongMap[start][end].endLat),
                    endLong: Number(LatLongMap[start][end].endLong),
                    transportType: start == "START" ? "Walk" : transportTypes[typesObjMap[start][end].transportType],
                    platform: platform,
                    duration: timeSlot && timeSlot.duration ? timeSlot.duration + " mins" : '0 mins',
                    durationN: timeSlot && timeSlot.duration ? timeSlot.duration : 0,
                    platformColor,
                    fullCoordinates: filteredCoords,
                    // routeFees: Number(fees)
                    //time: timeSlot.time
                })

                totTime += Number(Number(timeSlot.duration) * 60)
            }
            totDis += Number(graph[start][end])
            currentMode = indexMode
        });
        let busMessage = ['', '']
        let trainMessage = ['', '']

        var [routeTimings, meta] = await db.query("SELECT id,time,routeAllocationName FROM routetimings", {
            raw: true,
        });

        busTime = currTime
        if (busRoutes[0].length > 0) {
            let start = busRoutes[0][0]
            let end = busRoutes[0][busRoutes[0].length - 1]

            busMessage[0] = `${start.start} stop to ${end.end} stop`
        }
        if (busRoutes[1].length > 0) {
            let start = busRoutes[1][0]
            let end = busRoutes[1][busRoutes[1].length - 1]

            busMessage[1] = `${start.start} stop to ${end.end} stop`
        }
        if (trainRoutes[0].length > 0) {
            let start = trainRoutes[0][0]
            let end = trainRoutes[0][trainRoutes[0].length - 1]

            trainMessage[0] = `${start.start} stop to ${end.end} stop`
        }
        if (trainRoutes[1].length > 0) {
            let start = trainRoutes[1][0]
            let end = trainRoutes[1][trainRoutes[1].length - 1]

            trainMessage[1] = `${start.start} stop to ${end.end} stop`
        }

        let Allroutes = []
        let Allroutes1 = []
        let Allroutes2 = []

        let noOfSplits = {
            "bus": 0,
            "train": 0,
            "walk": 2,
        }

        busRoutes[0].forEach((element, index) => {
            totalBusTime[0] += Number(element.duration)
            let routeName = element.routeAllocationName
            let assignedTime = ''
            if (routeName) {
                let times = routeTimings.filter((time, index) => time.routeAllocationName == routeName && time.time > currTime)
                let durationTime = times && times[0] ? times[0].time : null
                assignedTime = element.duration != element.totalDuration ? moment(durationTime, "HH:mm").add(element.totalDuration, 'seconds').format("HH:mm:ss") : durationTime
                busRoutes[0][index]['etaTime'] = assignedTime
            } else {
                busRoutes[0][index]['etaTime'] = ''
            }
            if (index + 1 == busRoutes[0].length) {
                busTime = assignedTime != '' ? assignedTime : currTime
            }
            if (!Allroutes.includes(element.routeAllocationName)) {
                if (element.routeAllocationName) {
                    Allroutes.push(element.routeAllocationName)
                    Allroutes1.push(element.routeAllocationName)
                }
            }
        });
        busRoutes[1].forEach((element, index) => {
            totalBusTime[1] += Number(element.duration)

            let routeName = element.routeAllocationName
            if (routeName) {
                let times = routeTimings.filter((time, index) => time.routeAllocationName == routeName && time.time > busTime)
                let durationTime = times && times[0] ? times[0].time : null

                busRoutes[1][index]['etaTime'] = element.duration != element.totalDuration ? moment(durationTime, "HH:mm").add(element.totalDuration, 'seconds').format("HH:mm:ss") : durationTime
            } else {
                busRoutes[1][index]['etaTime'] = ''
            }
            if (!Allroutes.includes(element.routeAllocationName)) {
                if (element.routeAllocationName) {
                    Allroutes.push(element.routeAllocationName)
                    Allroutes2.push(element.routeAllocationName)

                }
            }
        });
           // return
        noOfSplits['bus'] = Allroutes.length//busRoutes[1].length + busRoutes[0].length
        noOfSplits['train'] += trainRoutes[0].length > 0 ? 1 : 0
        noOfSplits['train'] += trainRoutes[1].length > 0 ? 1 : 0
        busFees = Number(Allroutes.length * 10)
        feesForBus[0] = Number(Allroutes1.length * 10)
        feesForBus[1] = Number(Allroutes2.length * 10)

        // const firebasePopularLocationsModel = require('../../models/firebasePopularLocations.model');
        // const firebaseUserStartLocationModel = require('../../models/firebaseUserStartLocation.model');
        // const firebasepopularBusRoutesModel = require('../../models/firebasepopularBusRoutes.model');

        // console.log(Allroutes)
        // console.log(Allroutes1)
        // console.log(Allroutes2)
        let s = ''
        let z = ''
        Allroutes.forEach((rec, index) => {
            if (index == (Allroutes.length - 1)) {
                s += '("' + rec + '")'
            } else {
                s += '("' + rec + '"),'
            }
        })
        resDistance.path.forEach((rec, index) => {

            if (index == (resDistance.path.length - 1)) {
                z += '("' + rec + '")'
            } else {
                z += '("' + rec + '"),'
            }
        })
        let pr1
        let pr2
        let pr3
        if (s.length > 0) {
            let qq1 = `INSERT INTO firebase_popularBusRoute (busStopName) VALUES ${s} ON DUPLICATE KEY UPDATE count=count+1`
            pr1 = db.query(qq1, {
                raw: true,
            })
        }
        if (z.length > 0) {
            let qq2 = `INSERT INTO firebase_popularStopsStations (name) VALUES ${z} ON DUPLICATE KEY UPDATE count=count+1`
            pr2 = db.query(qq2, {
                raw: true,
            })
        }
        let qq3 = `INSERT INTO firebase_passengerStartLocations (latitude, longitude,noOfWalks,noOfTrains,noOfBuses) VALUES (${userLat},${userLong},${noOfSplits['walk']},${noOfSplits['train']},${noOfSplits['bus']})`

        pr3 = db.query(qq3, {
            raw: true,
        })
        await Promise.all([pr1, pr2, pr3]).then((values) => {
            // console.log(values);
        });

        trainRoutes[0].forEach((element, index) => {
            totalTrainTime[0] += Number(element.durationN)
        })
        trainRoutes[1].forEach((element, index) => {
            totalTrainTime[1] += Number(element.durationN)
        })

        if (trainRoutes[0]) {
            let len = trainRoutes[0].length
            if (len == 0) {
                feesForTrain[0] = 0
            } else {
                let f = trainRoutes[0][0].start
                let e = trainRoutes[0][len - 1].end
                const fees = trainFeesList.find(rec => rec.from == f)[e]

                feesForTrain[0] = Number(fees)
            }
        }
        if (trainRoutes[1]) {
            let len = trainRoutes[1].length
            if (len == 0) {
                feesForTrain[1] = 0
            } else {
                let f = trainRoutes[1][0].start
                let e = trainRoutes[1][len - 1].end
                const fees = trainFeesList.find(rec => rec.from == f)[e]

                feesForTrain[1] = Number(fees)
            }
        }
        pathTrace = [{
            walkRoutes: [
                ...walkRoutes
            ],
        }]

        ///////////////////////
        let mapper = {
            'busRoutes1': 1,
            'busRoutes2': 2,
            'trainRoutes1': 3,
            'trainRoutes2': 4,
        }

        let arr = [
            { "put": busRoutes[0], "in": 0, "key": "busRoutes", "value": busRoutes[0][0] ? busRoutes[0][0].start : null },
            { "put": busRoutes[1], "in": 1, "key": "busRoutes", "value": busRoutes[1][0] ? busRoutes[1][0].start : null },
            { "put": trainRoutes[0], "in": 0, "key": "trainRoutes", "value": trainRoutes[0][0] ? trainRoutes[0][0].start : null },
            { "put": trainRoutes[1], "in": 1, "key": "trainRoutes", "value": trainRoutes[1][0] ? trainRoutes[1][0].start : null },
        ]
        let sequence = []
        path.forEach((element, index) => {
            // console.log(element)
            let found = arr.find(ele => ele.value == element)
            // console.log(found)
            if (found) {
                let st = found.key + (found.in + 1)
                sequence.push(mapper[st])
                // console.log('<<<<<<', st)
                pathTrace[0][st] = found.put
            }
        });
        // console.log(sequence)
        ////////////////////
        pathTrace[0].walkRouteToHome = [
            {
                "start": userHomeClosest.end,
                "end": "Home",
                "distance": userWalkToHomeFar,
                "unit": "meters",
                "duration": userWalkDistanceToHome,
                "startLat": userHomeClosest.endLat,
                "startLong": userHomeClosest.endLong,
                "endLat": userHomeLat,
                "endLong": userHomeLong,
                "transportType": "WalkRouteToHome",

            }
        ]
        if (!pathTrace[0].busRoutes1) {
            pathTrace[0].busRoutes1 = []
        } else {
            // busFees += 10
        }
        if (!pathTrace[0].busRoutes2) {
            pathTrace[0].busRoutes2 = []
        } else {
            // busFees += 10
        }
        if (!pathTrace[0].trainRoutes1) {
            pathTrace[0].trainRoutes1 = []
        } else {
            let len = pathTrace[0].trainRoutes1.length - 1
            let fr = pathTrace[0].trainRoutes1[0].start
            let to = pathTrace[0].trainRoutes1[len].end


            // let fees = trainFeesList.find(rec => rec.from == fr)[to]
            // trainFees += Number(fees)
        }
        if (!pathTrace[0].trainRoutes2) {
            pathTrace[0].trainRoutes2 = []
        } else {
            let len = pathTrace[0].trainRoutes2.length - 1
            let fr = pathTrace[0].trainRoutes2[0].start
            let to = pathTrace[0].trainRoutes2[len].end

            // let fees = trainFeesList.find(rec => rec.from == fr)[to]
            // trainFees += Number(fees)
        }
        totDis += userDriveDistanceToHomeValue

        totTime += userWalkTimeValue
        totTime += userDriveDurationToHomeValue
        trainFees = Number(feesForTrain[0]) + Number(feesForTrain[1])
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Train trace data fetched successfully",
                status: 1,
                results: {
                    totalDistance: Number(totDis).toFixed(2),
                    totalTime: Number(totTime).toFixed(2),
                    pathTrace,
                    startLocation: 'User Location',
                    endLocation: 'User Home Location',
                    busMessage,
                    trainMessage,
                    walkRouteToHomeMessage: `Walk from ${userHomeClosest.end} to Home`,
                    totalTrainTime,// in mins
                    totalBusTime, //in seconds
                    userWalkDistance,
                    userWalkDistanceToHome,
                    userDriveDistanceToHome,
                    sequence,
                    fees: {
                        feesForBus,
                        feesForTrain,
                        busTotal: busFees,
                        trainTotal: trainFees,
                        tripTotal: trainFees + busFees,
                        peak: isPeakHours,
                    }
                    // allRoutes
                }
            }, null, 2)
        })
    } catch (err) {
        console.log(err)
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: err.message,
                status: 0,
                results: {},
            })
        })
    }
};

module.exports.getStopsWithin10km = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    try {
        let req = querystring.parse(event.body);

        const userLat = req.userLat ? req.userLat : null;
        const userLong = req.userLong ? req.userLong : null;
        if (!(userLat || userLong)) {
            throw new Error('User current location is required')
        }

        let getAllLocations = `SELECT start,end, startYLat,startXLong,endXLong,endYLat,distanceMeters,duration,transportType FROM trainGraphLocations GROUP BY start ORDER BY id ASC`;
        var [locations, meta] = await db.query(getAllLocations, {});

        let responseLocations = {
            1: [],
            2: [],
        }

        locations.forEach((location, index) => {

            const distance = distanceHelper.distanceBetweenTwoPoints(userLat, userLong, location.startYLat, location.startXLong, "M")
            let flag = false
            if (distance <= 10000) {
                flag = true
            }
            if (location.transportType == 1) {
                flag = true
            }
            if (flag) {
                responseLocations[location.transportType].push({
                    startStation: location.start,
                    endStation: location.end,
                    distanceFromUser: +distance.toFixed(2),
                    distanceFromUserText: distance.toFixed(2) + ' meters',
                    distanceBetweenStation: location.distanceMeters,
                    durationBetweenStation: location.duration,
                    start: {
                        latitude: location.startYLat,
                        longitude: location.startXLong,
                    },
                    end: {
                        latitude: location.endYLat,
                        longitude: location.endXLong,
                    },
                    isWithin10Km: distance <= 10000 ? true : false
                })
            }
        });

        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Locations fetched successfully within 10 km",
                status: 1,
                results: {
                    buses: responseLocations[2],
                    trains: responseLocations[1]
                },
            })
        })

    } catch (err) {
        callback(null, {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: err.message,
                err: err.message,
                status: 0,
                results: {},
            })
        })
    }
};

function toTitleCase(str) {
    return str.replace(
        /\w\S*/g,
        function (txt) {
            return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        }
    );
}
