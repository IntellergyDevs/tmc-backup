var main = require('./main')
const querystring = require('querystring');
const routesModel = require('../../models/Routes.model');
const tripModel = require('../../models/TripDataSet.model');
var config = require('../../config/config.json');
const moment = require('moment');
const db = require('../../config/db.sequelize');

const { Op } = require("sequelize");
const NodeGeocoder = require('node-geocoder');
const options = {
    provider: 'google',
    apiKey: config.google.map, // for Mapquest, OpenCage, Google Premier
    formatter: null // 'gpx', 'string', ...
};
const geocoder = NodeGeocoder(options);

module.exports.getAll = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    let req = querystring.parse(event.body);
    let error = {};
    let limit = req.limit ? Number(req.limit) : 20;
    let page = 0;
    if (req != null && req.page != null) {
        page = 0 + Number(req.page) * limit || 0;
    }

    let sortBy = req != null && req.sort_by != null && req.sort_by != '' ? req.sort_by : 'id';
    let sortOrder = req != null && req.sort_order != null && req.sort_order != '' ? req.sort_order : 'ASC';

    let search = {};

    if (req.routeAllocation) {
        search['RouteAllocation'] = {
            [Op.eq]: req.routeAllocation
        }
    } else {
        error['routeAllocation'] = "Route Allocation cannot be empty"
    }

    if (req.Date && req.Time) { // For Date
        //let datetime = moment(req.Date + " " + req.Time, config.dateFormat.ApiBusFormat).format(config.dateFormat.powerBi);
        // search['StartDateTime'] = {
        //     [Op.eq]: datetime
        // }
    } else {
        error['DateTime'] = "Date Time cannot be empty"
    }
    if (Object.keys(error).length == 0) {
        var [results, metadata] = await db.query("SELECT StopPointX, StopPointY, DeviceId, AverageSpeed FROM tripdataset GROUP BY DeviceId", {
            raw: true,
        });
        let coords = {};

        await results.forEach(function (record, index) {
            coords[record.DeviceId] = record
        })

        const tdate = moment().format("YYYY-MM-DD");
        const filterData = moment(req.Date, "DD-MM-YY").format("YYYY-MM-DD");

        console.log(tdate)
        console.log(filterData)
        var timeCondition = "";

        if (moment(tdate).diff(moment(filterData), 'days') == 0) {
            console.log('time');
            timeCondition = " AND TIME(`time`) >= '" + req.Time + "'";
        } else {
            timeCondition = "";
        }

        var [routeTimings, meta] = await db.query("SELECT id,time FROM routetimings WHERE routeAllocationName = '" + req.routeAllocation + "'" + timeCondition, {
            raw: true,
        });

        var timings = [];

        await routeTimings.forEach(function (record, index) {
            //timings[record.id] = record.time
            timings.push(record.time)
        })
        var [stopLocations, meta] = await db.query("SELECT StopNumber, PointX, PointY FROM stoplocations WHERE routeAllocationName = '" + req.routeAllocation + "'", {
            raw: true,
        });

        var stops = [];

        await stopLocations.forEach(function (record, index) {
            //stops[record.StopNumber] = record;
            stops.push(record)
            //stops[record.StopNumber]['expected'] = coords;

        })

        await routesModel.findAndCountAll({
            raw: true,
            limit: 1,
            offset: page,
            where: search,
            order: [
                [sortBy, sortOrder],
            ],
        }).then(async function (records) {
            let resRecords = records.rows;
            let points;
            if (records.count > 0 && timings.length > 0) {
                records.rows.forEach(function (record, index) {
                    points = coords[record.BusId];

                    resRecords[index].routeStopLocations = stops;
                    if (req.userLat && req.userLng) {
                        resRecords[index].BusdistanceFromUser = main.calcCrow(req.userLat, req.userLng, points.StopPointY, points.StopPointX).toFixed(1);
                    }

                    var totalDist = 0;
                    stops.forEach(function (stop, index2) {
                        let dis = main.calcCrow(stop.PointY, stop.PointX, points.StopPointY, points.StopPointX).toFixed(1);
                        resRecords[index].routeStopLocations[index2].distanceFromStation = dis;
                        resRecords[index].routeStopLocations[index2].busAverageSpeed = points.AverageSpeed;
                        resRecords[index].routeStopLocations[index2].etaToStation = Math.ceil(dis * points.AverageSpeed);
                        totalDist = resRecords[index].routeStopLocations[index2].etaToStationFullRoute = totalDist + Math.ceil(dis * points.AverageSpeed);
                    })

                    resRecords[index].routeTimings = timings;
                })
                if (records.rows[0]) {
                    records = records.rows[0];
                }
                let disFrmUser = [];

                if (records.routeStopLocations) {
                    records.routeStopLocations.forEach(function (record, index) {
                        let dis = main.calcCrow(record.PointY, record.PointX, req.userLat, req.userLng).toFixed(1);
                        disFrmUser.push({
                            dis: dis,
                            station: record.StopNumber
                        })
                    })
                }
                if (disFrmUser.length > 0) {
                    const closest = disFrmUser.reduce(
                        (acc, loc) =>
                            acc.dis < loc.dis
                                ? acc
                                : loc
                    )
                    records.closestStation = closest;
                }
                if (points.AverageSpeed) {
                    records.etaFromBus = Math.ceil(records.BusdistanceFromUser * points.AverageSpeed);
                }

                records.StopPointX = points.StopPointX;
                records.StopPointY = points.StopPointY;
                if (points.StopPointX) {
                    callback(null, {
                        statusCode: 200,
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        },
                        body: JSON.stringify({
                            msg: records.count == 0 ? "No Buses found" : "Records fetched successfully",
                            err: {},
                            status: 1,
                            results: records,
                        })
                    })
                } else {
                    callback(null, {
                        statusCode: 200,
                        headers: {
                            'Content-Type': 'application/json',
                            'Access-Control-Allow-Origin': '*'
                        },
                        body: JSON.stringify({
                            msg: "No Buses found",
                            err: {},
                            status: 0,
                            results: {},
                        })
                    })
                }

            } else {
                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "No Buses found",
                        err: {},
                        status: 0,
                        results: {},
                    })
                })
            }

        }).catch(function (err) {
            callback(err)
        });
    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }


};

module.exports.getBus = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    let req = querystring.parse(event.body);
    let error = {};
    //console.log(calcCrow(59.3293371,13.4877472,59.3225525,13.4619422).toFixed(1));

    let search = {};

    if (req.BusId) {
        search['BusId'] = {
            [Op.eq]: req.BusId
        }
    } else {
        error['BusId'] = "Bus id cannot be empty"
    }
    if (req.userLat && req.userLng) {

    } else {
        error['Location'] = "Location coordinates cannot be empty"
    }

    if (Object.keys(error).length == 0) {


        await routesModel.findAndCountAll({
            raw: true,
            where: search,
        }).then(async function (records) {

            var [routeTimings, meta] = await db.query("SELECT id,time FROM routetimings WHERE routeAllocationName = '" + records.rows[0].RouteAllocation + "'", {
                raw: true,
            });

            var timings = {};

            await routeTimings.forEach(function (record, index) {
                timings[record.id] = record.time
            })

            await tripModel.findAll({
                raw: true,
                limit: 1,
                order: [
                    ['id', 'DESC'],
                ],
                attributes: ['_id', 'StopPointX', 'StopPointY', 'StopDateTime', 'Distance', 'AverageSpeed'],
                where: {
                    DeviceId: req.BusId
                },
            }).then(async function (lastlocation) {
                lastlocation[0].distanceFromUser = main.calcCrow(req.userLat, req.userLng, lastlocation[0].StopPointY, lastlocation[0].StopPointX).toFixed(1);
                lastlocation[0].eta = (lastlocation[0].distanceFromUser * lastlocation[0].AverageSpeed) / 60;
                const location = await geocoder.reverse({ lat: lastlocation[0].StopPointY, lon: lastlocation[0].StopPointX });
                lastlocation[0].location = location[0].formattedAddress;
                records.rows[0].lastKnownLocation = lastlocation;
                records.rows[0].routeTimings = timings;

                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: records.count == 0 ? "No Bus found" : "Records fetched successfully",
                        err: {},
                        status: 1,
                        results: records,
                    })
                })
            }).catch(function (err) {
                console.log(err)

                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "Internal server error",
                        err: err.message,
                        status: 0,
                        results: [],
                    })
                })
            })


        }).catch(function (err) {
            console.log(err)

            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Internal server error",
                    err: err.message,
                    status: 0,
                    results: [],
                })
            })
        });
    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }


};

