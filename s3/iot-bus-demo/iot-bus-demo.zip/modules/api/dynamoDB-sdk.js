const { dynamoDB } = require('./ddbClient')

var params = {
    TableName: 'pilabs-trips-database',
    ScanIndexForward: false,
    ProjectionExpression: "tripId, tripLength, timestampStart,tripExpirationTime",
    // IndexName: 'tripId',
    FilterExpression: 'tripLength > :zero',
    ExpressionAttributeValues: {
        ':zero': 0,
    }
};

dynamoDB.scan(params, function (err, data) {
    if (err) console.log(err);
    // else console.log(data);
    data.Items.forEach(rec => {
        var d = Number(rec.tripExpirationTime)
        console.log(rec.tripLength)
        // console.log(rec.tripId, new Date(d))

    });
});
