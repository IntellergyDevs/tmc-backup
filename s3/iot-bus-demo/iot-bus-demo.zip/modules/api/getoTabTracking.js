const moment = require('moment');
const momenttimezone = require('moment-timezone');
var config = require('../../config/config.json');
const GeotabApi = require('mg-api-js');
const authentication = {
    credentials: {
        database: config.geotab.database,
        userName: config.geotab.email,
        password: config.geotab.password,
    }
}
const api = new GeotabApi(authentication);

moment.tz.setDefault(config.timeZone.africaCairo);

module.exports.insertExceptionEvent = async (event, context, callback) => {

};
