const tripModel = require('../../models/TripDataSet.model');
const { Op } = require("sequelize");

module.exports.getAll = async (event, context, callback) => {
    let req = event.queryStringParameters;

    let limit = req != null && req.limit != null && req.limit != '' ? Number(req.limit) : 20;
    let page = 0;
    if(req != null && req.page != null){
        page = 0 + Number(req.page) * limit || 0;
    }
    let sortBy = req != null && req.sort_by != null && req.sort_by != '' ? req.sort_by : 'id';
    let sortOrder = req != null && req.sort_order != null && req.sort_order != '' ? req.sort_order : 'ASC';


    let searchBy = req != null && req.search_by != null && req.search_by != ''? req.search_by : '';
    let searchValue = req != null && req.search_value != null && req.search_value != '' ? req.search_value : '';
    let search = {};
    if (searchBy != '' && searchValue != '') {
        search[searchBy] = {
            [Op.substring]: searchValue
        }
    }
    await tripModel.findAndCountAll({
        raw: true,
        limit: limit,
        offset: page,
        where: search,
        order: [
            [sortBy, sortOrder],
        ],
    }).then(function (records) {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify(records, null, 2)
        })
    }).catch(function (err) {
        callback(err)
    });
};