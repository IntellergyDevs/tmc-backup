const Sequelize = require('sequelize');
const env = typeof (process.env.NODE_ENV) != "undefined" ? process.env.NODE_ENV : "dev";
// const env = "ferns";
const config = require(__dirname + '/config.json')[env];
console.log("Env:", env, "db:", config.database);
var opts = {
    define: {
        //prevent sequelize from pluralizing table names
        freezeTableName: true
    }
}

var sequelize = new Sequelize(config.database, config.username, config.password, {
    host: config.read_host,
    dialect: config.dialect,
    operatorsAliases: config.operatorsAliases,
    pool: config.pool,
    logging: false,
    operatorsAliases: 0,
});

module.exports = sequelize;