var mysql = require('mysql');

var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    port: 3306,
    database: 'geotab'
});

connection.connect(function (err) {
    if (err) {
        console.error('Database connection failed: ' + err.stack);
        return;
    }

    console.log('Connected to database.');
});
module.exports = connection;

const db = require('./db.sequelize');

db.authenticate()
    .then(() => console.log('Database connected...'))
    .catch(err => console.log('Error: ', err))