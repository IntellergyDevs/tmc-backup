const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const OdometerData = db.define('odometerdataset', {
    _id: {
        type: Sequelize.STRING,
        unique: true,
        //primaryKey: true,
    },
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    DateTime: {
        type: Sequelize.STRING
    },
    DeviceName: {
        type: Sequelize.STRING
    },
    DeviceId: {
        type: Sequelize.STRING
    },
    DiagnosticId: {
        type: Sequelize.STRING
    },
    DiagnosticName: {
        type: Sequelize.STRING
    },
    Data: {
        type: Sequelize.FLOAT
    },
    DistanceCovered: {
        type: Sequelize.FLOAT
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
},{
    freezeTableName: true
})

module.exports = OdometerData;