const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const MessagesBoard = db.define('messageBoard', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    title: {
        type: Sequelize.STRING
    },
    description: {
        type: Sequelize.TEXT
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
},{
    freezeTableName: true
})

module.exports = MessagesBoard;