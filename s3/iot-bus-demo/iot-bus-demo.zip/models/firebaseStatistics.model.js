const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const firebaseStatistics = db.define('firebase_statistics', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    monthlyActiveUsers: {
        type: Sequelize.STRING
    },
    dailyActiveUsers: {
        type: Sequelize.STRING
    },
    tripsPlanned: {
        type: Sequelize.STRING
    },
    dailySessionsPerUser: {
        type: Sequelize.STRING
    },
    sessionUsageInMinutes: {
        type: Sequelize.STRING
    },
    highestAppUsagePeriodFrom: {
        type: Sequelize.STRING
    },
    highestAppUsagePeriodTo: {
        type: Sequelize.STRING
    },
    reviews: {
        type: Sequelize.STRING
    },
    downloads: {
        type: Sequelize.STRING
    },
    retentionRate: {
        type: Sequelize.STRING
    },
    ChurnRate: {
        type: Sequelize.STRING
    },
    gauTripServiceSplitBus: {
        type: Sequelize.STRING
    },
    gauTripServiceSplitTrain: {
        type: Sequelize.STRING
    },
    gauTripServiceSplitWalk: {
        type: Sequelize.STRING
    },
    totalUninstalls: {
        type: Sequelize.STRING
    },
    totalErrors: {
        type: Sequelize.STRING
    },
    monthlyUserGrowth: {
        type: Sequelize.STRING
    },
    platform: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = firebaseStatistics;