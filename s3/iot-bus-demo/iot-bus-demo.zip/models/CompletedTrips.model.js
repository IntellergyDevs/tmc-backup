const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const CompletedTrips = db.define('completedTrips', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    HD03HNGP: {
        type: Sequelize.STRING
    },
    HD03HPGP: {
        type: Sequelize.STRING
    },
    HD03HWGP: {
        type: Sequelize.STRING
    },
    FG16FCGP: {
        type: Sequelize.STRING
    },
    FH92KNGP: {
        type: Sequelize.STRING
    },
    HC01LGGP: {
        type: Sequelize.STRING
    },
    bD: {
        type: Sequelize.STRING
    },
    date: {
        type: Sequelize.DATE
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = CompletedTrips;