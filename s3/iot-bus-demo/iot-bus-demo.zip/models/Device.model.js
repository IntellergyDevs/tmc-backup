const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const Device = db.define('device', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    DeviceName: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    isActive: {
        type: Sequelize.INTEGER,
    }
}, {
    freezeTableName: true
})

module.exports = Device;