const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const firebaseEvents = db.define('firebase_events', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    EventName: {
        type: Sequelize.STRING
    },
    Count: {
        type: Sequelize.INTEGER
    },
    Users: {
        type: Sequelize.INTEGER
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = firebaseEvents;