const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const firebasepopularBusRoutes = db.define('firebase_popularBusRoute', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    busStopName: {
        type: Sequelize.STRING
    },
    count: {
        type: Sequelize.INTEGER
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = firebasepopularBusRoutes;