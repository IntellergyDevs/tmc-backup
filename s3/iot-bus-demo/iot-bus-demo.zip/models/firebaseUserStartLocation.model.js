const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const firebaseUserStartLocation = db.define('firebase_passengerStartLocations', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    latitude: {
        type: Sequelize.STRING
    },
    longitude: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = firebaseUserStartLocation;