const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const Diagnostic = db.define('diagnostic', {
    _id: {
        type: Sequelize.STRING,
        unique: true,
        //primaryKey: true,
    },
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    code: {
        type: Sequelize.STRING
    },
    diagnosticType: {
        type: Sequelize.STRING
    },
    engineType: {
        type: Sequelize.STRING
    },
    isLogGuaranteedOnEstimateError: {
        type: Sequelize.STRING
    },
    name: {
        type: Sequelize.STRING
    },
    version: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = Diagnostic;