const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');
const UserAdminStatic = require('./userAdminStatic.model')
const UserAdmin = db.define('users', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    firstName: {
        type: Sequelize.STRING
    },
    lastName: {
        type: Sequelize.STRING
    },
    name: {
        type: Sequelize.STRING
    },
    associatedStation: {
        type: Sequelize.STRING
    },
    role: {
        type: Sequelize.STRING
    },
    associatedRoutes: {
        type: Sequelize.STRING
    },
    email: {
        type: Sequelize.STRING,
        allowNull: false,
        validate: {
            isEmail: {
                args: true,
                msg: 'Please enter a valid email'
            },
            notEmpty: {
                args: true,
                msg: "Email is required & cannot be empty"
            }
        }
    },
    password: {
        type: Sequelize.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                args: true,
                msg: "Password is required & cannot be empty"
            }
        }
    },
    isVerified: {
        type: Sequelize.INTEGER
    },
    status: {
        type: Sequelize.INTEGER
    },
    verifyToken: {
        type: Sequelize.STRING
    },
    forgotPassToken: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = UserAdmin;