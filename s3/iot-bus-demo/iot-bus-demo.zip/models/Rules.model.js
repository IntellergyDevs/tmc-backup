const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const Rules = db.define('rules', {
    _id: {
        type: Sequelize.STRING,
        unique: true,
        //primaryKey: true,
    },
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    Name: {
        type: Sequelize.STRING
    },
    Version: {
        type: Sequelize.STRING
    },
    BaseType: {
        type: Sequelize.STRING
    },
    ActiveFrom: {
        type: Sequelize.STRING
    },
    ActiveTo: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = Rules;