const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const firebase_popularStopsStations = db.define('firebase_popularStopsStations', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    name: {
        type: Sequelize.STRING
    },
    type: {
        type: Sequelize.STRING
    },
    count: {
        type: Sequelize.INTEGER
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = firebase_popularStopsStations;