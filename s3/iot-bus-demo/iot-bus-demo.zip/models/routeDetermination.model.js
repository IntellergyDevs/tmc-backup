const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const routeDetermination = db.define('routeDetermination', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    deviceId: {
        type: Sequelize.STRING
    },
    isRouteReset: {
        type: Sequelize.INTEGER
    },
    isBusInStation: {
        type: Sequelize.INTEGER
    },
    totalCountables: {
        type: Sequelize.TEXT,
    },
    currentStation: {
        type: Sequelize.STRING,
    },
    currentRouteDetermined: {
        type: Sequelize.TEXT,
    },
    pastList: {
        type: Sequelize.TEXT,
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = routeDetermination;