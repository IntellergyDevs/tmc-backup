const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');
const UserAdmin = require('./UserAdmin.model');
const UserAdminStatic = db.define('userAdminStatic', {
    id: {
        type: Sequelize.INTEGER,
        // unique: true,
        autoIncrement: true,
        primaryKey: true,
    },
    headerText: {
        type: Sequelize.STRING
    },
    headerColor  : {
        type: Sequelize.STRING
    },
    legendBackground: {
        type: Sequelize.STRING
    },
    busInfoBackground: {
        type: Sequelize.STRING
    },
    logo: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
    userAdmin_id: {
        type: Sequelize.INTEGER,
     
        references: {
          // This is a reference to another model
          model: UserAdmin,
     
          // This is the column name of the referenced model
          key: 'id',
        }
      },
}, {
    freezeTableName: true
})

module.exports = UserAdminStatic;