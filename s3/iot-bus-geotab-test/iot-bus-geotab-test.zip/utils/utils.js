const jwt = require('jsonwebtoken');
const config = require('../config/config.json');



let errorMessages = {
    'jwt expired': 'Session Timeout !!',
    'invalid signature': 'Invalid Session',
    'jwt malfunctioned': 'Session Compromised !!!, Logging you out ...',
    'jwt malformed': 'Session Compromised !!!, Logging you out ...',
    'Auth token is missing': 'Auth token is missing'
}

module.exports.checkAuth = (headers, callback) => {
    return new Promise(resolve => {

        let error = ''
        try {

            if (!headers.Authorization) {
                throw new Error('Auth token is missing')
            }
            let token = headers.Authorization.split(" ")[1]
            if (!token) {
                throw new Error('Auth token is missing')
            }

            let decoded = jwt.verify(token, config.JWT_SECRET_KEY);
            resolve(decoded)
        } catch (err) {
            console.log(err)
            let error = '';
            let errorCode = 403;
            if (err.message && errorMessages[err.message]) {
                error = errorMessages[err.message]
            } else {
                error = "Something went wrong"
                errorCode = 500
            }
            callback(null, {
                statusCode: errorCode,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: error,
                    err: error,
                    status: 0
                })
            })
        }
    });

}

module.exports.parseJwt = (token) => {
    return JSON.parse(jsonPayload);
};