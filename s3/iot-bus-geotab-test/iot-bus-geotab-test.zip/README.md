serverless deploy
serverless deploy --stage production --region eu-central-1


serverless deploy function -f functionName

serverless deploy function --function helloWorld \
  --stage dev \
  --region us-east-1