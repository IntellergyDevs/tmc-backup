const querystring = require('querystring');
const admin = require("firebase-admin");
const db = require('../config/db.sequelize');
const FcmDevices = require('../models/FcmDevices.model');

const iosServiceAccount = require("../config/project-eagle-284910-firebase-adminsdk-1rpvq-03aee3e787.json")
const androidServiceAccount = require("../config/project-eagle-284910-firebase-adminsdk-1rpvq-03aee3e787.json");


const registerFcmDevice = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    try {
        let req = querystring.parse(event.body);

        const deviceModel = req.deviceModel ? req.deviceModel : '';
        const androidVersion = req.androidVersion ? req.androidVersion : '';
        const fcmToken = req.fcmToken ? req.fcmToken : '';
        const deviceType = req.deviceType ? req.deviceType : '';
        const uuidAndroidId = req.uuidAndroidId ? req.uuidAndroidId : '';
        const ipAddress = req.ipAddress ? req.ipAddress : '';
        if (uuidAndroidId == '') {
            throw new Error('UUID is required and cannot be empty')
        }
        if (fcmToken == '') {
            throw new Error('FCM Token is required and cannot be empty')
        }
        let findExistingDeviceQuery = `SELECT * FROM fcmDevices WHERE uuidAndroidId = '${uuidAndroidId}'`;
        let [deviceExist, meta] = await db.query(findExistingDeviceQuery, {});

        let newDevice = {
            deviceModel,
            androidVersion,
            fcmToken,
            deviceType,
            uuidAndroidId,
            ipAddress,
            isActive: 1
        }
        // console.log(newDevice);
        if (deviceExist.length > 0) { // device is there so overwrite
            let device = deviceExist[0]
            await FcmDevices.update(newDevice, {
                where: {
                    id: device.id
                }
            }).then(function (device) {
                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "Device updated successfully",
                        status: 1,
                        results: {
                            newDevice
                        },
                    })
                })
            }).catch(async function (err) {
                let errors = err.errors.map(function (record) {
                    return record.message;
                });
                console.log(errors)
                callback(null, {
                    statusCode: 401,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "Validation Failed",
                        err: errors,
                        status: 0,
                        results: [],
                    })
                })
            })

        } else { // insert new device

            await FcmDevices.create(
                newDevice
            ).then(function (newDevice) {
                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "New device added successfully",
                        status: 1,
                        results: {
                            newDevice
                        },
                    })
                })
            }).catch(async function (err) {

                let errors = err.errors.map(function (record) {
                    return record.message;
                });
                console.log(errors)

                callback(null, {
                    statusCode: 401,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "Validation Failed",
                        err: errors,
                        status: 0,
                        results: [],
                    })
                })
            })
        }

    } catch (err) {
        console.log(err)
        callback(null, {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: err.message,
                err: err.message,
                status: 0,
                results: {},
            })
        })
    }

}

const sendPushNotificationsiOS = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    let getAllDevices = `SELECT * FROM fcmDevices WHERE isActive = 1 AND deviceType = 'iOS'`;
    let [devices, meta] = await db.query(getAllDevices, {});

    let iOSDeviceArray = []

    devices.forEach(element => {
        if (element.fcmToken && element.fcmToken != '') {
            iOSDeviceArray.push(element.fcmToken)
        }
    });
    console.log(iOSDeviceArray)
    console.log('total > ', iOSDeviceArray.length)
    iOSDeviceArray = [...new Set(iOSDeviceArray)]
    console.log('unique > ', iOSDeviceArray.length)

    admin.initializeApp({
        credential: admin.credential.cert(iosServiceAccount),
        // databaseURL: "https://testproject-23f41.firebaseio.com"
    });

    let registrationToken = iOSDeviceArray

    let payload = {
        notification: {
            title: "Rahul iOS",
            body: "Rahul iOS",
        }
    };

    let options = {
        priority: "high",
        timeToLive: 60 * 60 * 24
    }
    await admin.messaging().sendToDevice(registrationToken, payload, options)
        .then(function (response) {
            console.log('res', response)
            console.log('success: ', response.successCount, 'failure: ', response.failureCount)
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    // msg: response,
                    err: response,
                    status: 0,
                    results: {},
                })
            })
        }).catch(function (err) {
            console.log(JSON.stringify(err))
            callback(null, {
                statusCode: 500,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: err.message,
                    err: err,
                    status: 0,
                    results: {},
                })
            })
        })


}

const sendPushNotificationsAndroid = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    let getAllDevices = `SELECT * FROM fcmDevices WHERE isActive = 1 AND deviceType='Android'`;
    let [devices, meta] = await db.query(getAllDevices, {});

    let androidDeviceArray = []

    devices.forEach(element => {
        if (element.fcmToken && element.fcmToken != '') {
            androidDeviceArray.push(element.fcmToken)
        }
    });

    console.log('total > ', androidDeviceArray.length)
    androidDeviceArray = [...new Set(androidDeviceArray)]
    console.log('unique > ', androidDeviceArray.length)

    admin.initializeApp({
        credential: admin.credential.cert(androidServiceAccount),
        // databaseURL: "https://testproject-23f41.firebaseio.com"
    });

    let registrationToken = ['dac9CTAHZkJbq_RNl9oOkf:APA91bGKkvpYdkEw_4mm1AqX-dWLMuGH5ZOvp7EpOEU07nJo8-vt9qIWleymqPlaIdKnlThzFNG-Y_1ucbv42tj1V6xwWEE50UtKWA136Ek-ixpIcJN-PAk2oAR5WMkRKWAp77pcJk74']//deviceArray

    let payload = {
        data: {
            title: 'Bus delay for route 3',
            body: 'The bus has been delayed due to heavy snow'
        }
    }

    let options = {
        priority: "high",
        timeToLive: 60 * 60 * 24
    }
    await admin.messaging().sendToDevice(registrationToken, payload, options)
        .then(function (response) {
            console.log('res', response)
            console.log('success: ', response.successCount, 'failure: ', response.failureCount)
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    // msg: response,
                    err: response,
                    status: 0,
                    results: {},
                })
            })
        }).catch(function (err) {
            console.log(JSON.stringify(err))
            callback(null, {
                statusCode: 500,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: err.message,
                    err: err,
                    status: 0,
                    results: {},
                })
            })
        })


}

const getFirebaseCalculations = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    let calc = {
        tripsPlanned: 25,
        users: {
            dailySessionsPerUser: 12,
            // tripsPlannedCount: 12,
            sessionUsageInMinutes: 35,
            highestAppUsagePeriod: {
                from: "2:00 AM",
                to: "4:30 AM",
            },
            originLocation: [
                'MIDRAND',
                'WOODLANDS OFFICE PARK - WSP2-11',
                'Queenswood - 4',
                'GREENSTONE - Greenstone 17',
            ]
        },
        downloads: {
            apple: 3,
            android: 4
        },
        reviews: {
            apple: 1,
            android: 3
        },
        rate: {
            retention: 45,
            churn: 55,
        },
        gauTripServiceSplit: {
            walk: 25,
            bus: 35,
            train: 40,
        },
        usage: {
            busStops: [
                'WOODLANDS OFFICE PARK - WSP2-16',
                'Highveld - HCS - 1',
                'Kelvin - KMS-10',
            ],
            busRoutes: [
                'Kelvin',
                'BUCCLEUCH',
                'LINBRO BUSINESS PARK',
                'WOODLANDS OFFICE PARK',
            ],
            trainStation: [
                'SANDTON',
                'RHODESFIELD',
            ],
        },
    }

    try {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Firebase calculations data fetched successfully",
                status: 1,
                results: {
                    calc
                }
            }, null, 2)
        })
    } catch (err) {
        console.log(JSON.stringify(err))
        callback(null, {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: err.message,
                err: err,
                status: 0,
                results: {},
            })
        })
    }
}


module.exports = {
    registerFcmDevice,
    sendPushNotificationsiOS,
    sendPushNotificationsAndroid,
    getFirebaseCalculations,
};