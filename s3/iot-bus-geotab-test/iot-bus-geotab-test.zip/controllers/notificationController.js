const querystring = require('querystring');
const moment = require('moment');
const { Op } = require("sequelize");
const config = require('../config/config.json');

const NotificationsModel = require('../models/Notifications.model');
const MessagesBoardModel = require('../models/MessagesBoard.model');
const gtNewsModel = require('../models/GtNews.model');
const contactsModel = require('../models/Contacts.model');


const getAllNotifications = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    console.log('query start - ', new Date())
    moment.tz.setDefault(config.timeZone.africaCairo);
    let req = querystring.parse(event.body);
    let error = {};
    let limit = req.limit ? Number(req.limit) : 20;
    let page = 0;
    if (req != null && req.page != null) {
        page = 0 + Number(req.page) * limit || 0;
    }

    let sortBy = req != null && req.sort_by != null && req.sort_by != '' ? req.sort_by : 'id';
    let sortOrder = req != null && req.sort_order != null && req.sort_order != '' ? req.sort_order : 'ASC';

    let search = {};
    console.log('before if - ', new Date())
    if (Object.keys(error).length == 0) {

        await NotificationsModel.findAndCountAll({
            raw: true,
            limit: limit,
            offset: page,
            where: search,
            order: [
                [sortBy, sortOrder],
            ],
        }).then(async function (records) {
            console.log('inside async after if - ', new Date())
            let idsList = []
            let response = await records.rows.map(function (record) {
                let currentTime = moment().tz(config.timeZone.africaCairo).format("x")
                let notifTime = moment(record.createdAt).tz(config.timeZone.africaCairo).format("x")
                idsList.push(record.id)
                let nrecord = {};
                nrecord = record;
                nrecord['diff'] = timeDiff(currentTime, notifTime);
                return nrecord
            });
            let pasrsedIds = idsList.map(id => "" + id + "").join()

            console.log('after time diff loop and before sending in response - ', new Date())
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: records.count == 0 ? "No Notifications found" : "Notifications fetched successfully",
                    err: {},
                    status: records.count == 0 ? 0 : 1,
                    results: { ...records, pasrsedIds },
                })
            })
        }).catch(function (err) {
            callback(err)
        });
    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }
};

const getMessages = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    moment.tz.setDefault(config.timeZone.africaCairo);

    let req = querystring.parse(event.body);
    let error = {};
    let limit = req.limit ? Number(req.limit) : 20;
    let page = 0;
    if (req != null && req.page != null) {
        page = 0 + Number(req.page) * limit || 0;
    }

    let sortBy = req != null && req.sort_by != null && req.sort_by != '' ? req.sort_by : 'id';
    let sortOrder = req != null && req.sort_order != null && req.sort_order != '' ? req.sort_order : 'ASC';

    let search = {};
    if (Object.keys(error).length == 0) {

        await MessagesBoardModel.findAndCountAll({
            raw: true,
            limit: limit,
            offset: page,
            where: search,
            attributes: [
                'title', 'description'
            ],
            order: [
                [sortBy, sortOrder],
            ],
        }).then(async function (records) {
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: records.count == 0 ? "No Messages found" : "Messages fetched successfully",
                    err: {},
                    status: records.count == 0 ? 0 : 1,
                    results: records,
                })
            })
        }).catch(function (err) {
            callback(err)
        });
    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }


};

const getGtNews = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    moment.tz.setDefault(config.timeZone.africaCairo);

    let req = querystring.parse(event.body);
    let error = {};
    let limit = req.limit ? Number(req.limit) : 20;
    let page = 0;
    if (req != null && req.page != null) {
        page = 0 + Number(req.page) * limit || 0;
    }

    let sortBy = req != null && req.sort_by != null && req.sort_by != '' ? req.sort_by : 'id';
    let sortOrder = req != null && req.sort_order != null && req.sort_order != '' ? req.sort_order : 'ASC';

    let search = {
        expiryDate: {
            [Op.gte]: new Date()
        }
    };
    if (Object.keys(error).length == 0) {

        await gtNewsModel.findAndCountAll({
            raw: true,
            // limit: limit,
            // offset: page,
            where: search,
            attributes: [
                'title', 'description', 'imageUrl'
            ],
            order: [
                [sortBy, sortOrder],
            ],
        }).then(async function (records) {
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: records.count == 0 ? "No GT News found" : "GT News fetched successfully",
                    err: {},
                    status: records.count == 0 ? 0 : 1,
                    results: records,
                })
            })
        }).catch(function (err) {
            callback(err)
        });
    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }


};


const addContact = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;

    let req = querystring.parse(event.body);
    let error = {};

    if (!req.queryType) {
        error['queryType'] = "Query Type cannot be empty"
    }
    if (!req.description) {
        error['description'] = "Description cannot be empty"
    }

    try {
        if (Object.keys(error).length == 0) {
            await contactsModel.create(
                req
            ).then(function (contact) {
                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "Contact added successfully",
                        err: {},
                        status: 1,
                        results: contact,
                    })
                })
            }).catch(async function (err) {

                let errors = err.errors.map(function (record) {
                    return record.message;
                });

                console.log(errors)
                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "Validation Failed",
                        err: errors,
                        status: 0,
                        results: {},
                    })
                })
            })
        } else {
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Insufficient Data provided",
                    err: error,
                    status: 0,
                    results: {},
                })
            })
        }
    } catch (catE) {

    }

};

function timeDiff(curr, prev) {

    let ms_Min = 60 * 1000;
    let ms_Hour = ms_Min * 60;
    let ms_Day = ms_Hour * 24;
    let ms_Mon = ms_Day * 30;
    let ms_Yr = ms_Day * 365;
    let diff = curr - prev;
    if (diff < ms_Min) {
        return Math.round(diff / 1000) + ' seconds ago';

    } else if (diff < ms_Hour) {
        return Math.round(diff / ms_Min) + ' minutes ago';

    } else if (diff < ms_Day) {
        return Math.round(diff / ms_Hour) + ' hours ago';

    } else if (diff < ms_Mon) {
        return 'Around ' + Math.round(diff / ms_Day) + ' days ago';

    } else if (diff < ms_Yr) {
        return 'Around ' + Math.round(diff / ms_Mon) + ' months ago';
    } else {
        return 'Around ' + Math.round(diff / ms_Yr) + ' years ago';
    }
}


module.exports = {
    getAllNotifications,
    getMessages,
    getGtNews,

    addContact,
};