const moment = require('moment');
const GeotabApi = require('mg-api-js');

const db = require('../config/db.sequelize');
const config = require('../config/config.json');
const utils = require('../utils/utils');
const errorMessages = {
    'JSONRPCError - Incorrect login credentials': 'You can\'t view respective bus details that frequently',
    'JSONRPCError - API calls quota exceeded. Maximum admitted 10 per 1m.': 'You can\'t view respective bus details that frequently'
}


const getBusExceptions = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    // let auth = await utils.checkAuth(event.headers, callback);

    moment.tz.setDefault(config.timeZone.africaCairo);
    let req = event.queryStringParameters;
    let busId = req && req.busId ? req.busId : null;
    let fromDate = req && req.fromDate ? req.fromDate : new Date().toISOString().split('T')[0];
    let toDate = req && req.toDate ? req.toDate : new Date().toISOString().split('T')[0];

    const authentication = {
        credentials: {
            database: config.geotab.database,
            userName: config.geotab.email,
            password: config.geotab.password,
        }
    }
    const api = new GeotabApi(authentication);

    let error = {};
    if (busId == null) {
        error['Invalid Param'] = "BusId is invalid parameter"
    }
    if (Object.keys(error).length == 0) {
        let calls = [
            ['Get', {
                typeName: 'ExceptionEvent',
                search: {
                    toDate: toDate,
                    fromDate: fromDate,//,new Date().toISOString().split('T')[0],
                    deviceSearch: { id: busId }
                }
            }],
            // ['Get', { typeName: 'DeviceStatusInfo', resultsLimit: 1, search: { deviceSearch: { id: busId } } }],
            ['Get', { typeName: 'Rule' }],

        ];
        await api.multiCall(calls).then(data => {
            let events = [];
            let rules = [];
            data[1].forEach(function (rule) {
                rules[rule.id] = rule.name
            })
            if (data[0].length > 0) {

                data[0].sort((a, b) => {
                    return new Date(b.activeFrom) - new Date(a.activeFrom)
                });

                data[0].forEach((value) => {
                    events.push({
                        ...value,
                        rule: {
                            id: value.rule.id,
                            name: typeof (rules[value['rule']['id']]) != 'undefined' ? rules[value['rule']['id']] : '',
                        },
                        activeFrom: moment(value['activeFrom']).tz(config.timeZone.africaCairo).format(config.dateFormat.powerBi),
                        activeTo: moment(value['activeTo']).tz(config.timeZone.africaCairo).format(config.dateFormat.powerBi)
                    })
                })
            }
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Bus exceptions data fetched successfully",
                    status: 1,
                    results: {
                        exceptions: events,
                        // location: location,
                    }
                }, null, 2)
            })
        }).catch(error => {
            let err = 'An internal server error occured'
            console.log(error)

            if (error.message && errorMessages[error.message]) {
                err = errorMessages[String(error.message)]
            } else {
                err = error.message
            }
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: err,//error.message ? error.message : "An internal server error occured",
                    //err: error,
                    status: 0,
                    results: [],
                })
            })
        });

    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }
};


const getBusLocationTrace = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    // let auth = await utils.checkAuth(event.headers, callback)

    moment.tz.setDefault(config.timeZone.africaCairo);
    let req = event.queryStringParameters;

    let busId = req && req.busId ? req.busId : null;
    let fromDate = req && req.fromDate ? req.fromDate : new Date().toISOString();
    let toDate = req && req.toDate ? req.toDate : new Date().toISOString();

    const authentication = {
        credentials: {
            database: config.geotab.database,
            userName: config.geotab.email,
            password: config.geotab.password,
        }
    }
    const api = new GeotabApi(authentication);
    console.log(fromDate, "  <> ", toDate)

    try {
        if (busId == null) {
            throw new Error("BusId is invalid parameter")
        }
        // Total Distance covered by bus

        // let queryTotalDis = `SELECT SUM(DistanceCovered) AS DistanceCovered FROM odometerdataset WHERE DeviceId = '${busId}' AND DateTime >= '${fromDate}' AND DateTime <= '${toDate}' AND DistanceCovered > 0`;
        // let queryTotalDis = `SELECT Data FROM odometerdataset WHERE DeviceId = '${busId}' AND DateTime >= '${fromDate}' AND DateTime <= '${toDate}' ORDER BY DateTime DESC`
        let queryAvgSpeed = `SELECT AVG(AverageSpeed) AS AverageSpeed FROM tripdataset WHERE DeviceId = '${busId}' AND StartDateTime >= '${fromDate}' AND StartDateTime <= '${toDate}'`;
        let queryFuelUsed = `SELECT Data AS FuelUsed FROM fuelusagedataset WHERE DeviceId = '${busId}' AND DateTime >= '${fromDate}' AND DateTime <= '${toDate}' ORDER BY FuelUsed ASC`;
        let queryIdlingTime = `SELECT SUM( Duration ) AS IdlingDuration FROM exceptioneventdataset WHERE DeviceId = 'bC' AND RuleId = 'RuleIdlingId' AND ActiveFrom >= '${fromDate}' AND ActiveFrom <= '${toDate}'`
        let totalTripQ = `SELECT DeviceId, COUNT(DeviceId) AS toalTrips FROM tripdataset WHERE DeviceId = '${busId}' AND StartDateTime >= '${fromDate}' AND StopDateTime <= '${toDate}' GROUP BY DeviceId`
        // let [BustotalDistance, meta] = await db.query(queryTotalDis, {});
        let [BusAvgSpeed, meta1] = await db.query(queryAvgSpeed, {});
        let [BusFuelUsed, meta2] = await db.query(queryFuelUsed, {});
        let [BusIdlingTime, meta3] = await db.query(queryIdlingTime, {});
        let [totalTrip, meta4] = await db.query(totalTripQ, {});
        let totalDistanceTravelled = 0
        // BustotalDistance = BustotalDistance[0] ? BustotalDistance[0] : []


        BusAvgSpeed = BusAvgSpeed[0] ? BusAvgSpeed[0].AverageSpeed : ''
        // BusFuelUsed = BusFuelUsed[0] ? BusFuelUsed[0].FuelUsed : ''
        BusIdlingTime = BusIdlingTime[0] ? BusIdlingTime[0].IdlingDuration : ''
        totalTrip = totalTrip[0] ? totalTrip[0] : []

        let calls = [
            ['Get',
                {
                    typeName: 'LogRecord',
                    search: {
                        fromDate: fromDate,
                        ToDate: toDate,
                        deviceSearch: { id: busId }
                    }
                }
            ],
            ['Get', {
                typeName: 'StatusData',
                search: {
                    fromDate: fromDate,
                    ToDate: toDate,
                    deviceSearch: { id: busId },
                    diagnosticSearch: {
                        id: "DiagnosticOdometerId"
                    },
                }
            }],
        ];
        console.time('test');
        await api.multiCall(calls).then(data => {
            let BustotalDistance = data[1]
            console.log(BustotalDistance.length)
            if (BustotalDistance.length > 1) {
                let first = BustotalDistance[0].data
                let last = BustotalDistance[BustotalDistance.length - 1].data
                console.log(first, last)
                totalDistanceTravelled = last - first
            }

            console.timeEnd('test');
            let totalRecords = Math.floor(data[0].length / 100);
            let tracedRecords = [];
            if (totalRecords >= 2) {
                // trim records
                data[0].forEach((val, key) => {
                    if (key % totalRecords == 0) {
                        tracedRecords.push({
                            ...val,
                            // "dateTime_utc": val.dateTime,
                            "dateTime": moment(val.dateTime).tz(config.timeZone.africaCairo).format(config.dateFormat.powerBi),
                        })
                    }
                })

            } else {
                data[0].forEach((val, key) => {
                    tracedRecords.push({
                        ...val,
                        // "dateTime_utc": val.dateTime,
                        "dateTime": moment(val.dateTime).tz(config.timeZone.africaCairo).format(config.dateFormat.powerBi),
                    })
                })
            }

            let fuelUsed = 0
            if (BusFuelUsed.length >= 2) {
                fuelUsed = BusFuelUsed[BusFuelUsed.length - 1].FuelUsed - BusFuelUsed[0].FuelUsed
            }
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Bus exceptions data fetched successfully",
                    status: 1,
                    results: {
                        trace: tracedRecords,
                        info: {
                            0: data[0].length,
                            1: totalRecords
                        },
                        otherDetails: {
                            BustotalDistance: Number(totalDistanceTravelled / 1000),
                            BusAvgSpeed: BusAvgSpeed != null ? BusAvgSpeed : 0,
                            BusFuelUsed: fuelUsed,
                            BusIdlingTime,
                            totalTrips: totalTrip && totalTrip.toalTrips ? totalTrip.toalTrips : 0
                        }
                    }
                }, null, 2)
            })
        }).catch(error => {
            let err = 'An internal server error occured'
            console.log(error)
            if (error.message && errorMessages[error.message]) {
                err = errorMessages[error.message]
            } else {
                err = error.message
            }
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: err,//error.message ? error.message : "An internal server error occured",
                    //err: error,
                    status: 0,
                    results: [],
                })
            })
        });
    } catch (err) {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: err.message ? err.message : "An Internal server error occured",
                status: 0,
                results: [],
            })
        })
    }
};

module.exports = {
    getBusExceptions,
    getBusLocationTrace,
};