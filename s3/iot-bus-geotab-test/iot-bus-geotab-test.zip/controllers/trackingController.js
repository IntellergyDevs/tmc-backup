const moment = require('moment');
// const bcrypt = require('bcryptjs');
// const jwt = require('jsonwebtoken');
const jwt_decode = require('jwt-decode');
const geolib = require('geolib');

const db = require('../config/db.sequelize');
const config = require('../config/config.json');
const utils = require('../utils/utils');
const distanceCalc = require('../utils/distanceCalculator');
const Stops = require('../enums/stop');
const Routes = require('../enums/route');
const distanceHelper = require("../utils/distanceCalculator");


const getAllBuses = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    // let auth = await utils.checkAuth(event.headers, callback)

    moment.tz.setDefault(config.timeZone.africaCairo);
    let error = {};
    if (Object.keys(error).length == 0) {
        let busLocations = {};

        let query = "SELECT * FROM device LEFT JOIN deviceStatusInfo ON device.id = deviceStatusInfo.deviceID WHERE isActive = 1";
        let [records, meta] = await db.query(query, {});
        records = records ? records : [];

        if (records && records[0]) {
            const idleTime = 5;//mins

            let finalResponse = records.map((value, index) => {
                // console.log(value);
                let isDriving = value.isDriving
                let duration = value.currentStateDuration
                let durationInMins = Number(moment(duration, 'hh:mm:ss').format("m"))
                let status = '';
                if (isDriving) {
                    status = 'running'
                }
                if (!isDriving) {
                    if (durationInMins <= idleTime) {
                        status = 'idle'
                    } else {
                        status = 'stopped'
                    }
                }
                // console.log(isDriving, duration, durationInMins, status)
                return {
                    status,
                    statusDuration: duration,
                    latitude: Number(value.latitude),
                    longitude: Number(value.longitude),
                    id: value.deviceId,
                    DeviceName: value.DeviceName
                }
            })
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Bus data fetched successfully",
                    status: 1,
                    results: {
                        buses: finalResponse
                    }
                }, null, 2)
            })

        } else {
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "No bus data found",
                    //err: error,
                    status: 0,
                    results: [],
                })
            })
        }
    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }
};

const getAllStaticDetails = async (event, context, callback) => {

    context.callbackWaitsForEmptyEventLoop = false;
    // let auth = await utils.checkAuth(event.headers, callback);

    let error = {};
    if (Object.keys(error).length == 0) {

        let queryforStops = "SELECT B.id, A.name as Landmark, B.name, A.Latitude AS landmarkLat, A.Longitude AS landmarkLong, B.Latitude AS surroundLat, B.Longitude AS surroundLong, associatedRoutes FROM stopsLandmarks A LEFT JOIN stopsSurroundingStops B ON A.id = B.landmarkId";
        let queryforFullPath = "SELECT id, name, colorScheme, landmarkId, Latitude, Longitude FROM stopsFullPath"
        let busRoutes = db.query("SELECT * FROM stoplocations_react", {
            nest: true
        });
        const stopsAndLandmarks = db.query(queryforStops, {
            nest: true
        });
        // console.log('stopsAndLandmarks======>',stopsAndLandmarks);

        let fullPath = db.query(queryforFullPath, {
            nest: true
        });
        // records = records ? records : [];
        let toDate = moment().format("YYYY-MM-DD");
        let fromDate = moment().add(-30, 'days').format("YYYY-MM-DD");
        let getCountQuery = `SELECT DeviceId, COUNT(_id) AS count FROM exceptioneventdataset WHERE createdAt >= '${fromDate}' GROUP BY DeviceId`
        let [getExceptionCounts, meta] = await db.query(getCountQuery, {
            raw: true,
        })
        // console.log('getExceptionCounts',getExceptionCounts);
        let totalExceptions = 0
        const totalDevice = getExceptionCounts.length
        let deviceRating = {}
        getExceptionCounts.forEach(element => {
            totalExceptions += element.count
            deviceRating[element.DeviceId] = element.count
        });

        const avg = totalExceptions / totalDevice
        const percentile = avg / 5

        let outOf = [0, 0, 0, 0, 0]

        outOf.forEach((element, index) => {
            let num = avg - (index * percentile)
            outOf[index] = num
        });

        getExceptionCounts.forEach((element, index) => {
            let count = element.count
            let rating = outOf.filter(elem => count <= elem).length
            deviceRating[element.DeviceId] = rating
        });
        // console.log(toDate, fromDate);
        await Promise.all([busRoutes, stopsAndLandmarks, fullPath]).then((values) => {
            let records = values[0]
            let landmarksRaw = values[1]
            let fullPath = values[2]
            let fullPathLocation = {};

            fullPath.forEach(element => {
                if (typeof (fullPathLocation[element.name]) === 'undefined') {
                    fullPathLocation[element.name] = [];
                }
                fullPathLocation[element.name].push({
                    id: element.id,
                    latitude: Number(element.Latitude),
                    longitude: Number(element.Longitude),
                })
            });
            let stopLocations = {};
            records.forEach(element => {
                if (typeof (stopLocations[element.routeAllocationName]) === 'undefined') {
                    stopLocations[element.routeAllocationName] = {};
                    stopLocations[element.routeAllocationName]['id'] = element.routeAllocationName;
                    stopLocations[element.routeAllocationName]['name'] = element.routeAllocationName;
                    stopLocations[element.routeAllocationName]['routeStops'] = [];
                    stopLocations[element.routeAllocationName]['routeCoordinates'] = fullPathLocation[element.routeAllocationName] ? fullPathLocation[element.routeAllocationName] : []
                    stopLocations[element.routeAllocationName]['colorScheme'] = "#" + element.colorScheme;
                }
                stopLocations[element.routeAllocationName].routeStops.push({
                    message: element.StopNumber,
                    id: element.id,
                    longitude: Number(element.PointX),
                    latitude: Number(element.PointY),
                })
            });
            let responseStops = [];

            Object.keys(stopLocations).forEach(element => {
                responseStops.push(stopLocations[element]);
            });
            let landmarks = landmarksRaw.filter((item, index, objects) => {
                if (index === 0) {
                    return item
                } else if (item.Landmark !== objects[index - 1].Landmark) {
                    return {
                        "name": item.Landmark,
                        "latitude": Number(item.landmarkLat),
                        "longitude": Number(item.landmarkLong),
                        "associatedRoutes": item.associatedRoutes
                    };
                }
            }).map(function (item) {
                return {
                    "name": item.Landmark,
                    "latitude": Number(item.landmarkLat),
                    "longitude": Number(item.landmarkLong),
                    "associatedRoutes": JSON.parse(item.associatedRoutes)
                };
            });

            let landmarksWithStops = landmarksRaw.filter(({ id }) => id != null).map(function (item) {
                return {
                    "Landmark": item.Landmark,
                    "name": item.name,
                    "latitude": Number(item.surroundLat),
                    "longitude": Number(item.surroundLong),
                };
            }).reduce((r, a) => {
                r[a.Landmark] = [...r[a.Landmark] || [], a];
                return r;
            }, {});
            let responseLandmarksStops = [];
            Object.keys(landmarksWithStops).forEach((element, key) => {
                responseLandmarksStops.push({
                    id: element,
                    name: element,
                    routeCoordinates: landmarksWithStops[element]
                })
                // console.log(element)
            });
            responseLandmarksStops.forEach((element, index) => {
                let landmark = landmarks.filter(lm => lm.name == element.name)

                responseLandmarksStops[index]['associatedRoutes'] = landmark && landmark[0] && landmark[0].associatedRoutes ? landmark[0].associatedRoutes : []
            })

            if (records && records[0]) {

                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Frame-Options': 'DENY', 'X-Frame-Options': 'DENY',
                        'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "Stops and landmarks data fetched successfully",
                        status: 1,
                        results: {
                            "type": "FeatureCollection",
                            // routes: {
                            //     routeStops: responseStops, //black main stops
                            //     routeCoordinates: fullPathLocation // full path trace
                            // },
                            routes: responseStops,
                            landmarks: {
                                landmarkStops: landmarks, // main station points
                                landmarkAreaCoordinates: responseLandmarksStops // all polygon
                            },
                            deviceRating,
                            stats: {
                                totalExceptions,
                                avg
                            },
                        },
                    }, null, 2)
                })
            } else {
                callback(null, {
                    statusCode: 200,
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Frame-Options': 'DENY', 'Access-Control-Allow-Origin': '*'
                    },
                    body: JSON.stringify({
                        msg: "No data found",
                        //err: error,
                        status: 0,
                        results: [],
                    })
                })
            }
        });
    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }
};

const getDriverRatings = async (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    // let auth = await utils.checkAuth(event.headers, callback)

    moment.tz.setDefault(config.timeZone.africaCairo);
    let toDate = moment().format("YYYY-MM-DD");
    let fromDate = moment().add(-30, 'days').format("YYYY-MM-DD");

    let error = {};

    if (true) {
        let getCountQuery = `SELECT DeviceId, COUNT(_id) AS count FROM exceptioneventdataset WHERE createdAt >= '${fromDate}' GROUP BY DeviceId`
        let [getExceptionCounts, meta] = await db.query(getCountQuery, {
            raw: true,
        })

        let totalExceptions = 0
        const totalDevice = getExceptionCounts.length
        let deviceRating = {}
        getExceptionCounts.forEach(element => {
            totalExceptions += element.count
            deviceRating[element.DeviceId] = element.count
        });

        const avg = totalExceptions / totalDevice
        const percentile = avg / 5

        let outOf = [0, 0, 0, 0, 0]

        outOf.forEach((element, index) => {
            let num = avg - (index * percentile)
            outOf[index] = num
        });

        getExceptionCounts.forEach((element, index) => {
            let count = element.count
            let rating = outOf.filter(elem => count <= elem).length
            deviceRating[element.DeviceId] = rating
        });
        // console.log(toDate, fromDate)

        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Driver Ratings fetched successfully",
                timePeriod: {
                    fromDate,
                    toDate
                },
                err: {},
                status: 1,
                results: {
                    deviceRating,
                    stats: {
                        totalExceptions,
                        avg
                    }
                },
            })
        });
    } else {
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Insufficient Data provided",
                err: error,
                status: 0,
                results: [],
            })
        })
    }
};


const getBusesStationEtaData = async (event, context, callback) => {
    try {
        context.callbackWaitsForEmptyEventLoop = false;

        let req = event.queryStringParameters;
        console.log(req, event)
        let Authorization = 'Bearer ' + config.auth.centurion;
        if (req.location == 'centurion')
            Authorization = 'Bearer ' + config.auth.centurion;
        if (req.location == 'marlboro')
            Authorization = 'Bearer ' + config.auth.marlboro;
        if (req.location == 'hatfield')
            Authorization = 'Bearer ' + config.auth.hatfield;

        event.headers.Authorization = Authorization;
        let auth = await utils.checkAuth(event.headers, callback);
        let user = jwt_decode(event.headers.Authorization.split(' ')[1]);
        // console.log(user);

        let parsedRoutes = user.associatedRoutes
        if (!user.associatedRoutes) {
            throw new Error('You are not authorized to access that location')
        }
        let routesStopsUser = parsedRoutes.map(id => "'" + id + "'").join()

        let getStopsForStationQuery = `SELECT id, routeAllocationName,StopNumber, PointX, PointY,sequence, colorScheme FROM stoplocations_react WHERE include = 1 AND routeAllocationName IN (${routesStopsUser})`
        const p1 = db.query(getStopsForStationQuery, {
            raw: true,
        });

        let getPolygonsQuery = `SELECT name, landmarkId,Latitude,Longitude FROM stopsSurroundingStops WHERE name = '${user.associatedStation}'`
        const p2 = db.query(getPolygonsQuery, {
            raw: true,
        });

        let getDeviceInfoQuery = `SELECT currentStation,isRouteReset,latitude,longitude,routeDetermination.isBusInStation AS isBusInStation, routeDetermination.pastList AS pastList,device.isActive AS isActive,currentRouteDetermined, routeDetermination.deviceId FROM deviceStatusInfo LEFT JOIN routeDetermination ON deviceStatusInfo.deviceId = routeDetermination.deviceId LEFT JOIN device ON device.id = deviceStatusInfo.deviceId WHERE device.isActive = 1`
        const p3 = db.query(getDeviceInfoQuery, {
            raw: true,
        });

        let getBoundary = `SELECT stationBoundary FROM stopsLandmarks WHERE name = '${user.associatedStation}'`
        const p4 = db.query(getBoundary, {
            raw: true,
        })

        let getAllGraphLocs = `SELECT start, end, routeAllocationName, distanceFromStation FROM trainGraphLocations_new`
        const p5 = db.query(getAllGraphLocs, {
            raw: true,
        })

        let stopsObj = {}
        let polygonArray = []
        let busesInPolygon = {}

        await Promise.all([p1, p2, p3, p4, p5]).then(async (values) => {
            let stops = values[0][0]
            let polygons = values[1][0]
            let deviceInfo = values[2][0]
            let Boundary = values[3][0]
            let trainGraphs = values[4][0]
            let uniqueStops = []
            stops.forEach(element => {

                if (!stopsObj[element.routeAllocationName]) {
                    stopsObj[element.routeAllocationName] = {}
                    stopsObj[element.routeAllocationName]['stops'] = []
                    stopsObj[element.routeAllocationName]['color'] = element.colorScheme
                    uniqueStops.push(element.routeAllocationName)
                }
                stopsObj[element.routeAllocationName]['stops'].push({
                    StopNumber: element.StopNumber,
                    latitude: element.PointY,
                    longitude: element.PointX,
                    sequence: element.sequence,
                })
            });
            let responseBusRecords = {}
            let hasRouteAllocated = []
            deviceInfo.forEach((bus, index) => {
                if (user.associatedRoutes.includes(bus.currentRouteDetermined)) {
                    hasRouteAllocated.push(bus.currentRouteDetermined)
                    let isDeviated = false
                    const isInPoly = geolib.isPointInPolygon({ latitude: bus.latitude, longitude: bus.longitude }, polygons) ? 1 : 0;
                    if (!isInPoly) {
                        isDeviated = true
                    }
                    responseBusRecords[bus.deviceId] = {}
                    responseBusRecords[bus.deviceId]['stops'] = []
                    responseBusRecords[bus.deviceId]['isDeviated'] = isDeviated
                    responseBusRecords[bus.deviceId]['route'] = {
                        name: bus.currentRouteDetermined,
                        color: stopsObj[bus.currentRouteDetermined]['color'] ? '#' + stopsObj[bus.currentRouteDetermined]['color'] : ''
                    }
                    responseBusRecords[bus.deviceId]['location'] = { latitude: bus.latitude, longitude: bus.longitude }

                    if (bus.isBusInStation == 1) {
                    } else {
                        let i = 0
                        let stopsCount = 0
                        let Firstindex = stopsObj[bus.currentRouteDetermined]['stops'].findIndex(val => val.StopNumber == bus['currentStation'])

                        while (i < 3) {
                            if (stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount]) {
                                responseBusRecords[bus.deviceId]['stops'].push({
                                    StopNumber: stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount].StopNumber,
                                    latitude: stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount].latitude,
                                    longitude: stopsObj[bus.currentRouteDetermined]['stops'][Firstindex + stopsCount].longitude
                                })
                            }
                            i++;
                            stopsCount++;
                        }

                        responseBusRecords[bus.deviceId]['stops'].forEach((stopElement, index) => {
                            let getDistance;
                            // console.log(stopElement.StopNumber);
                            let found = trainGraphs.find(rec => rec.start == stopElement.StopNumber)
                            getDistance = (found.distanceFromStation / 1000)

                            const speed = 20;//kmph
                            let durationInSecs = getDistance / speed
                            duration = distanceCalc.secondsToHms(durationInSecs * 3600)// secs
                            // console.log(getDistance);
                            responseBusRecords[bus.deviceId]['stops'][index]['distance'] = {
                                km: getDistance.toFixed(2),
                                m: (getDistance * 1000).toFixed(2)
                            }
                            responseBusRecords[bus.deviceId]['stops'][index]['eta'] = {
                                text: duration,
                                seconds: Number(durationInSecs * 3600).toFixed(2)
                            }

                        });
                    }
                }

            });
            hasRouteAllocated = [...new Set(hasRouteAllocated)]


            uniqueStops = uniqueStops.filter(function (el) {
                return !hasRouteAllocated.includes(el);
            });
            uniqueStops.forEach(unique => {
                responseBusRecords[unique] = {
                    stops: [],
                    route: {
                        name: unique,
                        color: stopsObj[unique]['color'] ? '#' + stopsObj[unique]['color'] : ''
                    }
                }
            });
            callback(null, {
                statusCode: 200,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({
                    msg: "Bus data fetched successfully",
                    status: 1,
                    results: {
                        busesInPolygon: responseBusRecords,
                    }
                }, null, 2)
            });
        })
    } catch (err) {
        console.log(err)
        callback(null, {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Internal server error occured",
                err: err.message,
                status: 0,
                results: [],
            })
        })
    }
};



const userGetStaticDetails = async (event, context, callback) => {
    try {
        context.callbackWaitsForEmptyEventLoop = false;

        let req = event.queryStringParameters;
        let Authorization = 'Bearer ' + config.auth.centurion;
        if (req.location == 'centurion')
            Authorization = 'Bearer ' + config.auth.centurion;
        if (req.location == 'marlboro')
            Authorization = 'Bearer ' + config.auth.marlboro;
        if (req.location == 'hatfield')
            Authorization = 'Bearer ' + config.auth.hatfield;

        event.headers.Authorization = Authorization;
        let auth = await utils.checkAuth(event.headers, callback)
        let user = jwt_decode(event.headers.Authorization.split(' ')[1]);

        // get routes
        let busRoutes
        var responseStops = [];
        let landmarks
        let responseLandmarksStops = [];
        if (user.associatedRoutes) {
            let parsedRoutes = user.associatedRoutes
            let sts = parsedRoutes.map(id => "'" + id + "'").join()

            let queryforStops = `SELECT B.id, A.centerPoint, A.name as Landmark, B.name, A.Latitude AS landmarkLat, A.Longitude AS landmarkLong, B.Latitude AS surroundLat, B.Longitude AS surroundLong, associatedRoutes FROM stopsLandmarks A LEFT JOIN stopsSurroundingStops B ON A.id = B.landmarkId WHERE A.name = '${user.associatedStation}'`;
            let queryforFullPath = `SELECT id, name, colorScheme, landmarkId, Latitude, Longitude FROM stopsFullPath WHERE name IN (${sts})`

            let busRoutes = db.query(`SELECT * FROM stoplocations_react WHERE routeAllocationName IN (${sts})`, {
                nest: true
            });
            const stopsAndLandmarks = db.query(queryforStops, {
                nest: true
            });

            let fullPath = db.query(queryforFullPath, {
                nest: true
            });

            await Promise.all([busRoutes, stopsAndLandmarks, fullPath]).then((values) => {
                let records = values[0]
                let landmarksRaw = values[1]
                let fullPath = values[2]
                let fullPathLocation = {};

                fullPath.forEach(element => {
                    if (typeof (fullPathLocation[element.name]) === 'undefined') {
                        fullPathLocation[element.name] = [];
                    }
                    fullPathLocation[element.name].push({
                        id: element.id,
                        latitude: Number(element.Latitude),
                        longitude: Number(element.Longitude),
                    })
                });
                let stopLocations = {};
                records.forEach(element => {
                    if (typeof (stopLocations[element.routeAllocationName]) === 'undefined') {
                        stopLocations[element.routeAllocationName] = {};
                        stopLocations[element.routeAllocationName]['id'] = element.routeAllocationName;
                        stopLocations[element.routeAllocationName]['name'] = element.routeAllocationName;
                        stopLocations[element.routeAllocationName]['routeStops'] = [];
                        stopLocations[element.routeAllocationName]['routeCoordinates'] = fullPathLocation[element.routeAllocationName] ? fullPathLocation[element.routeAllocationName] : []
                        stopLocations[element.routeAllocationName]['colorScheme'] = "#" + element.colorScheme;
                    }
                    stopLocations[element.routeAllocationName].routeStops.push({
                        message: element.StopNumber,
                        id: element.id,
                        longitude: Number(element.PointX),
                        latitude: Number(element.PointY),
                    })
                });
                Object.keys(stopLocations).forEach(element => {
                    responseStops.push(stopLocations[element]);
                });
                landmarks = landmarksRaw.filter((item, index, objects) => {
                    if (index === 0) {
                        return item
                    } else if (item.Landmark !== objects[index - 1].Landmark) {
                        return {
                            "name": item.Landmark,
                            "latitude": Number(item.landmarkLat),
                            "longitude": Number(item.landmarkLong),
                            "associatedRoutes": item.associatedRoutes,
                            "centerPoint": item.centerPoint,
                        };
                    }
                }).map(function (item) {
                    return {
                        "name": item.Landmark,
                        "latitude": Number(item.landmarkLat),
                        "longitude": Number(item.landmarkLong),
                        "associatedRoutes": JSON.parse(item.associatedRoutes),
                        "centerPoint": JSON.parse(item.centerPoint),
                    };
                });

                let landmarksWithStops = landmarksRaw.filter(({ id }) => id != null).map(function (item) {
                    return {
                        "Landmark": item.Landmark,
                        "name": item.name,
                        "latitude": Number(item.surroundLat),
                        "longitude": Number(item.surroundLong),
                        // "centerPoint": JSON.parse(item.centerPoint),
                    };
                }).reduce((r, a) => {
                    r[a.Landmark] = [...r[a.Landmark] || [], a];
                    return r;
                }, {});

                Object.keys(landmarksWithStops).forEach((element, key) => {
                    responseLandmarksStops.push({
                        id: element,
                        name: element,
                        routeCoordinates: landmarksWithStops[element]
                    })
                });
                responseLandmarksStops.forEach((element, index) => {
                    let landmark = landmarks.filter(lm => lm.name == element.name)

                    responseLandmarksStops[index]['associatedRoutes'] = landmark && landmark[0] && landmark[0].associatedRoutes ? landmark[0].associatedRoutes : []
                })
            })
        }
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Data fetched successfully",
                status: 1,
                results: {
                    routes: responseStops,
                    landmarks: {
                        landmarkStops: landmarks, // main station points
                        landmarkAreaCoordinates: responseLandmarksStops, // all polygon,
                        centerPoint: landmarks && landmarks[0] && landmarks[0].centerPoint ? landmarks[0].centerPoint : null
                    }
                }
            }, null, 2)
        })

    } catch (err) {
        console.log(err)
        callback(null, {
            statusCode: 401,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: err.message,
                err: err.message,
                status: 0,
                results: [],
            })
        })
    }
};

async function getPilabsData(location){
    const axios = require('axios');
    const response = await axios.get(`https://8dg9kin6f2.execute-api.af-south-1.amazonaws.com/dev/api/pilabs/getTripETA?location=${location}`)
    if(response.data && response.status == 200){
        return response.data;
    } else {
        return false;
    }
    
}

function getRoutesFromLocation(location) {
    if (location == "marlboro") {
      return [
        "Greenstone",
        "Linbro Business Park",
        "Woodlands Office Park",
        "Buccleuch",
        "Kelvin",
      ];
    } else if (location == "centurion") {
      return ["Midstream", "Highveld"];
    } else {
      return ["Queenswood"];
    }
  }

  function getDistance1(obj){
    return (obj.distanceMeters / 1000);
 }

function getEndDistance(obj){
  return (obj.distanceFromStation / 1000);
}

const getBusesStationEtaDataCombine = async (event, context, callback) => {
    try {
        context.callbackWaitsForEmptyEventLoop = false;
        //let user = await utils.checkAuth(event.headers, callback)
        // let user = jwt_decode(event.headers.Authorization.split(' ')[1]);
        // console.log('user associatedRoutes', user);
        const location = event.queryStringParameters.location;
        let routes = getRoutesFromLocation(location);
        let user = {
          associatedStation: location,
          associatedRoutes: routes
        }
        let pilabsData;
        if(location && location != ''){
            pilabsData = await getPilabsData(location);
        }
        let responseBusRecords = await getBusRecord(user);
        if(pilabsData){
            responseBusRecords= [...responseBusRecords, ...pilabsData['results']['busesInPolygon']];
        }
        callback(null, {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Bus data fetched successfully",
                status: 1,
                results: {
                    busesInPolygon: responseBusRecords,
                }
            }, null, 2)
        })
    } catch (err) {
        console.log(err)
        callback(null, {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                msg: "Internal server error occured",
                err: err.message,
                status: 0,
                results: [],
            })
        })
    }
};

async function getBusRecord(user) {
    const geolib = require('geolib');
  
    let location;
    let parsedRoutes = user.associatedRoutes
    if (!user.associatedRoutes) {
        throw new Error('You are not authorized to access that location')
    }
    if (user.associatedStation) {
        location = user.associatedStation;
    }
    let routesStopsUser = parsedRoutes.map(id => "'" + id + "'").join()
  
    let getStopsForStationQuery = `SELECT id, routeAllocationName,StopNumber, PointX, PointY,sequence, colorScheme FROM stoplocations_react WHERE include = 1 AND routeAllocationName IN (${routesStopsUser})`
    const p1 = db.query(getStopsForStationQuery, {
        raw: true,
    })

    let getPolygonsQuery = `SELECT name, landmarkId,Latitude,Longitude FROM stopsSurroundingStops WHERE name = '${user.associatedStation}'`
    const p2 = db.query(getPolygonsQuery, {
        raw: true,
    })

    let getDeviceInfoQuery = `SELECT currentStation,isRouteReset,latitude,longitude,routeDetermination.isBusInStation AS isBusInStation, routeDetermination.pastList AS pastList,device.isActive AS isActive,currentRouteDetermined, routeDetermination.deviceId, routeDetermination.deviceName, deviceStatusInfo.currentStateDuration FROM deviceStatusInfo LEFT JOIN routeDetermination ON deviceStatusInfo.deviceId = routeDetermination.deviceId LEFT JOIN device ON device.id = deviceStatusInfo.deviceId WHERE device.isActive = 1`
    const p3 = db.query(getDeviceInfoQuery, {
        raw: true,
    })

    let getBoundary = `SELECT stationBoundary FROM stopsLandmarks WHERE name = '${user.associatedStation}'`
    const p4 = db.query(getBoundary, {
        raw: true,
    })

    let getAllGraphLocs = `SELECT start, end, routeAllocationName,distanceMeters, distanceFromStation FROM trainGraphLocations_new`
    const p5 = db.query(getAllGraphLocs, {
        raw: true,
    })
  
    let stopsObj = {};
    let polygonArray = [];
    let busesInPolygon = {};
  
    const values = await Promise.all([p1, p2, p3, p4, p5]);
    let stops = values[0][0]
    let polygons = values[1][0]
    let deviceInfo = values[2][0]
    let Boundary = values[3][0]
    let trainGraphs = values[4][0]
    let uniqueStops = []
  
    //inserting stops
    for (let stop of stops) {
        if (!stopsObj[stop.routeAllocationName]) {
            stopsObj[stop.routeAllocationName] = {}
            stopsObj[stop.routeAllocationName]['stops'] = []
            stopsObj[stop.routeAllocationName]['color'] = stop.colorScheme
            uniqueStops.push(stop.routeAllocationName)
        }
        stopsObj[stop.routeAllocationName]['stops'].push({
            StopNumber: stop.StopNumber,
            latitude: stop.PointY,
            longitude: stop.PointX,
            sequence: stop.sequence,
        });
    }
  
    let responseBusRecords = [];
    let hasRouteAllocated = [];
    for (let bus of deviceInfo) {
        if (user.associatedRoutes.includes(bus.currentRouteDetermined)) {
            let busRecord = {};
            hasRouteAllocated.push(bus.currentRouteDetermined);
            let isDeviated = false;
  
            //check if bus is in polygon
            const isInPoly = geolib.isPointInPolygon({ latitude: bus.latitude, longitude: bus.longitude }, polygons) ? 1 : 0;
            if (!isInPoly) {
                isDeviated = true;
            }
  
            //inserting bus data into new busRecord object
            busRecord['locationName'] = location;
            busRecord['deviceId'] = bus.deviceId;
            busRecord['deviceName'] = bus.deviceName;
            busRecord['stops'] = [];
            busRecord['isDeviated'] = isDeviated;
            busRecord['route'] = {
                name: bus.currentRouteDetermined,
                color: stopsObj[bus.currentRouteDetermined]['color'] ? `#${stopsObj[bus.currentRouteDetermined]['color']}` : ''
            }
            busRecord['location'] = {
                latitude: bus.latitude,
                longitude: bus.longitude
            }
  
            //proceed only if bus is not at station
            if (bus.isBusInStation == 0) {
                let currentStation;
                let foundCurrentStationDistance;
                let remainingDistanceFromCurrentStopInSecs = 0;
                let coveredDistanceFromCurrentStopInSecs = 0;
                let speed = 20; //kmph
                let getCurrentBusSpeed = `SELECT * FROM logrecorddataset where DeviceId = '${bus.deviceId}' order by createdAt DESC`;
                let busSpeedResult = await db.query(getCurrentBusSpeed, {
                    raw: true,
                });
                speed = busSpeedResult[0][0].Speed;
                if (speed <= 0) speed = 20;
  
                if (stopsObj[bus.currentRouteDetermined]['stops'] && stopsObj[bus.currentRouteDetermined]['stops'].length > 0) {
                    // sort the array by sequence
                    await stopsObj[bus.currentRouteDetermined]['stops'].sort((a, b) => a.sequence - b.sequence);
                    let duplicateBusStand = {
                        "StopNumber": stopsObj[bus.currentRouteDetermined]['stops'][0].StopNumber,
                        "latitude": stopsObj[bus.currentRouteDetermined]['stops'][0].latitude,
                        "longitude": stopsObj[bus.currentRouteDetermined]['stops'][0].longitude,
                        "sequence": stopsObj[bus.currentRouteDetermined]['stops'][stopsObj[bus.currentRouteDetermined]['stops'].length - 1].sequence + 1,
                        "duplicate": true
                    };
                    stopsObj[bus.currentRouteDetermined]['stops'].push(duplicateBusStand);
                    let Firstindex = stopsObj[bus.currentRouteDetermined]['stops'].findIndex(val => val.StopNumber == bus['currentStation']);
                    if (Firstindex !== -1) {
                        // remove stops that bus has passed
                        let filterStops = [...stopsObj[bus.currentRouteDetermined]['stops']];
                        filterStops = filterStops.splice(Firstindex);
  
                        if (filterStops && filterStops.length > 0) {
                            // get currentStation
                            currentStation = filterStops[0];
                            // console.log('currentStation', currentStation);
  
                            //getting current station distance from DB
                            foundCurrentStationDistance = trainGraphs.find(rec => rec.start == currentStation.StopNumber);
  
                            // get only 3 stops, remove rest
                            let nextStops = filterStops.slice(0, 4);
  
                            //inserting stop details into stops array of busRecord
                            if (nextStops && nextStops.length > 0) {
                                for (let nextStop of nextStops) {
                                    busRecord['stops'].push({
                                        StartStopName: Stops[nextStop.StopNumber],
                                        StartStopNumber: nextStop.StopNumber,
                                        latitude: nextStop.latitude,
                                        longitude: nextStop.longitude,
                                        sequence: nextStop.sequence
                                    })
                                }
                            }
                        }
                    }
                }
                let index = 0;
                let distanceArr = [...trainGraphs].filter(x => x.routeAllocationName == bus.currentRouteDetermined);
                if(busRecord['stops'].length > 0){
                for (let stopElement of busRecord['stops']) {
                    //getting next stop of current stop
                    let found = trainGraphs.find(rec => rec.start == stopElement.StartStopNumber);
  
                    busRecord['stops'][index]['EndStopNumber'] = found['end'];
                    busRecord['stops'][index]['EndStopName'] = Stops[found['end']];
  
                    //calculating next bus stop
                    let nextStop;
                    let firstStopObj;
                    if (busRecord['stops'].length == 1) {
                        nextStop = busRecord['stops'][index];
                        firstStopObj = busRecord['stops'][0];
                    } else {
                        nextStop = busRecord['stops'][index + 1];
                        firstStopObj = busRecord['stops'][1];
                    }
  
  
                    if (nextStop) {
                        //calculating distance between two locations
                        let remainingDistanceFromCurrentStop = await distanceHelper.distanceBetweenTwoPoints(bus.latitude, bus.longitude, firstStopObj.latitude, firstStopObj.longitude, "K");
                        if(index > 0){
                            const countIndex = busRecord['stops'][0].sequence;
                            let _distance = 0;
                            for(let i = 0; i < index; i++) {    
                                let _d = getDistance1(distanceArr[countIndex + i]);
                                _distance = _distance + _d;
                            }
                            remainingDistanceFromCurrentStop = remainingDistanceFromCurrentStop + _distance;
                        }
  
                        //Calculating distance in seconds
                        remainingDistanceFromCurrentStopInSecs = remainingDistanceFromCurrentStop / speed;
  
                        let getDistance;
                        // getDistance = (found.distanceMeters / 1000); //distance in KM
                        getDistance = remainingDistanceFromCurrentStop; //distance in KM
  
                        let durationInSecs = getDistance / speed;
                        let duration = distanceCalc.secondsToHms(durationInSecs * 3600) //secs
                        console.log(`from bus to ${nextStop.StartStopNumber} in seconds => ${durationInSecs * 3600} => ${duration} inserting in ${busRecord['stops'][index].StartStopNumber}`);;
  
                        //inserting distance in km and m
                        busRecord['stops'][index]['distance'] = {
                            km: getDistance.toFixed(2),
                            m: (getDistance * 1000).toFixed(2)
                        }
  
                        // inserting ETA
                        busRecord['stops'][index]['eta'] = {
                            text: duration,
                            timestamp: moment().add(Number(durationInSecs * 3600), 'seconds').unix(),
                            time: moment().add(Number(durationInSecs * 3600), 'seconds').utcOffset('+0200').format('h:mm A'),
                            seconds: Number(durationInSecs * 3600).toFixed(2),
                            currentTimeStamp: moment().add(Number(remainingDistanceFromCurrentStopInSecs * 3600), 'seconds').unix(),
                            currentTime: moment().add(Number(remainingDistanceFromCurrentStopInSecs * 3600), 'seconds').utcOffset('+0200').format('h:mm A'),
                            currentSeconds: Number(remainingDistanceFromCurrentStopInSecs * 3600).toFixed(2)
                        }
                        
                        coveredDistanceFromCurrentStopInSecs = (durationInSecs * 3600) - (remainingDistanceFromCurrentStopInSecs * 3600);
                    }
                    index++;
                }
                }
                
                if (busRecord['stops'].length > 1) busRecord['stops'].splice(busRecord['stops'].length - 1, 1);
                if (busRecord['stops'].length > 1) busRecord['stops'] = busRecord['stops'].filter((stop) => Number(stop.distance.m) >= Number(busRecord['stops'][0].distance.m));
                // last stop eta
                stopsObj[bus.currentRouteDetermined]['stops'] = stopsObj[bus.currentRouteDetermined]['stops'].filter(x => !x['duplicate']);
                let isLastIndex = busRecord['stops'].findIndex(x => x.sequence == stopsObj[bus.currentRouteDetermined]['stops'].length);
                if(isLastIndex == -1 && busRecord['stops'].length > 1){
                  let endStopObj = {
                    StartStopName: busRecord['stops'][0].StartStopName,
                    StartStopNumber: busRecord['stops'][0].StopNumber,
                    latitude: busRecord['stops'][0].latitude,
                    longitude: busRecord['stops'][0].longitude,
                    EndStopNumber: 'end',
                    EndStopName: Stops[`${location[0].toUpperCase()}${location.slice(1)} End`]
                  }
                  let distanceTofirstStop = busRecord['stops'][0].distance.km;
                  let _d = getEndDistance(distanceArr[busRecord['stops'][0].sequence]);
                  let remainingDistanceFromCurrentStop = Number(distanceTofirstStop) + Number(_d);
                  
                  let remainingDistanceFromCurrentStopInSecs = 0;
                  remainingDistanceFromCurrentStopInSecs = remainingDistanceFromCurrentStop / speed;
                  
                  let getDistance;
                  getDistance = remainingDistanceFromCurrentStop; //distance in KM
  
                  let durationInSecs = getDistance / speed;
                  let duration = distanceCalc.secondsToHms(durationInSecs * 3600) //secs
                  
  
                  //inserting distance in km and m
                  endStopObj['distance'] = {
                      km: getDistance.toFixed(2),
                      m: (getDistance * 1000).toFixed(2)
                  }
  
                  // inserting ETA
                  endStopObj['eta'] = {
                      text: duration,
                      timestamp: moment().add(Number(durationInSecs * 3600), 'seconds').unix(),
                      time: moment().add(Number(durationInSecs * 3600), 'seconds').utcOffset('+0200').format('h:mm A'),
                      seconds: Number(durationInSecs * 3600).toFixed(2),
                      currentTimeStamp: moment().add(Number(remainingDistanceFromCurrentStopInSecs * 3600), 'seconds').unix(),
                      currentTime: moment().add(Number(remainingDistanceFromCurrentStopInSecs * 3600), 'seconds').utcOffset('+0200').format('h:mm A'),
                      currentSeconds: Number(remainingDistanceFromCurrentStopInSecs * 3600).toFixed(2)
                  }
                  
                  busRecord['stops'].push(endStopObj);
                }
                
            }
            // if(busRecord['stops'] && busRecord['stops'].length > 0){
                
            // }
            responseBusRecords.push(busRecord);
            //stopsObj[bus.currentRouteDetermined]['stops'] = stopsObj[bus.currentRouteDetermined]['stops'].filter(x => !x['duplicate']);  
        }
        
    }
  
    hasRouteAllocated = [...new Set(hasRouteAllocated)]
    uniqueStops = uniqueStops.filter(function (el) {
        return !hasRouteAllocated.includes(el);
    });
  
    for (let unique of uniqueStops) {
        let index = responseBusRecords.indexOf((x) => x.deviceId == unique);
        if (index == -1) {
            let record = {
                locationName: location,
                deviceName: null,
                deviceId: null,
                stops: [],
                route: {
                    name: unique,
                    color: stopsObj[unique]['color'] ? '#' + stopsObj[unique]['color'] : ''
                }
            }
            //responseBusRecords.push(record);
        }
    }
    return responseBusRecords;
}


  const updateDistance = async (event, context, callback) => {
    let routes = getRoutesFromLocation('hatfield');
    let routesStopsUser = routes.map(id => "'" + id + "'").join();
    let getStopsForStationQuery = `SELECT id, routeAllocationName,StopNumber, PointX, PointY,sequence, colorScheme FROM stoplocations_react WHERE include = 1 AND routeAllocationName IN (${routesStopsUser})`
    const p1 = db.query(getStopsForStationQuery, {
        raw: true,
    });
  };
  

module.exports = {
    getAllBuses,
    getAllStaticDetails,
    getDriverRatings,
    getBusesStationEtaData,
    userGetStaticDetails,
    getBusesStationEtaDataCombine
};