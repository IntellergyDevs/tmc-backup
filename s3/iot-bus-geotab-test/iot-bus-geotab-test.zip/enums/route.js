module.exports = Object.freeze({
    'centurion': 'centurion',
    'marlboro': 'marlboro',
    'hatfield' : 'hatfield'
});