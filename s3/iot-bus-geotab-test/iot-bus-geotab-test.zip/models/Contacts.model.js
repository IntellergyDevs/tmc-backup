const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const Contacts = db.define('contacts', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    queryType: {
        type: Sequelize.STRING
    },
    name: {
        type: Sequelize.STRING,
    },
    emailId: {
        type: Sequelize.STRING,
        validate: {
            isEmail: {
                args: true,
                msg: 'Please enter a valid email'
            }
        }
    },
    phoneNo: {
        type: Sequelize.STRING
    },
    description: {
        type: Sequelize.TEXT
    },
    ticketDetails: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = Contacts;