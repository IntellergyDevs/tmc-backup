const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const gtNews = db.define('gtNews', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    title: {
        type: Sequelize.STRING
    },
    description: {
        type: Sequelize.TEXT
    },
    imageUrl: {
        type: Sequelize.TEXT
    },
    expiryDate: {
        type: Sequelize.DATE
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
},{
    freezeTableName: true
})

module.exports = gtNews;