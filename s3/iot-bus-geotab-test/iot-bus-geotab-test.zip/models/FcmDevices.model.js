const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const fcmDevices = db.define('fcmDevices', {
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    deviceModel: {
        type: Sequelize.STRING
    },
    androidVersion: {
        type: Sequelize.STRING
    },
    fcmToken: {
        type: Sequelize.STRING
    },
    uuidAndroidId: {
        type: Sequelize.STRING,
        allowNull: false,
    },
    ipAddress: {
        type: Sequelize.STRING
    },
    deviceType: {
        type: Sequelize.STRING
    },
    isActive: {
        type: Sequelize.INTEGER
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
}, {
    freezeTableName: true
})

module.exports = fcmDevices;