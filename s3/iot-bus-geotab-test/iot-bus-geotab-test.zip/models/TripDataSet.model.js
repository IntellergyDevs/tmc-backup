const Sequelize = require('sequelize');
const db = require('../config/db.sequelize');

const TripDataSet = db.define('tripdataset', {
    _id: {
        type: Sequelize.STRING,
        unique: true,
        //primaryKey: true,
    },
    id: {
        type: Sequelize.INTEGER,
        unique: true,
        primaryKey: true,
    },
    DeviceName: {
        type: Sequelize.STRING
    },
    DeviceId: {
        type: Sequelize.STRING
    },
    StartDateTime: {
        type: Sequelize.STRING
    },
    StopDateTime: {
        type: Sequelize.STRING
    },
    Distance: {
        type: Sequelize.FLOAT
    },
    AverageSpeed: {
        type: Sequelize.FLOAT
    },
    DrivingDuration: {
        type: Sequelize.STRING
    },
    MaximumSpeed: {
        type: Sequelize.FLOAT
    },
    IdlingDuration: {
        type: Sequelize.STRING
    },
    StopDuration: {
        type: Sequelize.STRING
    },
    StopPointX: {
        type: Sequelize.STRING
    },
    StopPointY: {
        type: Sequelize.STRING
    },
    NextTripStart: {
        type: Sequelize.STRING
    },
    WorkDistance: {
        type: Sequelize.FLOAT
    },
    WorkDrivingDuration: {
        type: Sequelize.STRING
    },
    WorkStopDuration: {
        type: Sequelize.STRING
    },
    createdAt: {
        type: Sequelize.DATE
    },
    updatedAt: {
        type: Sequelize.DATE
    },
},{
    freezeTableName: true
})

module.exports = TripDataSet;